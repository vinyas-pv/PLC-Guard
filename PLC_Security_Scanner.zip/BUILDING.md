# Building the Windows app and installer

**Goal:** a normal Windows installer, `PLC-Security-Scanner-Setup-<version>.exe`. Run it, click *Next*, *Install*, *Finish*,
and the last page has **"Launch PLC Security Scanner"** ticked, so finishing the installer opens the tool. It also adds a Start
menu entry (and an optional desktop shortcut) and an uninstaller under *Settings → Apps*.

> **The installer must be built on Windows.** PyInstaller cannot cross-compile, so it cannot be produced from Linux or macOS. This environment can prepare the project, but the actual Windows `.exe` must be built on Windows or by the included GitHub Actions workflow.
> If you do not have a Windows PC, see "Building without a Windows PC" below.

## 1. Prerequisites (once)

| Needed | Details |
|---|---|
| Windows 10 or 11, 64-bit | The build machine. The finished installer runs on 64-bit Windows 10/11. |
| 64-bit Python 3.10–3.15 (use the newest version supported by the installed PySide6 and PyInstaller releases) | From <https://www.python.org/downloads/>. In the installer tick **"Add python.exe to PATH"** and keep the **py launcher**. (Newer Python versions require compatible PySide6 and PyInstaller releases; pip will report if a package does not support the selected interpreter.) |
| Inno Setup 6.3 or newer | From <https://jrsoftware.org/isdl.php>. Needed only for the installer; without it you still get a portable folder. |
| Internet access | `pip` downloads PySide6 (a few hundred MB) and PyInstaller on the first build. |

Check from a Command Prompt: `py --list` shows installed versions. The build script selects the newest installed version from Python 3.15 down to 3.10; if the newest version is not yet supported by PySide6/PyInstaller, install a compatible version and retry.

## 2. Get the files

Unzip the project to a short path without spaces or special characters, for example `C:\src\plc-security-scanner`.
Avoid OneDrive-synced folders and very long paths: both cause odd build failures.

## 3. (Optional) Try it without building anything

Double-click **`run_from_source.bat`**. The first run creates a `.venv` folder and installs PySide6, then opens the app.
Equivalent by hand:

```
py -3 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python plc_security_scanner.py
```

## 4. Build the executable and installer

Open **Command Prompt** in the project folder and run:

```
packaging\build_windows.bat
```

It does the following and **stops at the first failure**:

1. Creates a build environment in `.venv-build` and installs `requirements.txt` and `requirements-build.txt`.
2. Generates the Windows version resource from `__version__` in `plc_scanner3.py` (the single place the version is set).
3. Builds the app with PyInstaller using `packaging\PLCSecurityScanner.spec`.
4. Compiles the installer with Inno Setup if it is installed.

The production source package intentionally excludes the development test suite. After building, launch the EXE and verify the main window, sample-project action, scan workflow and report export on the target Windows machine.

The first build takes several minutes. Results:

| Output | Path |
|---|---|
| **Installer** | `dist\installer\PLC-Security-Scanner-Setup-<version>.exe` |
| Portable app (no install needed) | `dist\PLC Security Scanner\PLC Security Scanner.exe` (copy the whole folder) |

## 5. Install and open the tool

1. Double-click `PLC-Security-Scanner-Setup-<version>.exe`.
2. If asked, choose *Install for me only* (no administrator rights needed) or *for all users*. Pick the folder and whether to
   create a desktop shortcut.
3. Click **Install**, then leave **"Launch PLC Security Scanner"** ticked and click **Finish**. The tool opens.

Later, start it from the Start menu. Uninstall from *Settings → Apps → PLC Security Scanner*.

**For IT / scripted installs**

```
PLC-Security-Scanner-Setup-3.5.0.exe /VERYSILENT /NORESTART            (current user; does not launch the app)
PLC-Security-Scanner-Setup-3.5.0.exe /VERYSILENT /NORESTART /ALLUSERS  (all users; needs administrator rights)
```

## 6. Using the app

* **Upload file…**, drag a file onto the window, or **Help → Open sample project** to try it.
* From a command prompt or *Open with*: `"PLC Security Scanner.exe" "C:\path\project.L5K"` opens and scans that file.
* **Where things are stored:** window size and preferences in the registry under `HKEY_CURRENT_USER\Software\PLCSecurityScanner`;
  crash details in `%LOCALAPPDATA%\PLC Security Scanner\error.log` (also **Help → Open error log folder**).
  The uninstaller leaves both so your settings survive an upgrade; delete them by hand for a clean removal.
* The command-line scanner (`plc_scanner3.py`) is unchanged and does not need the installer.

## 7. Releasing a new version

1. Change `__version__` in `plc_scanner3.py` .
2. Run `packaging\build_windows.bat` again.
3. Distribute the new installer. It upgrades an existing install in place because `AppId` in `installer.iss` never changes.

## 8. Customising

| Change | Where |
|---|---|
| Publisher name shown in the installer | `AppPublisher` in `packaging\installer.iss` |
| Company in the exe's file properties | `COMPANY` in `packaging\make_version_info.py` |
| Icon | Replace `assets\icon.ico` (keep several sizes: 16, 32, 48, 256) |
| Install for all users by default | `PrivilegesRequired=admin` in `installer.iss` |
| Extra bundled files | `datas` list in `packaging\PLCSecurityScanner.spec` (read them with `qt_resource_path`) |
| Single-file exe instead of a folder | Not recommended: slower start-up and more antivirus false positives. If you must, switch the spec to a onefile build. |

## 9. SmartScreen, antivirus and code signing

An unsigned executable is not trusted by default:

* **Windows SmartScreen** may show "Windows protected your PC". Click **More info → Run anyway**.
* **Some antivirus products flag PyInstaller applications.** UPX compression is already off, which helps the most.

To remove the warnings properly, **sign both the app and the installer** with a code-signing certificate
(`signtool sign /fd SHA256 /tr <timestamp-url> /td SHA256 /a <file>`; Inno Setup can sign the installer through its
`SignTool` directive). For internal distribution, ask IT to allow-list the installer by publisher or file hash.

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| `py` is not recognised | Reinstall Python from python.org with the py launcher and "Add to PATH". |
| `pip` cannot download packages (proxy or offline) | Configure the proxy (`pip config set global.proxy http://host:port`), or on a connected PC run `pip download -r requirements.txt -r requirements-build.txt -d wheels` and on the build PC `pip install --no-index --find-links wheels -r requirements.txt -r requirements-build.txt`. |
| `Unknown architecture identifier "x64compatible"` in Inno Setup | Inno Setup is older than 6.3: update it. |
| App does not start on another PC, mentions a missing DLL | Install the *Microsoft Visual C++ Redistributable 2015-2022 (x64)*: <https://aka.ms/vs/17/release/vc_redist.x64.exe>. |
| App closes immediately or shows no window | Look in `%LOCALAPPDATA%\PLC Security Scanner\error.log`. To see console output, set `console=True` in the spec and rebuild. |
| Help menu says the sample or README is not bundled | Check that the file is listed in `datas` in the PyInstaller spec. |
| Antivirus deletes files during the build | Exclude the project folder from real-time scanning while building. |

## What has and has not been verified

| Build package contents | Runtime verification |
|---|---|
| Source modules, build scripts, PyInstaller spec and installer script are included | The app should be launched and exercised on a Windows machine after building |
| The PyInstaller spec excludes unused Qt PDF and OpenGL modules | Confirm the GUI, scan workflow, sample action and exports on the target PC |

## Project map

| File | Purpose |
|---|---|
| `plc_security_scanner.py` | The PySide6 desktop app (window, table model, scan thread) |
| `(included in plc_security_scanner.py)` | Shared GUI logic: rows, filters, scan tracking, texts and resource paths |
| `plc_scanner3.py` | Scanner engine and command-line interface |
| `(GUI helpers included in plc_security_scanner.py)` | Shared filtering and report-export functions used by the Qt app |
| `assets/` | Application icon |
| `packaging/` | PyInstaller spec, Inno Setup script, build script, version-resource generator |
| `requirements.txt`, `requirements-build.txt` | Runtime and build dependencies |
| `run_from_source.bat` | Start the app from source without building |
