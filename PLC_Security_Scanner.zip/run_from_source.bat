@echo off
rem Starts the app from source (no build needed). First run installs PySide6 into .venv.
setlocal enableextensions
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher "py" not found. Install 64-bit Python 3.10-3.12 from python.org first.
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 exit /b 1
)
call ".venv\Scripts\activate.bat"
python -m pip install --quiet -r requirements.txt
if errorlevel 1 exit /b 1
python plc_security_scanner.py %*
endlocal
