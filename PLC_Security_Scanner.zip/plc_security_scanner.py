# Consolidated PLC Security Scanner GUI and support code.
# The PLC scanning engine remains in plc_scanner3.py.


# ===== GUI shared functions =====
"""
Shared PLC scanner filtering and report-export functions.

These functions are consolidated into plc_security_scanner.py.

Features
  * Upload a PLC file and scan it in a background thread. Supported (content-detected):
    .l5k .l5x .acd .rss .slc .ap15 .ap19 .zap15 .zap19 .scl .awl .s7p .zip .stu .sta .zef
    .project .projectarchive .gx3 .gxw .gps .smc2 .cxp .tsproj .plcproj .TcPOU .library .st .xml
    (ZIP-type files are opened and their supported members scanned; binary formats get
    string-level analysis - see the "Scan details" shown after a scan)
  * Colour-coded results table: click a column header to sort
  * Filter by minimum severity, free-text search, hide dead-code noise
  * Detail pane with context, CWE/standard, offending code and the fix
  * Download results as CSV (Excel-friendly), JSON or a standalone HTML report
  * Confidence level (High/Medium/Low) shown for every finding, with a minimum-confidence filter
  * Cancel button for long scans; large result lists are loaded into the table in batches
  * Always-visible indicator of the loaded Config, Rules file and Baseline, each with a reset button
  * OWASP Top 10 (2025 or 2021 edition, mapped by analogy): column, category filter, edition selector,
    summary in the HTML report and JSON export
  * Rules file: disable rules, override severity/text/confidence, add patterns and name tokens
    (see README, 'Rules file'); the rules file name and hash are written into JSON/HTML exports
  * Select several findings (Ctrl/Shift-click) and suppress them in one step
  * Baseline file: suppress findings you have triaged (accepted risk / false positive) with a reason;
    use 'Baseline...' to load one and 'Suppress selected...' to add the selected finding to it
  * Optional: strict mode and a JSON config file (same as the CLI --strict/--config)

Used internally by the PySide6 desktop application.
"""
import copy
import csv
import html
import json
import os
import queue
import sys
import threading
from dataclasses import asdict
from datetime import datetime
gui_HERE = os.path.dirname(os.path.abspath(__file__))
if gui_HERE not in sys.path:
    sys.path.insert(0, gui_HERE)
try:
    import plc_scanner3 as scanner
    IMPORT_ERROR = None
except Exception as exc:
    scanner = None
    IMPORT_ERROR = exc
gui_SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']
gui_SEV_ORDER = {s: i for i, s in enumerate(gui_SEVERITIES)}
gui_SEV_COLORS = {'CRITICAL': ('#f8d7da', '#842029'), 'HIGH': ('#ffe5d0', '#7a3e00'), 'MEDIUM': ('#fff3cd', '#664d03'), 'LOW': ('#e2f0d9', '#2d5016'), 'INFO': ('#e9ecef', '#343a40')}
gui_NOISE_RULES = {'PLC-CODE-001', 'PLC-CODE-002'}
gui_CONF_ORDER = {'High': 0, 'Medium': 1, 'Low': 2}
gui_ROW_BATCH = 250
gui_EXPORT_FIELDS = ['severity', 'rule_id', 'title', 'location', 'line', 'snippet', 'cwe_guideline', 'recommendation', 'practice', 'confidence', 'fingerprint', 'owasp']

def gui_summarize(findings):
    return {s: sum((1 for f in findings if f.severity == s)) for s in gui_SEVERITIES}

def gui_filter_findings(findings, min_severity='INFO', text='', hide_noise=False, min_confidence='ALL', owasp='ALL'):
    """Return [(original_index, finding)] that match the filters.
    min_confidence: ALL, MEDIUM (Medium and High) or HIGH. owasp: ALL or a category such as "A05"
    (a label like "A05 Injection" also works)."""
    owasp_code = '' if str(owasp).upper() == 'ALL' else str(owasp).split()[0].upper()
    limit = gui_SEV_ORDER.get(min_severity, gui_SEV_ORDER['INFO'])
    conf_limit = {'ALL': 99, 'MEDIUM': 1, 'HIGH': 0}.get(str(min_confidence).upper(), 99)
    needle = text.strip().lower()
    out = []
    for idx, f in enumerate(findings):
        if gui_SEV_ORDER.get(f.severity, 99) > limit:
            continue
        if hide_noise and f.rule_id in gui_NOISE_RULES:
            continue
        if conf_limit < 99 and gui_CONF_ORDER.get(f.confidence, 99) > conf_limit:
            continue
        if owasp_code and f.owasp.split(':')[0].upper() != owasp_code:
            continue
        if needle and needle not in ' '.join((str(x) for x in (f.severity, f.rule_id, f.title, f.location, f.snippet, f.cwe_guideline, f.practice, f.owasp))).lower():
            continue
        out.append((idx, f))
    return out

def gui_sort_value(col, f):
    if col == 'severity':
        return gui_SEV_ORDER.get(f.severity, 99)
    if col == 'line':
        return f.line
    if col == 'confidence':
        return {'high': 0, 'medium': 1, 'low': 2}.get(f.confidence.lower(), 3)
    return str(getattr(f, {'rule': 'rule_id'}.get(col, col))).lower()

def gui__suppression_record(item):
    """Normalize a (Finding, baseline-entry) pair for report exports."""
    f, entry = item
    d = asdict(f)
    d['report_status'] = 'SUPPRESSED'
    d['suppression_status'] = entry.get('status', 'accepted_risk')
    d['suppression_reason'] = entry.get('reason', '')
    d['suppression_owner'] = entry.get('owner', '')
    d['suppression_expires'] = entry.get('expires', '')
    return d

def gui_export_csv(findings, path, source='', suppressed=()):
    """Export active findings and, when supplied, suppressed findings with rationale."""
    with open(path, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(['source_file', 'report_status', 'suppression_status', 'suppression_reason', 'suppression_owner', 'suppression_expires'] + gui_EXPORT_FIELDS)
        for f in findings:
            d = asdict(f)
            w.writerow([os.path.basename(source), 'ACTIVE', '', '', '', ''] + [d[k] for k in gui_EXPORT_FIELDS])
        for item in suppressed:
            d = gui__suppression_record(item)
            w.writerow([os.path.basename(source), d['report_status'], d['suppression_status'], d['suppression_reason'], d['suppression_owner'], d['suppression_expires']] + [d[k] for k in gui_EXPORT_FIELDS])

def gui_provenance():
    """Scanner version and rules file in effect, recorded in exports for traceability."""
    if scanner is None:
        return {}
    r = getattr(scanner, 'ACTIVE_RULES', {})
    return {'scanner_version': getattr(scanner, '__version__', ''), 'rules_file': r.get('name') or 'built-in', 'rules_sha256': r.get('sha256', ''), 'owasp_edition': getattr(scanner, 'OWASP_STATE', {}).get('edition', '')}

def gui_export_json(findings, path, source='', suppressed=()):
    doc = {'source_file': source, 'generated': datetime.now().isoformat(timespec='seconds'), **gui_provenance(), 'summary': gui_summarize(findings), 'owasp_summary': {c: {'name': n, 'findings': k} for c, n, k in scanner.owasp_summary(findings)} if scanner else {}, 'findings': [asdict(f) for f in findings], 'suppressed_findings': [gui__suppression_record(item) for item in suppressed]}
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(doc, fh, indent=2, ensure_ascii=False)

def gui_build_html(findings, source='', suppressed=()):
    esc = html.escape
    counts = gui_summarize(findings)
    chips = ''.join((f'<span class="chip" style="background:{gui_SEV_COLORS[s][0]};color:{gui_SEV_COLORS[s][1]}">{s}: {counts[s]}</span>' for s in gui_SEVERITIES))
    owasp_line = ''
    if scanner is not None:
        ed = scanner.OWASP_STATE['edition']
        parts = [f'{c} {n}: {k}' for c, n, k in scanner.owasp_summary(findings) if k]
        owasp_line = f'OWASP Top 10:{ed} (primary category per finding, mapped by analogy to PLC code, not an OWASP assessment): ' + (' | '.join(parts) if parts else 'no mapped findings')
    rows = []
    for f in sorted(findings, key=lambda x: (gui_SEV_ORDER.get(x.severity, 99), x.line)):
        bg, fg = gui_SEV_COLORS.get(f.severity, gui_SEV_COLORS['INFO'])
        practice = f' <em>({esc(f.practice)})</em>' if f.practice else ''
        rows.append(f"""<tr><td><span class="chip" style="background:{bg};color:{fg}">{esc(f.severity)}</span></td><td>{esc(f.rule_id)}</td><td>{esc(f.confidence)}</td><td>{esc(f.owasp)}</td><td><strong>{esc(f.title)}</strong>{practice}<br><small>{esc(f.cwe_guideline)}</small></td><td>{esc(f.location)}{(' (line %d)' % f.line if f.line else '')}</td><td><code>{esc(f.snippet)}</code></td><td>{esc(f.recommendation)}</td></tr>""")
    suppressed_rows = []
    for f, entry in suppressed:
        suppressed_rows.append(f"<tr><td>{esc(f.severity)}</td><td>{esc(f.rule_id)}</td><td><strong>{esc(f.title)}</strong></td><td>{esc(f.location)}{(' (line %d)' % f.line if f.line else '')}</td><td>{esc(entry.get('status', 'accepted_risk'))}</td><td>{esc(entry.get('reason', ''))}</td><td>{esc(entry.get('owner', ''))}</td><td>{esc(entry.get('expires', ''))}</td></tr>")
    return f"""<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><title>PLC Security Report</title>\n<style>\nbody{{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#212529}}\nh1{{margin:0 0 4px}} .meta{{color:#6c757d;margin-bottom:14px}}\n.chip{{display:inline-block;padding:2px 9px;border-radius:10px;font-size:12px;font-weight:600;margin-right:6px}}\ntable{{border-collapse:collapse;width:100%;font-size:13px}}\nth,td{{border:1px solid #dee2e6;padding:6px 8px;vertical-align:top;text-align:left}}\nth{{background:#f1f3f5}} code{{background:#f8f9fa;padding:1px 4px;word-break:break-all}}\n</style></head><body>\n<h1>PLC Security Report</h1>\n<div class="meta">File: {esc(os.path.basename(source) or '-')} &nbsp;|&nbsp; Generated: {datetime.now():%Y-%m-%d %H:%M} &nbsp;|&nbsp; Total findings: {len(findings)}</div>\n<p>{chips}</p>\n<p><small>{esc(owasp_line)}</small></p>\n<p><small>Scanner {esc(gui_provenance().get('scanner_version', ''))}, rules: {esc(gui_provenance().get('rules_file', ''))}. Heuristic static analysis: findings are review leads, not proof of exploitable vulnerabilities. Confidence shows how likely a finding is a true positive (High = a setting or instruction was read directly; Low = absence-based or name-based).</small></p>\n<table><thead><tr><th>Severity</th><th>Rule</th><th>Confidence</th><th>OWASP Top 10</th><th>Finding</th><th>Location</th><th>Code</th><th>Recommended fix</th></tr></thead>\n<tbody>{(''.join(rows) if rows else '<tr><td colspan="8">No active findings.</td></tr>')}</tbody></table>\n<h2>Suppressed findings ({len(suppressed)})</h2>\n<p>Suppressed findings are included for audit traceability and are not counted as active findings.</p>\n<table><thead><tr><th>Severity</th><th>Rule</th><th>Finding</th><th>Location</th><th>Suppression type</th><th>Reason</th><th>Owner</th><th>Expires</th></tr></thead>\n<tbody>{(''.join(suppressed_rows) if suppressed_rows else '<tr><td colspan="8">No suppressed findings.</td></tr>')}</tbody></table>\n</body></html>"""

def gui_export_html(findings, path, source='', suppressed=()):
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(gui_build_html(findings, source, suppressed))

def gui_run_scan_ex(path, strict=False, baseline=None, cancel=None):
    """Run the scanner on one file of any supported format -> ScanResult(findings, details, suppressed...)."""
    if scanner is None:
        raise RuntimeError(f'plc_scanner3.py could not be imported: {IMPORT_ERROR}')
    return scanner.scan_file(path, strict, baseline, cancel)

def gui_run_scan(path, strict=False):
    """Run the scanner engine on one file and return its list of findings."""
    return gui_run_scan_ex(path, strict).findings
gui_FILE_GROUPS = (('Rockwell / Allen-Bradley', ('.l5k', '.l5x', '.acd', '.rss', '.slc')), ('Siemens', ('.ap15', '.ap19', '.zap15', '.zap19', '.scl', '.awl', '.s7p')), ('Schneider Electric', ('.stu', '.sta', '.zef', '.xef')), ('CODESYS / Beckhoff / IEC 61131-3', ('.project', '.projectarchive', '.library', '.st', '.tsproj', '.plcproj', '.tcpou')), ('Mitsubishi / Omron / other', ('.gx3', '.gxw', '.gps', '.smc2', '.cxp')), ('Archives and XML', ('.zip', '.xml')))

# ===== Qt support functions =====
"""Qt-free support logic for the PySide6 desktop app.

This code is consolidated into plc_security_scanner.py alongside the main Qt application.
"""
import os
import sys
import threading
from dataclasses import dataclass
import plc_scanner3 as scanner
qt_APP_NAME = 'PLC Security Scanner'
qt_ORG_NAME = 'PLCSecurityScanner'
qt_SEVERITIES = gui_SEVERITIES
qt_SEV_COLORS = gui_SEV_COLORS
qt_COLUMNS = (('severity', 'Severity', 90, True), ('rule', 'Rule', 110, False), ('confidence', 'Confidence', 90, True), ('owasp', 'OWASP', 70, True), ('title', 'Finding', 380, False), ('location', 'Location', 300, False), ('line', 'Line', 60, True))

class qt_RowStore:
    """The rows currently shown: [(original_index, finding)], with optional column sorting."""

    def __init__(self):
        self.rows = []
        self._sort = None

    def set_rows(self, rows):
        self.rows = list(rows)
        if self._sort:
            self.sort(*self._sort)

    def sort(self, column, descending=False):
        key = qt_COLUMNS[column][0]
        self._sort = (column, descending)
        self.rows.sort(key=lambda r: gui_sort_value(key, r[1]), reverse=descending)

    def cell(self, row, column):
        f = self.rows[row][1]
        key = qt_COLUMNS[column][0]
        if key == 'severity':
            return f.severity
        if key == 'rule':
            return f.rule_id
        if key == 'confidence':
            return f.confidence or '-'
        if key == 'owasp':
            return f.owasp.split(':')[0] or '-'
        if key == 'title':
            return f.title
        if key == 'location':
            return f.location
        return str(f.line) if f.line else '-'

    def finding(self, row):
        return self.rows[row][1]
qt_TREE_COLUMNS = (('category', 'Category', 190, False), ('title', 'Title', 330, False), ('instance', 'Instance', 420, False), ('confidence', 'Confidence', 90, True), ('owasp', 'OWASP', 70, True), ('location', 'Location', 260, False), ('line', 'Line', 60, True))
qt_INSTANCE_COLUMN = 2

def qt_category_text(f):
    """'[CRITICAL] PLC-LOG-001'"""
    return f'[{f.severity}] {f.rule_id}'

def qt_split_title(f):
    """(rule title, instance text) for a finding; instance is '' when the title carries none."""
    base = scanner.RULES.get(f.rule_id, (None, f.title))[1]
    t = f.title
    if t == base:
        return (base, '')
    if t.startswith(base + ' (') and t.endswith(')'):
        return (base, t[len(base) + 2:-1])
    return (t, '')

class qt_Group:
    """One top-level tree row: every occurrence of one rule title at one severity."""
    __slots__ = ('severity', 'rule_id', 'title', 'children', 'row')

    def __init__(self, severity, rule_id, title):
        self.severity, self.rule_id, self.title = (severity, rule_id, title)
        self.children, self.row = ([], 0)

    @property
    def key(self):
        return (self.severity, self.rule_id, self.title)

    @property
    def first(self):
        return self.children[0].finding

class qt_Child:
    """One sub-branch: a single occurrence (one Finding) of its group's rule."""
    __slots__ = ('index', 'finding', 'instance', 'parent', 'row')

    def __init__(self, index, finding, instance, parent, row):
        self.index, self.finding, self.instance, self.parent, self.row = (index, finding, instance, parent, row)

class qt_TreeStore:
    """Findings grouped as Group -> Child, with optional column sorting (groups by the column,
    occurrences by the same column when it describes an occurrence, otherwise by line)."""

    def __init__(self):
        self.groups = []
        self._sort = None

    def set_rows(self, rows):
        by_key, groups = ({}, [])
        for idx, f in rows:
            base, inst = qt_split_title(f)
            key = (f.severity, f.rule_id, base)
            g = by_key.get(key)
            if g is None:
                g = by_key[key] = qt_Group(*key)
                groups.append(g)
            g.children.append(qt_Child(idx, f, inst, g, len(g.children)))
        self.groups = groups
        self._renumber()
        if self._sort:
            self.sort(*self._sort)

    def _renumber(self):
        for r, g in enumerate(self.groups):
            g.row = r
            for k, c in enumerate(g.children):
                c.row = k

    @staticmethod
    def _child_key(key, c):
        if key == 'instance':
            return (c.instance or c.finding.snippet).lower()
        if key == 'location':
            return c.finding.location.lower()
        return c.finding.line

    @staticmethod
    def _group_key(key, g):
        if key == 'category':
            return (gui_SEV_ORDER.get(g.severity, 99), g.rule_id.lower())
        if key == 'title':
            return g.title.lower()
        if key == 'instance':
            return len(g.children)
        if key in ('location', 'line'):
            return min((qt_TreeStore._child_key(key, c) for c in g.children))
        return gui_sort_value(key, g.first)

    def sort(self, column, descending=False):
        key = qt_TREE_COLUMNS[column][0]
        self._sort = (column, descending)
        self.groups.sort(key=lambda g: self._group_key(key, g), reverse=descending)
        inner = key if key in ('instance', 'location', 'line') else 'line'
        for g in self.groups:
            g.children.sort(key=lambda c: self._child_key(inner, c), reverse=descending and inner == key)
        self._renumber()

    def cell(self, node, column):
        """Display text of a Group (top-level) or Child (sub-branch) cell."""
        key = qt_TREE_COLUMNS[column][0]
        if isinstance(node, qt_Group):
            f = node.first
            if key == 'category':
                return qt_category_text(f)
            if key == 'title':
                return node.title
            if key == 'instance':
                n = len(node.children)
                return f"{n} instance{('s' if n != 1 else '')}"
            if key == 'confidence':
                return f.confidence or '-'
            if key == 'owasp':
                return f.owasp.split(':')[0] or '-'
            return ''
        f = node.finding
        if key == 'instance':
            return node.instance or f.snippet or '-'
        if key == 'confidence':
            return f.confidence or '-'
        if key == 'owasp':
            return f.owasp.split(':')[0] or '-'
        if key == 'location':
            return f.location
        if key == 'line':
            return str(f.line) if f.line else '-'
        return ''

    @staticmethod
    def findings_for(nodes):
        """Unique findings behind the selected nodes: a Group stands for all of its occurrences."""
        out, seen = ([], set())
        for node in nodes:
            members = [c.finding for c in node.children] if isinstance(node, qt_Group) else [node.finding]
            for f in members:
                if id(f) not in seen:
                    seen.add(id(f))
                    out.append(f)
        return out

    def count(self):
        return sum((len(g.children) for g in self.groups))

@dataclass
class qt_FilterState:
    min_severity: str = 'ALL'
    min_confidence: str = 'ALL'
    owasp: str = 'ALL'
    text: str = ''
    hide_noise: bool = False

    def apply(self, findings):
        return gui_filter_findings(findings, 'INFO' if self.min_severity == 'ALL' else self.min_severity, self.text, self.hide_noise, self.min_confidence, self.owasp)

def qt_owasp_choices():
    """['ALL', 'A01 Broken Access Control', ...] for the active OWASP edition."""
    ed = scanner.OWASP_STATE['edition']
    return ['ALL'] + [f'{c} {n}' for c, n in scanner.OWASP_NAMES[ed].items()]

class qt_ScanTracker:
    """Which scan is current. Starting a scan abandons the previous one; results of an abandoned
    scan are rejected by accept(), so they can never overwrite newer results."""

    def __init__(self):
        self.scan_id = 0
        self.cancel_event = None
        self.busy = False

    def begin(self):
        if self.cancel_event is not None:
            self.cancel_event.set()
        self.scan_id += 1
        self.cancel_event = threading.Event()
        self.busy = True
        return (self.scan_id, self.cancel_event)

    def cancel(self):
        if self.busy and self.cancel_event is not None and (not self.cancel_event.is_set()):
            self.cancel_event.set()
            return True
        return False

    def accept(self, scan_id):
        if scan_id != self.scan_id:
            return False
        self.busy = False
        return True

def qt_status_text(shown, total, source='', suppressed=0, details=()):
    return f'Showing {shown} of {total} findings' + (f'  |  {os.path.basename(source)}' if source else '') + (f'  |  {suppressed} suppressed by baseline' if suppressed else '') + (f'  |  {details[-1][:90]}' if details else '')

def qt_detail_text(f):
    lines = [f'[{f.severity}] {f.rule_id}  {f.title}', '']
    for label, value in (('Location', f.location + (f'  (line {f.line})' if f.line else '')), ('Standard', f.cwe_guideline), ('Practice', f.practice or '-'), ('OWASP', f.owasp or '-'), ('Confidence', f.confidence or '-'), ('Code', f.snippet), ('Fix', f.recommendation)):
        lines.append(f'{label:<10}: {value}')
    return '\n'.join(lines)

def qt_group_text(g, limit=25):
    """Detail pane text for a selected top-level row (a Category / Title group)."""
    f = g.first
    lines = [f'{qt_category_text(f)}  {g.title}', '']
    n = len(g.children)
    for label, value in (('Instances', f'{n} (click the arrow or this row to expand them)'), ('Standard', f.cwe_guideline), ('Practice', f.practice or '-'), ('OWASP', f.owasp or '-'), ('Confidence', f.confidence or '-'), ('Fix', f.recommendation)):
        lines.append(f'{label:<10}: {value}')
    lines += ['', 'Instances:']
    for c in g.children[:limit]:
        where = c.finding.location + (f' line {c.finding.line}' if c.finding.line else '')
        lines.append(f"  - {c.instance or c.finding.snippet or '-'}  [{where}]")
    if n > limit:
        lines.append(f'  ... and {n - limit} more')
    return '\n'.join(lines)

def qt_scan_details_text(details):
    if not details:
        return ''
    return 'Scan details (how each part of the file was analysed)\n\n' + '\n'.join((f'  - {d}' for d in details))

def qt_multi_text(findings):
    lines = [f'{len(findings)} findings selected', '']
    lines += [f'  [{f.severity}] {f.rule_id}  {f.location}' for f in findings[:12]]
    if len(findings) > 12:
        lines.append(f'  ... and {len(findings) - 12} more')
    lines += ['', "Use 'Suppress selected…' to baseline them all with one reason."]
    return '\n'.join(lines)

def qt_config_indicator(name):
    return f"Config: {name or 'built-in defaults'}"

def qt_rules_indicator(name, disabled=0, overridden=0):
    return f'Rules: {name} ({disabled} disabled, {overridden} overridden)' if name else 'Rules: built-in'

def qt_baseline_indicator(path, entries=0):
    return f'Baseline: {os.path.basename(path)} ({entries} entries)' if path else 'Baseline: none'

def qt_suppress_question(findings):
    if len(findings) == 1:
        f = findings[0]
        return f'Why is {f.rule_id} at {f.location} acceptable?'
    f = findings[0]
    return f'Why are these {len(findings)} findings acceptable? (first: {f.rule_id} at {f.location})'

def qt_chip_text(severity, count):
    return f'{severity}: {count}'

def qt_qt_file_filters():
    """Filter string for QFileDialog: all supported types first, then one entry per vendor group."""

    def pats(exts):
        out = []
        for e in exts:
            for v in (e, e.upper(), '.TcPOU' if e == '.tcpou' else e):
                if '*' + v not in out:
                    out.append('*' + v)
        return ' '.join(out)
    every = [e for _, g in gui_FILE_GROUPS for e in g]
    parts = [f'All supported PLC files ({pats(every)})']
    parts += [f'{label} ({pats(g)})' for label, g in gui_FILE_GROUPS]
    parts.append('All files (*)')
    return ';;'.join(parts)

def qt_export_name(fmt, source):
    base = os.path.splitext(os.path.basename(source))[0] or 'plc'
    return f'{base}_security_report.{fmt}'

def qt_export_filter(fmt):
    return f'{fmt.upper()} files (*.{fmt});;All files (*)'

def qt_parse_args(args):
    """First command-line argument that is an existing file (used by 'Open with' / drag onto the exe)."""
    for a in args:
        if not a.startswith('-') and os.path.isfile(a):
            return os.path.abspath(a)
    return None

def qt_resource_path(rel):
    """Path of a bundled data file, both when running from source and from a PyInstaller build."""
    base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)

def qt_log_dir(environ=None):
    env = os.environ if environ is None else environ
    root = env.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), '.local', 'share')
    return os.path.join(root, qt_APP_NAME)

def qt_log_path(environ=None):
    return os.path.join(qt_log_dir(environ), 'error.log')

def qt_about_text():
    r = scanner.ACTIVE_RULES
    return f"{qt_APP_NAME} {scanner.__version__}\n\nA static review aid for PLC projects: it reads exported project files and reports weaknesses, never connecting to a controller or network.\n\nFindings are heuristic review leads, not proof of exploitability. OWASP Top 10 categories are assigned by analogy to PLC code and are not an OWASP assessment.\n\nOWASP edition: {scanner.OWASP_STATE['edition']}\nRules file: {r.get('name') or 'built-in'}\nError log: {qt_log_path()}"

# ===== Main Qt application =====
"""PLC Security Scanner desktop application. GUI support and report logic are consolidated in this file; plc_scanner3.py remains the scanning engine."""
import copy
import functools
import json
import os
import sys
import traceback
import plc_scanner3 as scanner
from PySide6.QtCore import QAbstractItemModel, QModelIndex, QSettings, QThread, QTimer, QUrl, Qt, Signal
from PySide6.QtGui import QAction, QBrush, QColor, QDesktopServices, QFont, QIcon, QKeySequence
from PySide6.QtWidgets import QAbstractItemView, QApplication, QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QSplitter, QTreeView, QVBoxLayout, QWidget
SAMPLE_NAME = 'critical_logic_flaw_sample.L5K'
JSON_FILTER = 'JSON files (*.json);;All files (*)'

class ResultsModel(QAbstractItemModel):
    """Two-level tree over qt_TreeStore: a row per Category / Title, instances as its children.
    Index internal pointers are the store's Group / Child objects (the store keeps them alive)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.store = qt_TreeStore()

    def rowCount(self, parent=QModelIndex()):
        if not parent.isValid():
            return len(self.store.groups)
        if parent.column() != 0:
            return 0
        node = parent.internalPointer()
        return len(node.children) if isinstance(node, qt_Group) else 0

    def columnCount(self, parent=QModelIndex()):
        return len(qt_TREE_COLUMNS)

    def index(self, row, column, parent=QModelIndex()):
        if row < 0 or column < 0 or column >= len(qt_TREE_COLUMNS):
            return QModelIndex()
        if not parent.isValid():
            if row >= len(self.store.groups):
                return QModelIndex()
            return self.createIndex(row, column, self.store.groups[row])
        group = parent.internalPointer()
        if not isinstance(group, qt_Group) or row >= len(group.children):
            return QModelIndex()
        return self.createIndex(row, column, group.children[row])

    def parent(self, index):
        if not index.isValid():
            return QModelIndex()
        node = index.internalPointer()
        if isinstance(node, qt_Child):
            return self.createIndex(node.parent.row, 0, node.parent)
        return QModelIndex()

    def node(self, index):
        return index.internalPointer() if index.isValid() else None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        node, col = (index.internalPointer(), index.column())
        is_group = isinstance(node, qt_Group)
        if role == Qt.ItemDataRole.DisplayRole:
            return self.store.cell(node, col)
        severity = node.severity if is_group else node.finding.severity
        if is_group and role == Qt.ItemDataRole.BackgroundRole:
            return QBrush(QColor(qt_SEV_COLORS.get(severity, qt_SEV_COLORS['INFO'])[0]))
        if is_group and role == Qt.ItemDataRole.ForegroundRole:
            return QBrush(QColor(qt_SEV_COLORS.get(severity, qt_SEV_COLORS['INFO'])[1]))
        if is_group and role == Qt.ItemDataRole.FontRole:
            font = QFont()
            font.setBold(True)
            return font
        if role == Qt.ItemDataRole.TextAlignmentRole and qt_TREE_COLUMNS[col][3]:
            return int(Qt.AlignmentFlag.AlignCenter)
        if role == Qt.ItemDataRole.ToolTipRole:
            text = self.store.cell(node, col)
            if not is_group and col == qt_INSTANCE_COLUMN:
                text = f'{text}\n{node.finding.location}' + (f' (line {node.finding.line})' if node.finding.line else '')
            return text
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return qt_TREE_COLUMNS[section][1]
        return None

    def set_rows(self, rows):
        self.beginResetModel()
        self.store.set_rows(rows)
        self.endResetModel()

    def sort(self, column, order=Qt.SortOrder.AscendingOrder):
        if column < 0 or column >= len(qt_TREE_COLUMNS):
            return
        self.beginResetModel()
        self.store.sort(column, order == Qt.SortOrder.DescendingOrder)
        self.endResetModel()

class ScanThread(QThread):
    done = Signal(int, str, object)

    def __init__(self, scan_id, path, strict, baseline, cancel, parent=None):
        super().__init__(parent)
        self.scan_id, self.path, self.strict, self.baseline, self.cancel = (scan_id, path, strict, baseline, cancel)

    def run(self):
        try:
            result = gui_run_scan_ex(self.path, self.strict, self.baseline, self.cancel)
            self.done.emit(self.scan_id, 'ok', result)
        except scanner.ScanCancelled:
            self.done.emit(self.scan_id, 'cancelled', None)
        except Exception as exc:
            self.done.emit(self.scan_id, 'err', exc)

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(qt_APP_NAME)
        self.resize(1280, 820)
        self.setMinimumSize(920, 580)
        self.setAcceptDrops(True)
        self.findings, self.source, self.details = ([], '', [])
        self.suppressed = []
        self.baseline, self.baseline_path, self.suppressed_n = (None, '', 0)
        self.config_name, self.rules_name = ('', '')
        self.default_config = copy.deepcopy(scanner.CONFIG)
        self.tracker = qt_ScanTracker()
        self._threads = set()
        self.settings = QSettings(qt_ORG_NAME, qt_APP_NAME)
        self.model = ResultsModel(self)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(200)
        self._search_timer.timeout.connect(self.refresh_table)
        self._build_ui()
        self.menuBar().hide()
        self._apply_dashboard_style()
        self._restore_settings()
        self.refresh_indicators()
        self.refresh_table()
        self.set_busy(False)

    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)
        box = QGroupBox('1. Upload a PLC project / export / source file')
        lay = QVBoxLayout(box)
        r1 = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setReadOnly(True)
        self.path_edit.setPlaceholderText('Drop a file here, or click Browse…')
        self.btn_upload = QPushButton('Browse')
        self.btn_scan = QPushButton('Re-scan')
        self.btn_cancel = QPushButton('Cancel')
        self.chk_strict = QCheckBox('Strict (guards must be in the same rung)')
        for w in (self.path_edit, self.btn_upload, self.btn_scan, self.btn_cancel, self.chk_strict):
            r1.addWidget(w)
        r1.setStretch(0, 1)
        lay.addLayout(r1)
        r2 = QHBoxLayout()
        self.btn_config = QPushButton('Config…')
        self.btn_rules = QPushButton('Rules…')
        self.btn_baseline = QPushButton('Baseline…')
        self.lbl_cfg, self.lbl_rules, self.lbl_bl = (QLabel(), QLabel(), QLabel())
        self.btn_reset_cfg = QPushButton('Reset config')
        self.btn_reset_rules = QPushButton('Reset rules')
        self.btn_clear_bl = QPushButton('Clear baseline')
        r2.addWidget(self.btn_baseline)
        r2.addWidget(self.lbl_bl)
        r2.addWidget(self.btn_clear_bl)
        r2.addStretch(1)
        lay.addLayout(r2)
        root.addWidget(box)
        cards = QHBoxLayout()
        cards.setSpacing(10)
        self.chips = {}
        self.card_frames = []
        for sev in qt_SEVERITIES:
            bg, fg = qt_SEV_COLORS[sev]
            frame = QFrame()
            frame.setObjectName('severityCard')
            frame.setProperty('severity', sev.lower())
            frame.setMinimumHeight(66)
            frame.setFrameShape(QFrame.Shape.StyledPanel)
            card_lay = QVBoxLayout(frame)
            card_lay.setContentsMargins(12, 8, 12, 8)
            card_lay.setSpacing(2)
            title = QLabel(sev)
            title.setObjectName('cardTitle')
            value = QLabel('0')
            value.setObjectName('cardValue')
            value.setStyleSheet(f'color:{fg};')
            card_lay.addWidget(title)
            card_lay.addWidget(value)
            self.chips[sev] = value
            self.card_frames.append(frame)
            cards.addWidget(frame, 1)
        for key, title_text in (('TOTAL', 'TOTAL FINDINGS'), ('SUPPRESSED', 'SUPPRESSED')):
            frame = QFrame()
            frame.setObjectName('summaryCard')
            frame.setMinimumHeight(66)
            card_lay = QVBoxLayout(frame)
            card_lay.setContentsMargins(12, 8, 12, 8)
            card_lay.setSpacing(2)
            title = QLabel(title_text)
            title.setObjectName('cardTitle')
            value = QLabel('0')
            value.setObjectName('cardValue')
            card_lay.addWidget(title)
            card_lay.addWidget(value)
            self.chips[key] = value
            self.card_frames.append(frame)
            cards.addWidget(frame, 1)
        root.addLayout(cards)
        self.cmb_sev = QComboBox()
        self.cmb_sev.addItems(['ALL'] + list(qt_SEVERITIES))
        self.cmb_conf = QComboBox()
        self.cmb_conf.addItems(['ALL', 'MEDIUM', 'HIGH'])
        self.cmb_conf.setCurrentText('HIGH')
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText('Search rule, text, location, CWE, OWASP…')
        self.txt_search.setClearButtonEnabled(True)
        self.chk_noise = QCheckBox('Hide dead-code noise')
        self.cmb_edition = QComboBox()
        self.cmb_edition.addItems(['2025', '2021'])
        self.cmb_owasp = QComboBox()
        self.cmb_owasp.setMinimumWidth(260)
        self.cmb_owasp.addItems(qt_owasp_choices())
        self.btn_suppress = QPushButton('Suppress selected…')
        self.btn_expand = QPushButton('Expand all')
        self.btn_collapse = QPushButton('Collapse all')
        f1 = QHBoxLayout()
        for text, w in (('Min severity:', self.cmb_sev), ('Min confidence:', self.cmb_conf)):
            f1.addWidget(QLabel(text))
            f1.addWidget(w)
        f1.addWidget(self.txt_search, 1)
        root.addLayout(f1)
        f2 = QHBoxLayout()
        f2.addStretch(1)
        f2.addWidget(self.btn_expand)
        f2.addWidget(self.btn_collapse)
        f2.addWidget(self.btn_suppress)
        root.addLayout(f2)
        self.tree = QTreeView()
        self.tree.setModel(self.model)
        self.tree.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tree.setWordWrap(False)
        self.tree.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.tree.setUniformRowHeights(True)
        self.tree.setAllColumnsShowFocus(True)
        self.tree.setRootIsDecorated(True)
        self.tree.setIndentation(20)
        self.tree.setExpandsOnDoubleClick(False)
        header = self.tree.header()
        header.setSortIndicator(-1, Qt.SortOrder.AscendingOrder)
        self.tree.setSortingEnabled(True)
        for i, (_, _, width, _) in enumerate(qt_TREE_COLUMNS):
            self.tree.setColumnWidth(i, width)
        header.setSectionResizeMode(qt_INSTANCE_COLUMN, QHeaderView.ResizeMode.Stretch)
        self.tree.selectionModel().selectionChanged.connect(self.on_selection)
        self.tree.clicked.connect(self.on_tree_clicked)
        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        mono = QFont('Consolas')
        mono.setStyleHint(QFont.StyleHint.Monospace)
        self.detail.setFont(mono)
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.tree)
        split.addWidget(self.detail)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 1)
        root.addWidget(split, 1)
        exp = QHBoxLayout()
        exp.addWidget(QLabel('3. Download results:'))
        self.btn_csv, self.btn_json, self.btn_html = (QPushButton('CSV'), QPushButton('JSON'), QPushButton('HTML report'))
        for w in (self.btn_csv, self.btn_json, self.btn_html):
            exp.addWidget(w)
        self.chk_only_shown = QCheckBox('Export only the rows currently shown')
        exp.addWidget(self.chk_only_shown)
        exp.addStretch(1)
        root.addLayout(exp)
        self.setCentralWidget(central)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setMaximumWidth(150)
        self.progress.setTextVisible(False)
        self.progress.hide()
        self.statusBar().addPermanentWidget(self.progress)
        self.btn_upload.clicked.connect(self.on_upload)
        self.btn_scan.clicked.connect(self.on_scan)
        self.btn_cancel.clicked.connect(self.on_cancel)
        self.btn_config.clicked.connect(self.on_config)
        self.btn_rules.clicked.connect(self.on_rules)
        self.btn_baseline.clicked.connect(self.on_baseline)
        self.btn_reset_cfg.clicked.connect(self.on_reset_config)
        self.btn_reset_rules.clicked.connect(self.on_reset_rules)
        self.btn_clear_bl.clicked.connect(self.on_clear_baseline)
        self.btn_suppress.clicked.connect(self.on_suppress)
        self.btn_expand.clicked.connect(lambda *_: self.tree.expandAll())
        self.btn_collapse.clicked.connect(lambda *_: self.tree.collapseAll())
        self.btn_csv.clicked.connect(functools.partial(self.on_export, 'csv'))
        self.btn_json.clicked.connect(functools.partial(self.on_export, 'json'))
        self.btn_html.clicked.connect(functools.partial(self.on_export, 'html'))
        self.cmb_sev.currentIndexChanged.connect(self.refresh_table)
        self.cmb_conf.currentIndexChanged.connect(self.refresh_table)
        self.cmb_owasp.currentIndexChanged.connect(self.refresh_table)
        self.cmb_edition.currentIndexChanged.connect(self.on_edition_changed)
        self.chk_noise.stateChanged.connect(self.refresh_table)
        self.txt_search.textChanged.connect(self._search_changed)

    def _apply_dashboard_style(self):
        """Apply a restrained, modern light theme without changing scan behaviour."""
        self.setStyleSheet('\n            QMainWindow, QWidget { background: #f4f7fb; color: #1f2937; }\n            QMenuBar { background: #ffffff; border-bottom: 1px solid #dbe3ee; padding: 4px; }\n            QMenuBar::item { padding: 6px 10px; background: transparent; border-radius: 5px; }\n            QMenuBar::item:selected, QMenu::item:selected { background: #e8f0fb; color: #174a86; }\n            QMenu { background: #ffffff; border: 1px solid #dbe3ee; }\n            QGroupBox { background: #ffffff; border: 1px solid #dbe3ee; border-radius: 9px;\n                        margin-top: 12px; padding: 12px 10px 10px; font-weight: 600; }\n            QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; color: #34445a; }\n            QLineEdit, QComboBox, QPlainTextEdit { background: #ffffff; border: 1px solid #cbd5e1;\n                        border-radius: 6px; padding: 6px 8px; selection-background-color: #cfe3ff; }\n            QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus { border: 1px solid #4385d1; }\n            QPushButton { background: #ffffff; border: 1px solid #cbd5e1; border-radius: 6px;\n                          padding: 7px 12px; min-height: 18px; }\n            QPushButton:hover { background: #edf4fc; border-color: #8fb5e5; }\n            QPushButton:pressed { background: #dceafa; }\n            QPushButton:disabled { color: #9aa6b5; background: #f1f4f8; }\n            QPushButton[text="Scan"] { background: #1769aa; color: #ffffff; border-color: #1769aa; font-weight: 700; }\n            QPushButton[text="Scan"]:hover { background: #12578f; }\n            QTreeView, QTableView { background: #ffffff; alternate-background-color: #f7f9fc; gridline-color: #e7edf4;\n                         border: 1px solid #dbe3ee; border-radius: 7px; selection-background-color: #d9eaff;\n                         selection-color: #172b45; }\n            QTreeView::item { padding: 3px 0; }\n            QHeaderView::section { background: #edf2f8; color: #334155; padding: 8px 6px;\n                                   border: none; border-right: 1px solid #dbe3ee; border-bottom: 1px solid #dbe3ee;\n                                   font-weight: 700; }\n            QFrame#severityCard, QFrame#summaryCard { background: #ffffff; border: 1px solid #dbe3ee;\n                                                      border-radius: 9px; }\n            QFrame#severityCard[severity="critical"] { border-top: 3px solid #991b1b; }\n            QFrame#severityCard[severity="high"] { border-top: 3px solid #c2410c; }\n            QFrame#severityCard[severity="medium"] { border-top: 3px solid #b7791f; }\n            QFrame#severityCard[severity="low"] { border-top: 3px solid #24734b; }\n            QFrame#severityCard[severity="info"] { border-top: 3px solid #64748b; }\n            QFrame#summaryCard { border-top: 3px solid #2563a6; }\n            QLabel#cardTitle { color: #64748b; font-size: 9pt; font-weight: 700; }\n            QLabel#cardValue { font-size: 18pt; font-weight: 700; }\n            QStatusBar { background: #ffffff; border-top: 1px solid #dbe3ee; color: #475569; }\n            QProgressBar { border: 1px solid #cbd5e1; border-radius: 4px; background: #eef2f7; }\n            QProgressBar::chunk { background: #2d7cc0; border-radius: 3px; }\n            QSplitter::handle { background: #e3eaf3; }\n        ')

    def _build_menu(self):

        def act(menu, text, slot, shortcut=None):
            a = QAction(text, self)
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            a.triggered.connect(slot)
            menu.addAction(a)
            return a
        m = self.menuBar().addMenu('&File')
        act(m, '&Open file…', self.on_upload, 'Ctrl+O')
        act(m, '&Scan again', self.on_scan, 'F5')
        act(m, '&Cancel scan', self.on_cancel, 'Esc')
        m.addSeparator()
        for fmt in ('csv', 'json', 'html'):
            act(m, f'Export {fmt.upper()}…', functools.partial(self.on_export, fmt))
        m.addSeparator()
        act(m, 'E&xit', self.close, 'Ctrl+Q')
        s = self.menuBar().addMenu('&Settings')
        act(s, 'Load &config…', self.on_config)
        act(s, 'Load &rules…', self.on_rules)
        act(s, 'Load &baseline…', self.on_baseline)
        s.addSeparator()
        act(s, 'Reset config', self.on_reset_config)
        act(s, 'Reset rules', self.on_reset_rules)
        act(s, 'Clear baseline', self.on_clear_baseline)
        h = self.menuBar().addMenu('&Help')
        act(h, 'Open &sample project', self.on_open_sample)
        act(h, 'Open &README', self.on_open_readme)
        act(h, 'Open error &log folder', self.on_open_log)
        h.addSeparator()
        act(h, '&About', self.on_about)

    def pick_open_file(self, title, filters, start_dir=''):
        path, _ = QFileDialog.getOpenFileName(self, title, start_dir, filters)
        return path

    def pick_save_file(self, title, default_path, filters):
        path, _ = QFileDialog.getSaveFileName(self, title, default_path, filters)
        return path

    def ask_text(self, title, label):
        text, ok = QInputDialog.getText(self, title, label)
        return text if ok else None

    def ask_yes_no(self, title, text):
        yes = QMessageBox.StandardButton.Yes
        no = QMessageBox.StandardButton.No
        return QMessageBox.question(self, title, text, yes | no, no) == yes

    def info(self, title, text):
        QMessageBox.information(self, title, text)

    def warn(self, title, text):
        QMessageBox.warning(self, title, text)

    def error(self, title, text):
        QMessageBox.critical(self, title, text)

    def _restore_settings(self):
        geo = self.settings.value('geometry')
        if geo:
            self.restoreGeometry(geo)
        self.chk_strict.setChecked(self.settings.value('strict', False, type=bool))
        edition = str(self.settings.value('owasp_edition', '2025'))
        if edition in scanner.OWASP_NAMES:
            scanner.set_owasp_edition(edition)
            self.cmb_edition.setCurrentText(edition)
            self._fill_owasp_combo()

    def _save_settings(self):
        self.settings.setValue('geometry', self.saveGeometry())
        self.settings.setValue('strict', self.chk_strict.isChecked())
        self.settings.setValue('owasp_edition', scanner.OWASP_STATE['edition'])

    def _last_dir(self):
        return str(self.settings.value('last_dir', '') or '')

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if path and os.path.isfile(path):
                self.open_path(path)
                break

    def closeEvent(self, event):
        self.tracker.cancel()
        self._save_settings()
        for t in list(self._threads):
            t.wait(3000)
        super().closeEvent(event)

    def on_upload(self, *_):
        path = self.pick_open_file('Select a PLC project, export, source or archive file', qt_qt_file_filters(), self._last_dir())
        if path:
            self.open_path(path)

    def open_path(self, path, scan=True):
        if not os.path.isfile(path):
            self.warn('File not found', f'Cannot open:\n{path}')
            return
        self.settings.setValue('last_dir', os.path.dirname(path))
        self.path_edit.setText(path)
        if scan:
            self.on_scan()

    def on_scan(self, *_):
        path = self.path_edit.text()
        if not path or not os.path.isfile(path):
            self.warn('No file', 'Please upload a PLC file first.')
            return
        scan_id, cancel = self.tracker.begin()
        self.set_busy(True)
        self.statusBar().showMessage(f'Scanning {os.path.basename(path)} …')
        thread = ScanThread(scan_id, path, self.chk_strict.isChecked(), self.baseline, cancel, self)
        thread.done.connect(self._on_done)
        thread.finished.connect(functools.partial(self._thread_finished, thread))
        self._threads.add(thread)
        thread.start()

    def _thread_finished(self, thread, *_):
        self._threads.discard(thread)
        thread.deleteLater()

    def on_cancel(self, *_):
        if self.tracker.cancel():
            self.statusBar().showMessage('Cancelling… (stops at the next checkpoint)')

    def _on_done(self, scan_id, kind, payload):
        if not self.tracker.accept(scan_id):
            return
        self.set_busy(False)
        if kind == 'cancelled':
            self.statusBar().showMessage('Scan cancelled. Previous results (if any) are unchanged.')
            return
        if kind == 'err':
            self.statusBar().showMessage('Scan failed.')
            self.error('Scan failed', f'{payload}')
            return
        self.findings, self.details = (payload.findings, payload.details)
        self.suppressed = list(payload.suppressed)
        self.suppressed_n = len(self.suppressed)
        self.source = self.path_edit.text()
        self.setWindowTitle(f'{qt_APP_NAME} - {os.path.basename(self.source)}')
        self.refresh_table()

    def set_busy(self, busy):
        for w in (self.btn_upload, self.btn_scan, self.btn_config, self.btn_rules, self.btn_baseline, self.btn_reset_cfg, self.btn_reset_rules, self.btn_clear_bl, self.btn_suppress):
            w.setEnabled(not busy)
        self.btn_cancel.setEnabled(busy)
        self.progress.setVisible(busy)

    def filter_state(self):
        return qt_FilterState(self.cmb_sev.currentText(), self.cmb_conf.currentText(), self.cmb_owasp.currentText(), self.txt_search.text(), self.chk_noise.isChecked())

    def current_rows(self):
        return self.filter_state().apply(self.findings)

    def _search_changed(self, *_):
        self._search_timer.start()

    def refresh_table(self, *_):
        opened = {g.key for g in self.model.store.groups if self.tree.isExpanded(self.model.index(g.row, 0))}
        rows = self.current_rows()
        self.model.set_rows(rows)
        for g in self.model.store.groups:
            if g.key in opened:
                self.tree.setExpanded(self.model.index(g.row, 0), True)
        counts = gui_summarize([finding for _original_index, finding in rows])
        for sev in qt_SEVERITIES:
            self.chips[sev].setText(str(counts[sev]))
        self.chips['TOTAL'].setText(str(len(rows)))
        self.chips['SUPPRESSED'].setText(str(self.suppressed_n))
        self.statusBar().showMessage(qt_status_text(len(rows), len(self.findings), self.source, self.suppressed_n, self.details))
        self.show_selection()

    def selected_nodes(self):
        return [self.model.node(i) for i in self.tree.selectionModel().selectedRows()]

    def selected_findings(self):
        return qt_TreeStore.findings_for(self.selected_nodes())

    def _modifier_held(self):
        mods = QApplication.keyboardModifiers()
        return bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier))

    def on_tree_clicked(self, index):
        """Clicking a Category / Title row opens or closes its instances (Ctrl/Shift-click only selects)."""
        if not index.isValid() or index.parent().isValid() or self._modifier_held():
            return
        self.tree.setExpanded(index, not self.tree.isExpanded(index))

    def on_selection(self, *_):
        self.show_selection()

    def show_selection(self):
        nodes = self.selected_nodes()
        fs = qt_TreeStore.findings_for(nodes)
        if len(nodes) == 1 and isinstance(nodes[0], qt_Group):
            text = qt_group_text(nodes[0])
        elif len(fs) > 1:
            text = qt_multi_text(fs)
        elif fs:
            text = qt_detail_text(fs[0])
        else:
            text = qt_scan_details_text(self.details)
        self.detail.setPlainText(text)

    def _fill_owasp_combo(self):
        self.cmb_owasp.blockSignals(True)
        self.cmb_owasp.clear()
        self.cmb_owasp.addItems(qt_owasp_choices())
        self.cmb_owasp.blockSignals(False)

    def on_edition_changed(self, *_):
        scanner.set_owasp_edition(self.cmb_edition.currentText())
        scanner.relabel_owasp(self.findings)
        self._fill_owasp_combo()
        self.refresh_table()

    def refresh_indicators(self):
        info = scanner.ACTIVE_RULES
        self.lbl_cfg.setText(qt_config_indicator(self.config_name))
        self.lbl_rules.setText(qt_rules_indicator(self.rules_name, info.get('disabled', 0), info.get('overridden', 0)))
        entries = len(self.baseline.get('entries', [])) if self.baseline else 0
        self.lbl_bl.setText(qt_baseline_indicator(self.baseline_path if self.baseline else '', entries))

    def on_config(self, *_):
        path = self.pick_open_file('Select a config JSON', JSON_FILTER, self._last_dir())
        if not path:
            return
        try:
            with open(path, encoding='utf-8-sig') as fh:
                data = json.load(fh)
            if not isinstance(data, dict):
                raise ValueError('the file must contain a JSON object')
            scanner.CONFIG.update(data)
        except (OSError, ValueError) as exc:
            self.error('Config error', f'Could not load the config:\n{exc}')
            return
        self.config_name = os.path.basename(path)
        self.refresh_indicators()
        self.statusBar().showMessage(f'Config loaded: {self.config_name} (applies to the next scan)')

    def on_reset_config(self, *_):
        scanner.CONFIG.clear()
        scanner.CONFIG.update(copy.deepcopy(self.default_config))
        self.config_name = ''
        self.refresh_indicators()
        self.statusBar().showMessage('Config reset to the built-in defaults (applies to the next scan)')

    def on_rules(self, *_):
        path = self.pick_open_file('Select a rules file (JSON)', JSON_FILTER, self._last_dir())
        if not path:
            return
        try:
            info = scanner.apply_rules(scanner.load_rules(path))
        except (OSError, ValueError) as exc:
            self.error('Rules file error', f'Could not use the rules file:\n{exc}')
            return
        self.rules_name = info['name']
        self.refresh_indicators()
        self.statusBar().showMessage(f"Rules file loaded: {info['name']} ({info['disabled']} disabled, {info['overridden']} overridden)")
        if self.source:
            self.on_scan()

    def on_reset_rules(self, *_):
        scanner.reset_rules()
        self.rules_name = ''
        self.refresh_indicators()
        self.statusBar().showMessage('Rules reset to the built-in set')
        if self.source:
            self.on_scan()

    def on_baseline(self, *_):
        path = self.pick_open_file('Select a baseline JSON', JSON_FILTER, self._last_dir())
        if not path:
            return
        try:
            self.baseline = scanner.load_baseline(path)
        except (OSError, ValueError) as exc:
            self.error('Baseline error', f'Could not load the baseline:\n{exc}')
            return
        self.baseline_path = path
        self.refresh_indicators()
        self.statusBar().showMessage(f"Baseline loaded: {os.path.basename(path)} ({len(self.baseline.get('entries', []))} entries)")
        if self.path_edit.text():
            self.on_scan()

    def on_clear_baseline(self, *_):
        if self.baseline is None:
            return
        self.baseline, self.baseline_path = (None, '')
        self.refresh_indicators()
        self.statusBar().showMessage('Baseline cleared')
        if self.path_edit.text():
            self.on_scan()

    def on_suppress(self, *_):
        fs = self.selected_findings()
        if not fs:
            self.info('Suppress', 'Select one or more findings (or a whole Category / Title row) first (Ctrl/Shift-click for several).')
            return
        path = self.baseline_path
        if not path:
            default = os.path.join(self._last_dir() or os.path.expanduser('~'), 'plc_baseline.json')
            path = self.pick_save_file('Choose or create a baseline file', default, JSON_FILTER)
            if not path:
                return
        reason = self.ask_text('Reason', qt_suppress_question(fs))
        if not reason or not reason.strip():
            return
        is_fp = self.ask_yes_no('Type of suppression', 'Is this a FALSE POSITIVE?\n\nYes = false positive\nNo = accepted risk')
        try:
            scanner.write_baseline(path, fs, 'false_positive' if is_fp else 'accepted_risk', reason.strip())
            self.baseline, self.baseline_path = (scanner.load_baseline(path), path)
        except (OSError, ValueError) as exc:
            self.error('Baseline error', str(exc))
            return
        self.refresh_indicators()
        self.on_scan()

    def on_export(self, fmt, *_):
        rows = [f for _, f in self.current_rows()] if self.chk_only_shown.isChecked() else self.findings
        if not rows and (not self.suppressed):
            self.info('Nothing to export', 'There are no active or suppressed findings to export.')
            return
        folder = self._last_dir() or os.path.expanduser('~')
        path = self.pick_save_file('Save results', os.path.join(folder, qt_export_name(fmt, self.source)), qt_export_filter(fmt))
        if not path:
            return
        try:
            {'csv': gui_export_csv, 'json': gui_export_json, 'html': gui_export_html}[fmt](rows, path, self.source, suppressed=self.suppressed)
        except OSError as exc:
            self.error('Save failed', str(exc))
            return
        self.statusBar().showMessage(f'Saved {len(rows)} active and {len(self.suppressed)} suppressed findings to {path}')
        self.info('Saved', f'Report saved:\n{path}\n\nIncluded: {len(rows)} active findings and {len(self.suppressed)} suppressed findings with their suppression reasons.')

    def on_open_sample(self, *_):
        for rel in (f'samples/{SAMPLE_NAME}',):
            path = qt_resource_path(rel)
            if os.path.isfile(path):
                self.open_path(path)
                return
        self.warn('Sample not found', 'The bundled sample file could not be located.')

    def on_open_readme(self, *_):
        path = qt_resource_path('README.md')
        if os.path.isfile(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            self.warn('README not found', 'README.md is not bundled with this build.')

    def on_open_log(self, *_):
        os.makedirs(qt_log_dir(), exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(qt_log_dir()))

    def on_about(self, *_):
        QMessageBox.about(self, f'About {qt_APP_NAME}', qt_about_text())

def install_excepthook():
    """Windowed builds have no console: log uncaught errors to a file and tell the user."""

    def hook(exc_type, exc, tb):
        text = ''.join(traceback.format_exception(exc_type, exc, tb))
        try:
            os.makedirs(qt_log_dir(), exist_ok=True)
            with open(qt_log_path(), 'a', encoding='utf-8') as fh:
                fh.write(text + '\n')
        except OSError:
            pass
        try:
            QMessageBox.critical(None, qt_APP_NAME, f'An unexpected error occurred:\n\n{exc}\n\nDetails were written to:\n{qt_log_path()}')
        except Exception:
            pass
    sys.excepthook = hook

def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('PLCSecurityScanner.Desktop')
        except Exception:
            pass
    app = QApplication(argv)
    app.setApplicationName(qt_APP_NAME)
    app.setOrganizationName(qt_ORG_NAME)
    app.setStyle('Fusion')
    icon = qt_resource_path('assets/icon.ico')
    if os.path.isfile(icon):
        app.setWindowIcon(QIcon(icon))
    install_excepthook()
    window = MainWindow()
    window.show()
    target = qt_parse_args(argv[1:])
    if target:
        QTimer.singleShot(0, functools.partial(window.open_path, target))
    return app.exec()
if __name__ == '__main__':
    sys.exit(main())
