#!/usr/bin/env python3
"""
plc_scanner3.py (v3.5) - static security scanner for PLC projects. v3.5 ships with a PySide6 desktop app
and a Windows installer (plc_scanner_qt.py, packaging/); the engine itself is unchanged. v3.4 maps every finding to the
OWASP Top 10 (2025 or 2021 edition, by analogy: see README) and adds a policy-driven firmware check.
v3.3 added a rules file
(--rules / --dump-rules): disable rules, override severity/text/confidence, add config-property
patterns and name tokens without editing code. v3.2 added cooperative scan
cancellation (used by the GUI Cancel button). v3.1 added a baseline/suppression
file, a per-finding confidence level and support for the `MAIN name;` / `FAULT name;` L5K program
lines. v3.0 added a multi-format
front end (see "multi-format front end" below): L5K, L5X, ACD, RSS, SLC, AP15/AP19, ZAP15/ZAP19,
SCL, AWL, S7P, ZIP, STU, STA, ZEF, PROJECT, PROJECTARCHIVE, GX3, GXW, GPS, SMC2, CXP, TSPROJ,
PLCPROJ, TcPOU, LIBRARY, ST, XML. Format is detected from content; extension is only a hint.
Original v2.1 description - Rockwell Logix 5000 L5K
exports (RLL + Structured Text). Merges every control of l5k_auditor.py
(Top-20 style practices, module/OPC-UA config, HMI taint, sockets, MSG, duplicate
coils, conflicting outputs, key-switch / first-scan / session-timeout checks,
modularity, dead code, test residue) into the v1 rule set. v2.1 adds Top-20 P4
(overflow flags), P6 (timer/counter presets), P12 (I/O plausibility), P16-P18
(scan time / uptime / fault logging), latched-never-unlatched outputs, unbounded
ST loops, uncalled routines and unlocked safety tasks.

Supports both rung dialects: "N: XIC(a)OTE(b);" and "RUNG 12 XIC(a)OTE(b);"

This is a heuristic analyser: findings are review leads, not proof. Attribute
names for module/controller properties differ per firmware - extend CFG_PARAMS
or pass --config to adapt names to your export.

Usage:
    python plc_scanner3.py plant.L5K            (also .L5X .ST .SCL .TcPOU .xml .zip .acd ... see below)
    python plc_scanner3.py *.L5K --json out.json --csv out.csv --fail-on HIGH
    python plc_scanner3.py plant.L5K --strict --config my_names.json
Exit code: 1 if any finding at/above --fail-on (default HIGH; use INFO to fail on anything,
which reproduces l5k_auditor.py behaviour), else 0.
Requires Python 3.8+ (uses the walrus operator). No third-party packages.
"""
import argparse
import bisect
import csv
import datetime
import hashlib
import io
import ipaddress
import json
import os
import re
import sys
import zipfile
import zlib
import xml.etree.ElementTree as ET

# Avoid Windows console encoding errors truncating CLI reports. Preserve the
# active encoding and escape characters it cannot represent.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="backslashreplace")
    except (AttributeError, OSError, ValueError):
        pass
from dataclasses import dataclass, asdict, field

__version__ = "3.5.0"

SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}

# ------------------------------------------------------------ site configuration
# Override any key with --config file.json
CONFIG = {
    "rung_max": 50,
    "min_firmware_major": 0,   # policy: report controllers whose firmware major revision is lower (0 = off)
    "keyswitch_keywords": ["S:KEYS", "KeySwitch", "PLC_Key_Status"],
    "firstscan_keywords": ["S:FS", "First_Scan", "FirstScan", "PowerUp_Init"],
    "access_flag_keywords": ["Access_Granted", "Login_Active"],
    "password_input_keywords": ["HMI_Password"],
    "forbidden_pairs": [["Valve_Open", "Valve_Close"], ["Motor_FWD", "Motor_REV"],
                        ["Cylinder_Extend", "Cylinder_Retract"]],
    "hmi_prefixes": ["HMI_"],
    "overflow_keywords": ["S:V", "S:MINOR", "MinorFaultRecord", "Overflow"],
    "monitor_keywords": {
        "scan time": ["LastScanTime", "MaxScanTime"],
        "uptime": ["WallClockTime", "Uptime"],
        "fault logging": ["MajorFaultRecord", "MajorFaultBits"],
    },
}
# token pairs that describe opposing actuator commands (generalises forbidden_pairs)
OPPOSITES = [("open", "close"), ("fwd", "rev"), ("forward", "reverse"), ("extend", "retract"),
             ("up", "down"), ("raise", "lower"), ("cw", "ccw"), ("inc", "dec"), ("start", "stop")]

# module/controller properties that enable insecure services: (rule, regex)
CFG_PARAMS = [
    ("PLC-CFG-006", r"\bWebPortAccess\s*:=\s*1\b"),
    ("PLC-CFG-006", r"\bHttp(?:Server)?(?:Enabled|Status)\s*:=\s*1\b"),
    ("PLC-CFG-007", r"\bTelnet(?:Status|Enabled)\s*:=\s*1\b"),
    ("PLC-CFG-008", r"\bFtp(?:Status|Enabled)\s*:=\s*1\b"),
    ("PLC-CFG-009", r"\bOpcUaAnonymousLoginEnabled\s*:=\s*1\b"),
    ("PLC-CFG-010", r"\bOpcUaSecurityPolicyNoneEnabled\s*:=\s*1\b"),
    ("PLC-CFG-011", r"\bSnmp(?:Status|Enabled)\s*:=\s*1\b"),
    ("PLC-CFG-012", r"\bSafetyLocked\s*:=\s*(?:No|0)\b"),
]

# ------------------------------------------------------------ rule catalog
# id: (severity, title, CWE/guideline, recommendation, Top-20 practice label)
RULES = {
    # credentials
    "PLC-CRED-001": ("HIGH", "Hardcoded credential stored in tag value", "CWE-798 / CWE-259",
                     "Never keep passwords/keys in tag initial values; use FactoryTalk Security / CIP Security.", ""),
    "PLC-CRED-002": ("HIGH", "Credential-like text in comment/description/string", "CWE-798 / CWE-200",
                     "Remove secrets from descriptions, rung comments and strings.", ""),
    "PLC-CRED-003": ("HIGH", "Literal credential assigned or compared in logic", "CWE-798 / CWE-321",
                     "Replace hardcoded passcodes with an authenticated mechanism.", ""),
    "PLC-CRED-004": ("CRITICAL", "Hardcoded plaintext string compared in EQU (password check in logic)",
                     "CWE-798 / CWE-259",
                     "Do not authenticate by comparing against a literal string in ladder logic.", ""),
    # network
    "PLC-NET-001": ("LOW", "Hardcoded IP address", "CWE-547",
                    "Move addresses to configuration; review every external endpoint.", ""),
    "PLC-NET-002": ("HIGH", "Unauthenticated peer-to-peer MSG instruction", "CWE-306 / CWE-346",
                    "Legacy CIP messaging is unauthenticated: enforce CIP Security, whitelist targets, "
                    "avoid dynamic paths.", ""),
    "PLC-NET-003": ("CRITICAL", "Raw TCP/UDP socket interface without authentication framework",
                    "CWE-306 / CWE-319",
                    "Raw sockets bypass industrial security profiles; remove, or wrap with authentication "
                    "+ validation.", ""),
    # access
    "PLC-ACC-001": ("MEDIUM", "Safety/interlock-related tag writable externally", "CWE-284 / CWE-269",
                    "Set ExternalAccess to Read Only/None for safety, interlock, bypass and trip tags.", ""),
    "PLC-ACC-002": ("LOW", "Sensitive tag writable externally", "CWE-284",
                    "Restrict ExternalAccess on setpoint, mode and auth tags.", ""),
    "PLC-ACC-003": ("MEDIUM", "Secret-named tag exposed through ExternalAccess", "CWE-200 / CWE-522",
                    "Set ExternalAccess := None for tags holding secrets.", ""),
    # configuration
    "PLC-CFG-001": ("MEDIUM", "Controller exported with no security code", "CWE-306 / CWE-1188",
                    "Verify project protection (FactoryTalk Security, source protection, keyswitch RUN, "
                    "CIP Security).", ""),
    "PLC-CFG-002": ("MEDIUM", "Change detection / signature protection disabled", "CWE-353 / CWE-693",
                    "Enable ChangesToDetect so unauthorised changes alter the audit signature.", ""),
    "PLC-CFG-003": ("LOW", "Module inhibited", "CWE-1188",
                    "Remove or document inhibited modules.", ""),
    "PLC-CFG-004": ("MEDIUM", "Electronic keying disabled", "CWE-1188",
                    "Use Exact Match / Compatible Keying.", ""),
    "PLC-CFG-005": ("LOW", "Very large task watchdog", "CWE-400 / CWE-754",
                    "Tune watchdogs to expected scan time.", ""),
    "PLC-CFG-006": ("CRITICAL", "Unauthenticated web server / HTTP diagnostics enabled", "CWE-306 / CWE-200",
                    "Disable the module web server or protect it; it leaks diagnostics without mandatory "
                    "authentication.", "Top20 P13"),
    "PLC-CFG-007": ("CRITICAL", "Cleartext Telnet interface enabled", "CWE-319 / CWE-306",
                    "Disable Telnet; it allows cleartext console configuration access.", "Top20 P13"),
    "PLC-CFG-008": ("HIGH", "Cleartext FTP server enabled", "CWE-319 / CWE-522",
                    "Disable FTP; credentials and files traverse the network unencrypted.", "Top20 P13"),
    "PLC-CFG-009": ("CRITICAL", "Anonymous OPC UA login allowed", "CWE-306 / CWE-287",
                    "Disable anonymous OPC UA; require credentials/certificates.", ""),
    "PLC-CFG-010": ("HIGH", "OPC UA 'None' security policy enabled", "CWE-319",
                    "Disable the None policy; require Sign/SignAndEncrypt.", ""),
    "PLC-CFG-011": ("MEDIUM", "SNMP service enabled (heuristic property name)", "CWE-1188 / CWE-319",
                    "Disable SNMP or restrict to v3 with authentication.", ""),
    "PLC-CFG-012": ("HIGH", "Safety task not locked", "CWE-284 / CWE-693",
                    "Lock the safety task and generate a safety signature before commissioning.", ""),
    # design / modes / restart
    "PLC-MOD-001": ("MEDIUM", "Routine exceeds modular size threshold", "CWE-1120",
                    "Split large routines into smaller reviewable modules.", "Top20 P1"),
    "PLC-MODE-001": ("HIGH", "No tracking of operating mode / CPU keyswitch position", "CWE-693 / CWE-778",
                     "Track the keyswitch (S:KEYS/GSV) and alarm when left in REM/PROG.", "Top20 P2"),
    "PLC-RST-001": ("HIGH", "No first-scan / power-up safe-state initialisation", "CWE-665 / CWE-1188",
                    "Add a first-scan (S:FS) routine that sets a safe process state after restart.",
                    "Top20 P15"),
    "PLC-SES-001": ("HIGH", "Automated session timeout logic missing", "CWE-613",
                    "Add a TON on the access flag and clear password-input / access-granted tags when "
                    ".DN is set.", ""),
    "PLC-ROB-001": ("LOW", "Program has no fault routine", "CWE-703 / CWE-754",
                    "Add a program fault routine that drives outputs safe and logs the fault.", ""),
    "PLC-ROB-002": ("LOW", "Division without visible zero check", "CWE-369",
                    "Guard the divisor before DIV or '/'.", ""),
    "PLC-ROB-003": ("MEDIUM", "Unbounded WHILE/REPEAT loop in Structured Text", "CWE-835 / CWE-400",
                    "Bound loop iterations; a long loop trips the task watchdog and faults the controller.",
                    ""),
    "PLC-INT-001": ("MEDIUM", "Arithmetic without overflow / status-flag integrity check", "CWE-190 / CWE-682",
                    "Check S:V / S:MINOR (or GSV MinorFaultRecord) after math and handle overflow.",
                    "Top20 P4"),
    "PLC-MON-001": ("LOW", "No PLC health monitoring", "CWE-778 / CWE-223",
                    "GSV LastScanTime/MaxScanTime, uptime and MajorFaultRecord; trend them on the HMI.",
                    "Top20 P16-P18"),
    # input validation
    "PLC-INP-001": ("MEDIUM", "Array index without visible bounds check", "CWE-129 / CWE-787",
                    "Clamp the index (LIM/LIMIT) before use, especially if it originates from "
                    "HMI/network.", ""),
    "PLC-INP-002": ("MEDIUM", "COP/CPS/FLL with non-constant length", "CWE-120 / CWE-787",
                    "Validate/clamp length against destination size.", ""),
    "PLC-INP-003": ("LOW", "String manipulation - confirm length validation", "CWE-120 / CWE-20",
                    "Check .LEN against capacity before CONCAT/INSERT/MID/DELETE.", ""),
    "PLC-INP-004": ("CRITICAL", "HMI input reaches a write sink with no validation filter",
                    "CWE-20 / CWE-1284",
                    "Range-check (LIMIT/GEQ/LEQ/...) every HMI-supplied value before MOV/COP/OTE/math.",
                    "Top20 P8"),
    "PLC-INP-005": ("MEDIUM", "HMI input validated only by equality or is a boolean command", "CWE-20",
                    "Add range checks / authorisation and interlocks to HMI commands.", "Top20 P8"),
    "PLC-TMR-001": ("MEDIUM", "Timer/counter preset set from a variable without validation",
                    "CWE-20 / CWE-1284",
                    "Bound-check presets (LIM/LIMIT) before use; never write .PRE directly from HMI.",
                    "Top20 P6"),
    "PLC-PLA-001": ("MEDIUM", "Physical input value used without plausibility/range check",
                    "CWE-20 / CWE-1284",
                    "Range-check analog inputs and cross-check redundant sensors before acting on them.",
                    "Top20 P12"),
    # system / logic integrity
    "PLC-SYS-001": ("MEDIUM", "SSV modifies controller/module attributes at runtime", "CWE-284 / CWE-732",
                    "Review each SSV: restrict triggers, validate values.", ""),
    "PLC-SYS-002": ("MEDIUM", "UID/UIE disables user interrupts", "CWE-833 / CWE-400",
                    "Ensure UID is always paired with UIE.", ""),
    "PLC-SAF-001": ("MEDIUM", "Bypass/override logic combined with safety signal", "CWE-693 / CWE-1220",
                    "Gate bypass behind authentication, time limits and alarms.", ""),
    "PLC-SAF-002": ("HIGH", "Safety/permissive signal forced to a constant", "CWE-693 / CWE-1220",
                    "Never hard-wire a safety, STO or interlock status to TRUE/FALSE. Restore the real signal, "
                    "or gate any bypass behind authentication, a time limit and an alarm.", ""),
    "PLC-LOG-001": ("CRITICAL", "Output coil driven in multiple locations", "CWE-1164 / CWE-662",
                    "Drive each output from exactly one place; use OTL/OTU pairs deliberately.", "Top20 P7"),
    "PLC-LOG-002": ("CRITICAL", "Conflicting output pair driven on the same rung", "CWE-662 / CWE-821",
                    "Never energise opposing outputs together; interlock them.", "Top20 P7"),
    "PLC-LOG-003": ("MEDIUM", "Opposing output without XIO interlock of its counterpart", "CWE-662",
                    "Add an XIO of the opposing output in the rung that drives this one.", "Top20 P7"),
    "PLC-LOG-004": ("MEDIUM", "Latched output never unlatched", "CWE-1164 / CWE-665",
                    "Pair every OTL with an OTU and reset latches to a safe state on first scan.",
                    "Top20 P15"),
    "PLC-DBG-001": ("LOW", "Debug/test/temporary residue present", "CWE-489 / CWE-912",
                    "Remove test/debug/backdoor code before release.", "Top20 P1"),
    "PLC-CODE-001": ("LOW", "Dead / disabled logic (AFI/NOP) or unstructured jumps", "CWE-561 / CWE-1164",
                     "Remove dead code; avoid JMP/LBL. Disabled logic hides baseline tampering.",
                     "Anti-pattern P3"),
    "PLC-CODE-002": ("LOW", "Routine never called (no JSR, not main/fault routine)", "CWE-561",
                     "Remove unused routines; dormant logic can be activated by a single edit.",
                     "Anti-pattern P3"),
    "PLC-CODE-003": ("LOW", "Commented-out logic left in source", "CWE-561 / CWE-615",
                     "Delete disabled code (version control keeps the history). Commented-out logic hides intent "
                     "and can be re-enabled with a one-character edit.", "Anti-pattern P3"),
    "PLC-ACC-004": ("LOW", "Block uses standard (non-optimized) memory access", "CWE-668 / CWE-1188",
                    "Enable 'Optimized block access' unless absolute addressing is required: offset-based access "
                    "is what PUT/GET and address-based HMI reads depend on.", ""),
    "PLC-VER-001": ("MEDIUM", "Controller firmware older than the policy minimum", "CWE-1104 / CWE-1395",
                    "Update the controller firmware to a supported revision, or document the exception. "
                    "Set the policy with the 'min_firmware_major' config key.", ""),
    # scan coverage notes (multi-format front end)
    "PLC-FMT-001": ("LOW", "Limited analysis: proprietary/binary or unstructured format", "Scan coverage",
                    "Only embedded text was analysed. Export the project to an open text format "
                    "(L5K/L5X, PLCopen XML, ST/SCL source) and rescan for full rule coverage.", ""),
    "PLC-FMT-002": ("LOW", "Graphical/unsupported routine language not analysed", "Scan coverage",
                    "Ladder/FBD/SFC/IL content in this format is not parsed; review it manually or "
                    "export it to a supported text form.", ""),
    "PLC-FMT-003": ("INFO", "Archive members skipped", "Scan coverage",
                    "Unsupported, encrypted, oversized or excess members were not scanned; extract and "
                    "scan them separately if needed.", ""),
    "PLC-FMT-004": ("LOW", "File did not parse as its expected format; scanned as plain text",
                    "Scan coverage", "Check the file for corruption or an unexpected variant.", ""),
}

SECRET_TOKENS = {"password", "passwd", "pwd", "passcode", "passphrase", "secret",
                 "token", "apikey", "credential", "credentials", "pin", "login"}
SECRET_SUBSTR = ["apikey", "privatekey", "authkey", "cryptokey", "secretkey", "accesskey"]
DEBUG_SUBSTR = ["_test", "_debug", "_temp_"]   # raw-text residue check in logic (PLC-DBG-001)
SAFETY_TOKENS = {"estop", "safety", "interlock", "guard", "trip", "lockout", "permissive", "sis", "sil"}
BYPASS_TOKENS = {"bypass", "override", "inhibit", "defeat", "mute", "muted", "ignore"}
SENSITIVE_TOKENS = {"setpoint", "sp", "mode", "auth", "authenticated", "authorized", "unlock", "admin",
                    "recipe"}
DEBUG_TOKENS = {"backdoor", "debug", "test", "dbg", "hack", "dummy", "sim", "simulate"}
EXTERNAL_INPUT_TOKENS = {"hmi", "cmd", "req", "request", "sel", "select", "user", "rx", "recv", "ext",
                         "input", "recipe"}
WRITE_SINK_RE = r"\b(OTE|OTL|OTU|MOV|MVM|COP|CPS|FLL|CPT|ADD|SUB|MUL|DIV|SSV)\s*\("
SIEMENS_SAFETY_TOKENS = {"sto", "sls", "ssm", "sbc", "sdi", "sos", "ss1", "ss2", "fsoe", "failsafe", "pilz"}
S7_COMM_RE = re.compile(r"(?<![\w.])(PUT|GET|BSEND|BRCV|USEND|URCV|TCON|TDISCON|TSEND|TRCV|TUSEND|TURCV|"
                        r"TSEND_C|TRCV_C|TMAIL_C|T_CONFIG)\s*[(),]", re.I)
S7_COMM_DECL_RE = re.compile(r":\s*(PUT|GET|BSEND|BRCV|USEND|URCV|TCON(?:_\w+)?|TDISCON|TSEND(?:_C)?|TRCV(?:_C)?|"
                             r"TUSEND|TURCV|TMAIL_C|T_CONFIG)\s*;", re.I)
_CODE_COMMENT_RE = re.compile(r"\s*(?:[#\"A-Za-z_][\w.#\"%\[\]]*\s*(?::=|\()[^;]*;|[#\"A-Za-z_][\w.#\"%\[\]]*\s*;"
                              r"|(?:IF|ELSIF|WHILE|FOR|CASE)\b.*\b(?:THEN|DO|OF)\b|END_(?:IF|FOR|WHILE|CASE)\s*;)", re.I)
_ST_DECL_RE = re.compile(
    r"\b([A-Za-z_]\w*)\s*(?:AT\s+%\S+\s*)?:\s*(?:W?STRING(?:\s*\[[^\]]*\]|\s*\([^)]*\))?|[A-Za-z_]\w*)"
    r"\s*:=\s*('(?:[^'$]|\$.)*'|\"(?:[^\"$]|\$.)*\"|-?\d{3,})\s*;")
SOCKET_RE = re.compile(r"\b(OpenConnection|WriteSocket|ReadSocket|SocketControl|"
                       r"Socket(?:Create|Bind|Listen|Accept|Read|Write|Delete|Connect|Open|Close)\w*)", re.I)


@dataclass
class Finding:
    rule_id: str
    severity: str
    title: str
    location: str
    line: int
    snippet: str
    cwe_guideline: str
    recommendation: str
    practice: str = ""
    confidence: str = ""      # High / Medium / Low: how likely the finding is a true positive
    fingerprint: str = ""      # stable id used by the baseline file (set by scan_file)
    owasp: str = ""            # primary OWASP Top 10 category for the active edition, e.g. "A02:2025 Security Misconfiguration"


# How much to trust a finding. High = a literal instruction/setting was read directly.
# Medium = structural or name-based pattern. Low = absence-based or weak name heuristics.
CONFIDENCE = {
    "PLC-CFG-001": "High", "PLC-CFG-002": "High", "PLC-CFG-003": "High", "PLC-CFG-004": "High",
    "PLC-CFG-005": "High", "PLC-CFG-006": "High", "PLC-CFG-007": "High", "PLC-CFG-008": "High",
    "PLC-CFG-009": "High", "PLC-CFG-010": "High", "PLC-CFG-011": "High", "PLC-CFG-012": "High",
    "PLC-LOG-001": "Medium", "PLC-LOG-002": "High", "PLC-LOG-003": "Medium", "PLC-LOG-004": "Medium",
    "PLC-CRED-001": "Medium", "PLC-CRED-002": "Medium", "PLC-CRED-003": "Medium", "PLC-CRED-004": "Medium",
    "PLC-NET-001": "Medium", "PLC-NET-002": "Low", "PLC-NET-003": "High",
    "PLC-ACC-001": "Medium", "PLC-ACC-002": "Medium", "PLC-ACC-003": "Medium",
    "PLC-INP-001": "Medium", "PLC-INP-002": "Medium", "PLC-INP-003": "Low",
    "PLC-INP-004": "Medium", "PLC-INP-005": "Low",
    "PLC-INT-001": "Medium", "PLC-ROB-001": "High", "PLC-ROB-002": "Medium", "PLC-ROB-003": "Medium",
    "PLC-TMR-001": "Medium", "PLC-PLA-001": "Low",
    "PLC-MODE-001": "Low", "PLC-RST-001": "Low", "PLC-SES-001": "Low", "PLC-MON-001": "Low",
    "PLC-SYS-001": "High", "PLC-SYS-002": "High", "PLC-SAF-001": "Low",
    "PLC-DBG-001": "Low", "PLC-CODE-001": "High", "PLC-CODE-002": "Medium", "PLC-MOD-001": "High",
    "PLC-VER-001": "High", "PLC-SAF-002": "Medium", "PLC-CODE-003": "Medium", "PLC-ACC-004": "High",
}


# ------------------------------------------------------------ OWASP Top 10 mapping
# The OWASP Top 10 describes WEB APPLICATION risks. For PLC code the mapping is by analogy: each rule is
# assigned the category whose weakness family (CWE) or intent it most resembles. One primary category per
# rule, so summaries add up. Not an OWASP certification. Editions: 2021 and 2025 (final, January 2026).
OWASP_NAMES = {
    "2021": {"A01": "Broken Access Control", "A02": "Cryptographic Failures", "A03": "Injection",
             "A04": "Insecure Design", "A05": "Security Misconfiguration",
             "A06": "Vulnerable and Outdated Components", "A07": "Identification and Authentication Failures",
             "A08": "Software and Data Integrity Failures", "A09": "Security Logging and Monitoring Failures",
             "A10": "Server-Side Request Forgery"},
    "2025": {"A01": "Broken Access Control", "A02": "Security Misconfiguration",
             "A03": "Software Supply Chain Failures", "A04": "Cryptographic Failures", "A05": "Injection",
             "A06": "Insecure Design", "A07": "Authentication Failures",
             "A08": "Software or Data Integrity Failures", "A09": "Logging & Alerting Failures",
             "A10": "Mishandling of Exceptional Conditions"},
}
# rule -> (category in 2021, category in 2025)
_OWASP_TABLE = {
    "PLC-CRED-001": ("A07", "A07"), "PLC-CRED-002": ("A07", "A07"), "PLC-CRED-003": ("A07", "A07"),
    "PLC-CRED-004": ("A07", "A07"),
    "PLC-NET-001": ("A05", "A02"), "PLC-NET-002": ("A07", "A07"), "PLC-NET-003": ("A02", "A04"),
    "PLC-ACC-001": ("A01", "A01"), "PLC-ACC-002": ("A01", "A01"), "PLC-ACC-003": ("A01", "A01"),
    "PLC-CFG-001": ("A07", "A07"), "PLC-CFG-002": ("A08", "A08"), "PLC-CFG-003": ("A05", "A02"),
    "PLC-CFG-004": ("A05", "A02"), "PLC-CFG-005": ("A05", "A02"), "PLC-CFG-006": ("A05", "A02"),
    "PLC-CFG-007": ("A02", "A04"), "PLC-CFG-008": ("A02", "A04"), "PLC-CFG-009": ("A07", "A07"),
    "PLC-CFG-010": ("A02", "A04"), "PLC-CFG-011": ("A05", "A02"), "PLC-CFG-012": ("A01", "A01"),
    "PLC-MOD-001": ("A04", "A06"), "PLC-MODE-001": ("A09", "A09"), "PLC-RST-001": ("A04", "A06"),
    "PLC-SES-001": ("A07", "A07"), "PLC-ROB-001": ("A04", "A10"), "PLC-ROB-002": ("A04", "A10"),
    "PLC-ROB-003": ("A04", "A10"), "PLC-INT-001": ("A04", "A10"), "PLC-MON-001": ("A09", "A09"),
    "PLC-INP-001": ("A03", "A05"), "PLC-INP-002": ("A03", "A05"), "PLC-INP-003": ("A03", "A05"),
    "PLC-INP-004": ("A03", "A05"), "PLC-INP-005": ("A03", "A05"), "PLC-TMR-001": ("A03", "A05"),
    "PLC-PLA-001": ("A03", "A05"), "PLC-SYS-001": ("A01", "A01"), "PLC-SYS-002": ("A04", "A10"),
    "PLC-SAF-001": ("A04", "A06"), "PLC-LOG-001": ("A04", "A06"), "PLC-LOG-002": ("A04", "A06"),
    "PLC-LOG-003": ("A04", "A06"), "PLC-LOG-004": ("A04", "A06"), "PLC-DBG-001": ("A05", "A02"),
    "PLC-CODE-001": ("A04", "A06"), "PLC-CODE-002": ("A04", "A06"), "PLC-VER-001": ("A06", "A03"),
    "PLC-SAF-002": ("A04", "A06"), "PLC-CODE-003": ("A04", "A06"), "PLC-ACC-004": ("A05", "A02"),
}
OWASP_MAP = {rid: {"2021": a, "2025": b} for rid, (a, b) in _OWASP_TABLE.items()}
OWASP_STATE = {"edition": "2025"}


def set_owasp_edition(edition):
    edition = str(edition)
    if edition not in OWASP_NAMES:
        raise ValueError(f"OWASP edition must be one of {', '.join(sorted(OWASP_NAMES))}")
    OWASP_STATE["edition"] = edition


def owasp_code(rule, edition=None):
    return OWASP_MAP.get(rule, {}).get(edition or OWASP_STATE["edition"], "")


def owasp_label(rule, edition=None):
    """e.g. 'A02:2025 Security Misconfiguration'; '' for rules without a mapping (scan-coverage notes)."""
    ed = edition or OWASP_STATE["edition"]
    code = owasp_code(rule, ed)
    return f"{code}:{ed} {OWASP_NAMES[ed][code]}" if code else ""


def relabel_owasp(findings, edition=None):
    """Re-label findings after the edition changes (the label is a function of the rule id)."""
    for f in findings:
        f.owasp = owasp_label(f.rule_id, edition)
    return findings


def owasp_summary(findings, edition=None):
    """[(code, name, count)] for all ten categories of the edition, zero counts included."""
    ed = edition or OWASP_STATE["edition"]
    counts = {c: 0 for c in OWASP_NAMES[ed]}
    for f in findings:
        c = owasp_code(f.rule_id, ed)
        if c:
            counts[c] += 1
    return [(c, OWASP_NAMES[ed][c], counts[c]) for c in OWASP_NAMES[ed]]


def owasp_coverage(edition=None):
    """{code: [rule ids that map to it]} for all ten categories of the edition."""
    ed = edition or OWASP_STATE["edition"]
    cov = {c: [] for c in OWASP_NAMES[ed]}
    for rid in sorted(OWASP_MAP):
        c = owasp_code(rid, ed)
        if c in cov:
            cov[c].append(rid)
    return cov


# ------------------------------------------------------------ rules file
# A rules file lets you tune the rule set without editing code (see README, "Rules file").
# All tables below are mutated in place, so every function that reads them sees the change.
import copy as _copy

TOKEN_SETS = {"secret": SECRET_TOKENS, "safety": SAFETY_TOKENS, "bypass": BYPASS_TOKENS,
              "sensitive": SENSITIVE_TOKENS, "debug": DEBUG_TOKENS, "external_input": EXTERNAL_INPUT_TOKENS}
LIST_GROUPS = {"secret_substrings": SECRET_SUBSTR, "debug_substrings": DEBUG_SUBSTR}
DISABLED = set()        # rule ids that never produce findings
SEVERITY_LOCK = set()   # rules whose severity was overridden: the override beats context-based escalation
ACTIVE_RULES = {"name": "", "sha256": "", "disabled": 0, "overridden": 0, "patterns": 0, "tokens": 0}
_DEFAULTS = {"rules": _copy.deepcopy(RULES), "confidence": dict(CONFIDENCE), "cfg_params": list(CFG_PARAMS),
             "tokens": {k: set(v) for k, v in TOKEN_SETS.items()},
             "lists": {k: list(v) for k, v in LIST_GROUPS.items()},
             "opposites": list(OPPOSITES), "owasp": _copy.deepcopy(OWASP_MAP)}
_RULES_FILE_KEYS = {"version", "_comment", "disable", "overrides", "cfg_params", "tokens"}
_OVERRIDE_KEYS = {"severity", "lock_severity", "title", "cwe", "recommendation", "practice", "confidence", "owasp",
                  "_comment"}
# rules whose severity the scanner raises/lowers by context (public IP, external input, ...)
DYNAMIC_SEVERITY_RULES = ("PLC-INP-001", "PLC-LOG-001", "PLC-NET-001", "PLC-TMR-001")
_TOKEN_RE = re.compile(r"[a-z0-9]+")
_SUBSTR_RE = re.compile(r"[a-z0-9_]{2,}")


def reset_rules():
    """Restore the built-in rule set."""
    RULES.clear()
    RULES.update(_copy.deepcopy(_DEFAULTS["rules"]))
    CONFIDENCE.clear()
    CONFIDENCE.update(_DEFAULTS["confidence"])
    CFG_PARAMS[:] = _DEFAULTS["cfg_params"]
    for k, tokens in TOKEN_SETS.items():
        tokens.clear()
        tokens.update(_DEFAULTS["tokens"][k])
    for k, items in LIST_GROUPS.items():
        items[:] = _DEFAULTS["lists"][k]
    OPPOSITES[:] = _DEFAULTS["opposites"]
    OWASP_MAP.clear()
    OWASP_MAP.update(_copy.deepcopy(_DEFAULTS["owasp"]))
    DISABLED.clear()
    SEVERITY_LOCK.clear()
    ACTIVE_RULES.update({"name": "", "sha256": "", "disabled": 0, "overridden": 0, "patterns": 0, "tokens": 0})


def load_rules(path):
    """Read and validate a rules file. Raises ValueError listing every problem found."""
    if os.path.getsize(path) > 1024 * 1024:
        raise ValueError("rules file is larger than 1 MB")
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        data = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"not valid JSON: {exc}")
    known = _DEFAULTS["rules"]
    errs = []
    if not isinstance(data, dict):
        raise ValueError("top level must be a JSON object")
    for k in data:
        if k not in _RULES_FILE_KEYS:
            errs.append(f"unknown top-level key '{k}' (allowed: {', '.join(sorted(_RULES_FILE_KEYS - {'_comment'}))})")
    disable = data.get("disable", [])
    if not isinstance(disable, list):
        errs.append("'disable' must be a list of rule ids")
        disable = []
    for rid in disable:
        if rid not in known:
            errs.append(f"disable: unknown rule '{rid}'")
    overrides = data.get("overrides", {})
    if not isinstance(overrides, dict):
        errs.append("'overrides' must be an object of rule id -> settings")
        overrides = {}
    norm = {}
    for rid, ov in overrides.items():
        if rid not in known:
            errs.append(f"overrides: unknown rule '{rid}'")
            continue
        if not isinstance(ov, dict):
            errs.append(f"overrides.{rid}: must be an object")
            continue
        o = {}
        for k, v in ov.items():
            if k not in _OVERRIDE_KEYS:
                errs.append(f"overrides.{rid}: unknown key '{k}' (allowed: {', '.join(sorted(_OVERRIDE_KEYS - {'_comment'}))})")
            elif k == "_comment":
                continue
            elif k == "severity":
                if not isinstance(v, str) or v.upper() not in SEV_ORDER:
                    errs.append(f"overrides.{rid}.severity '{v}' must be one of {', '.join(SEV_ORDER)}")
                else:
                    o[k] = v.upper()
            elif k == "owasp":
                if not isinstance(v, dict) or not v or set(v) - set(OWASP_NAMES):
                    errs.append(f"overrides.{rid}.owasp must be an object like {{\"2021\": \"A05\", \"2025\": \"A02\"}}")
                else:
                    bad = [f"{ed}:{c}" for ed, c in v.items() if c not in OWASP_NAMES[ed]]
                    if bad:
                        errs.append(f"overrides.{rid}.owasp: unknown categor{'y' if len(bad) == 1 else 'ies'} {', '.join(bad)}")
                    else:
                        o[k] = dict(v)
            elif k == "lock_severity":
                if not isinstance(v, bool):
                    errs.append(f"overrides.{rid}.lock_severity must be true or false")
                else:
                    o[k] = v
            elif k == "confidence":
                if not isinstance(v, str) or v.capitalize() not in ("High", "Medium", "Low"):
                    errs.append(f"overrides.{rid}.confidence '{v}' must be High, Medium or Low")
                else:
                    o[k] = v.capitalize()
            elif not isinstance(v, str) or len(v) > 600:
                errs.append(f"overrides.{rid}.{k} must be text of at most 600 characters")
            else:
                o[k] = v
        norm[rid] = o
    patterns = []
    plist = data.get("cfg_params", [])
    if not isinstance(plist, list):
        errs.append("'cfg_params' must be a list of {\"rule\": ..., \"pattern\": ...}")
        plist = []
    for n, item in enumerate(plist, 1):
        if not isinstance(item, dict) or set(item) - {"rule", "pattern", "_comment"} or \
                not isinstance(item.get("rule"), str) or not isinstance(item.get("pattern"), str):
            errs.append(f"cfg_params[{n}]: needs text fields 'rule' and 'pattern' only")
            continue
        if item["rule"] not in known:
            errs.append(f"cfg_params[{n}]: unknown rule '{item['rule']}'")
        elif len(item["pattern"]) > 300:
            errs.append(f"cfg_params[{n}]: pattern longer than 300 characters")
        else:
            try:
                re.compile(item["pattern"])
                patterns.append((item["rule"], item["pattern"]))
            except re.error as exc:
                errs.append(f"cfg_params[{n}]: invalid regular expression ({exc})")
    tokens = {}
    tspec = data.get("tokens", {})
    if not isinstance(tspec, dict):
        errs.append("'tokens' must be an object")
        tspec = {}
    for group, ops in tspec.items():
        if group != "opposites" and group not in TOKEN_SETS and group not in LIST_GROUPS:
            allowed = sorted(TOKEN_SETS) + sorted(LIST_GROUPS) + ["opposites"]
            errs.append(f"tokens: unknown group '{group}' (allowed: {', '.join(allowed)})")
            continue
        if not isinstance(ops, dict) or set(ops) - {"add", "remove"}:
            errs.append(f"tokens.{group}: use only 'add' and/or 'remove' lists")
            continue
        clean = {}
        for op, items in ops.items():
            if not isinstance(items, list):
                errs.append(f"tokens.{group}.{op} must be a list")
                continue
            vals = []
            for it in items:
                if group == "opposites":
                    ok = isinstance(it, list) and len(it) == 2 and all(isinstance(x, str) and _TOKEN_RE.fullmatch(x) for x in it)
                    (vals.append(tuple(it)) if ok else errs.append(f"tokens.opposites.{op}: each item must be two lowercase words, e.g. [\"raise\", \"lower\"]"))
                elif group in LIST_GROUPS:
                    ok = isinstance(it, str) and _SUBSTR_RE.fullmatch(it)
                    (vals.append(it) if ok else errs.append(f"tokens.{group}.{op}: '{it}' must be lowercase letters, digits or _ (at least 2 characters)"))
                else:
                    ok = isinstance(it, str) and _TOKEN_RE.fullmatch(it)
                    (vals.append(it) if ok else errs.append(f"tokens.{group}.{op}: '{it}' must be one lowercase word without spaces or underscores"))
            clean[op] = vals
        tokens[group] = clean
    if errs:
        raise ValueError("\n  - " + "\n  - ".join(errs[:15]) + (f"\n  ... and {len(errs) - 15} more" if len(errs) > 15 else ""))
    import hashlib as _h
    return {"disable": list(disable), "overrides": norm, "cfg_params": patterns, "tokens": tokens,
            "name": os.path.basename(path), "sha256": _h.sha256(raw).hexdigest()}


def apply_rules(spec):
    """Apply a validated rules spec on top of the built-in rules (replacing any earlier rules file)."""
    reset_rules()
    for rid, ov in spec["overrides"].items():
        sev, title, cwe, rec, practice = RULES[rid]
        new_sev = ov.get("severity", sev)
        RULES[rid] = (new_sev, ov.get("title", title), ov.get("cwe", cwe),
                      ov.get("recommendation", rec), ov.get("practice", practice))
        if new_sev != sev or ov.get("lock_severity"):
            SEVERITY_LOCK.add(rid)
        if "confidence" in ov:
            CONFIDENCE[rid] = ov["confidence"]
        if "owasp" in ov:
            OWASP_MAP[rid] = {**OWASP_MAP.get(rid, {}), **ov["owasp"]}
    DISABLED.update(spec["disable"])
    CFG_PARAMS.extend(spec["cfg_params"])
    n_tokens = 0
    for group, ops in spec["tokens"].items():
        if group == "opposites":
            for pair in ops.get("remove", []):
                OPPOSITES[:] = [p for p in OPPOSITES if set(p) != set(pair)]
            for pair in ops.get("add", []):
                if not any(set(p) == set(pair) for p in OPPOSITES):
                    OPPOSITES.append(pair)
            n_tokens += len(ops.get("add", [])) + len(ops.get("remove", []))
        else:
            if group in LIST_GROUPS:
                target = LIST_GROUPS[group]
                target[:] = [x for x in target if x not in ops.get("remove", [])]
                target.extend(x for x in ops.get("add", []) if x not in target)
            else:
                target = TOKEN_SETS[group]
                target.difference_update(ops.get("remove", []))
                target.update(ops.get("add", []))
            n_tokens += len(ops.get("add", [])) + len(ops.get("remove", []))
    ACTIVE_RULES.update({"name": spec["name"], "sha256": spec["sha256"], "disabled": len(spec["disable"]),
                         "overridden": len(spec["overrides"]), "patterns": len(spec["cfg_params"]),
                         "tokens": n_tokens})
    return dict(ACTIVE_RULES)


def dump_rules(path):
    """Write an editable template listing every built-in rule with its current default settings."""
    ov = {}
    for rid, (sev, title, cwe, rec, practice) in _DEFAULTS["rules"].items():
        ov[rid] = {"severity": sev, "confidence": _DEFAULTS["confidence"].get(rid, "Medium"), "title": title,
                   "cwe": cwe, "recommendation": rec, "practice": practice}
        if rid in _DEFAULTS["owasp"]:
            ov[rid]["owasp"] = dict(_DEFAULTS["owasp"][rid])
        if rid in DYNAMIC_SEVERITY_RULES:   # severity is raised/lowered by context unless locked
            ov[rid]["lock_severity"] = False
    tpl = {"_comment": "Edit or delete entries. Everything here equals the built-in defaults, so an unedited "
                       "file changes nothing. Add rule ids to 'disable' to switch them off.",
           "version": 1, "disable": [], "overrides": ov, "cfg_params": [], "tokens": {}}
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(tpl, fh, indent=2, ensure_ascii=False)
    return len(ov)


# ------------------------------------------------------------ text helpers
def take_parens(s):
    """Return (inside, remainder, closed) for the first balanced (...) in s."""
    depth, i, q, start = 0, 0, None, None
    while i < len(s):
        c = s[i]
        if q:
            if c == "$":
                i += 2
                continue
            if c == q:
                q = None
        else:
            if c in "\"'":
                q = c
            elif c == "(":
                if depth == 0:
                    start = i + 1
                depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0:
                    return s[start:i], s[i + 1:], True
        i += 1
    return (s[start:] if start is not None else ""), "", False


def split_args(s):
    out, cur, depth, q, i = [], [], 0, None, 0
    while i < len(s):
        c = s[i]
        if q:
            cur.append(c)
            if c == "$" and i + 1 < len(s):
                cur.append(s[i + 1])
                i += 2
                continue
            if c == q:
                q = None
        elif c in "\"'":
            q = c
            cur.append(c)
        elif c in "([":
            depth += 1
            cur.append(c)
        elif c in ")]":
            depth -= 1
            cur.append(c)
        elif c == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(c)
        i += 1
    if cur or out:
        out.append("".join(cur).strip())
    return out


def top_level_semicolon(s):
    q, i = None, 0
    while i < len(s):
        c = s[i]
        if q:
            if c == "$":
                i += 2
                continue
            if c == q:
                q = None
        elif c in "\"'":
            q = c
        elif c == ";":
            return i
        i += 1
    return -1


def attr(text, name):
    m = re.search(r"\b" + re.escape(name) + r'\s*:=\s*("(?:[^"$]|\$.)*"|[^,\s)]+)', text)
    return m.group(1).strip('"') if m else None


def strip_comments(t):
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    t = re.sub(r"\(\*.*?\*\)", "", t, flags=re.S)
    return re.sub(r"//.*$", "", t, flags=re.M)


def mask_strings(t):
    return re.sub(r"'(?:[^'$]|\$.)*'", "''", t)


def token_list(name):
    return [t.lower() for t in re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+", name)]


def name_tokens(name):
    toks = set(token_list(name))
    if "estop" in name.lower():  # CamelCase splitting breaks "EStop"
        toks.add("estop")
    return toks


def is_secret_name(n):
    low = n.lower()
    return bool(name_tokens(n) & SECRET_TOKENS) or any(s in low for s in SECRET_SUBSTR)


def base_name(t):
    return re.split(r"[.\[]", t.strip(), maxsplit=1)[0]


def opposite(a, b):
    la, lb = token_list(base_name(a)), token_list(base_name(b))
    if len(la) != len(lb) or la == lb:
        return False
    diff = [(x, y) for x, y in zip(la, lb) if x != y]
    return len(diff) == 1 and any(set(diff[0]) == set(p) for p in OPPOSITES)


def opposite_path(a, b):
    """Like opposite(), for full member paths: same parent path, opposing last member (Cmd.Open / Cmd.Close)."""
    pa, pb = re.sub(r"\s+", "", a).split("."), re.sub(r"\s+", "", b).split(".")
    return len(pa) == len(pb) and pa[:-1] == pb[:-1] and opposite(pa[-1], pb[-1])


def guarded(var, text, zero_check=False):
    e = re.escape(var)
    ops = "LIM|LES|LEQ|GRT|GEQ|CMP" + ("|NEQ|EQU" if zero_check else "")
    pats = [rf"\b({ops})\s*\([^;]*?\b{e}\b",
            rf"\b{e}\b\s*(<=|>=|<>|<|>{'|=' if zero_check else ''})",
            rf"(<=|>=|<>|<|>)\s*{e}\b",
            rf"\bFOR\s+{e}\s*:=",
            rf"\bLIMIT\s*\([^;]*\b{e}\b",
            rf"\bMOD\b[^;]*\b{e}\b"]
    return any(re.search(p, text, re.I) for p in pats)


def calls(code, names):
    for m in re.finditer(r"\b(" + "|".join(names) + r")\s*\(", code, re.I):
        inside, _, _ = take_parens(code[m.end() - 1:])
        yield m.group(1).upper(), split_args(inside)


def contains_any(text, kws):
    low = text.lower()
    return any(k.lower() in low for k in kws)


def is_external(v):
    b = base_name(v)
    return bool(name_tokens(b) & EXTERNAL_INPUT_TOKENS) or \
        any(b.lower().startswith(p.lower()) for p in CONFIG["hmi_prefixes"])


# ------------------------------------------------------------ scanner
class Scanner:
    def __init__(self, path, strict=False, lines=None, line_map=None, generic=False,
                 raw=False, ctx_labels=None, ip_note="", siemens=False):
        """lines/line_map let the multi-format front end feed pre-converted text:
        line_map[i] is the original line number for synthetic line i+1 (0 = unknown).
        generic=True disables Logix-only absence checks; raw=True only runs the text scans
        (credentials in strings/comments, IPs, insecure-service parameters)."""
        self.path, self.strict = path, strict
        if lines is None:
            with open(path, "rb") as f:
                lines = decode_text(f.read()).splitlines()
        self.lines = lines
        self.n = len(self.lines)
        self.line_map, self.generic, self.raw, self.ip_note = line_map, generic, raw, ip_note
        # siemens=True: input is Siemens SCL / SimaticML already normalised to plain ST (see _scl_normalize).
        # Tags are then identified by their full member path (UDT members are distinct bits) per block.
        self.siemens = self.exact = siemens
        self.ip_seen = set()
        self.ctx = [""] * (self.n + 2)
        if ctx_labels:
            self.ctx[1:1 + len(ctx_labels)] = ctx_labels
        self.findings = {}
        self.cur_prog = ""
        self.prog_tags = set()      # (program, tag)
        self.coils = {}             # qualified tag -> [(instr, location, rung, line)]
        self.corpus = []            # (line, raw, masked-code) for whole-file architectural checks
        self.orphans = []
        self.latched = {}           # qualified tag -> (line, location, raw) of first OTL
        self.unlatched = set()
        self.routines = []          # (program, routine, line, location)
        self.called = set()         # (program, routine) reached by JSR or as main/fault routine
        self.prog_state = {}        # program -> header info; fault-routine check runs when the block ends

    # -- reporting
    def add(self, rule, line, location, snippet, severity=None, extra=""):
        if rule in DISABLED:
            return
        sev, title, cwe, rec, practice = RULES[rule]
        if rule in SEVERITY_LOCK:
            severity = None  # a severity set in the rules file always wins
        if self.line_map is not None and line > 0:
            line = self.line_map[line - 1] if line - 1 < len(self.line_map) else 0
        key = (rule, location, line)
        if key in self.findings:
            return
        if self.generic:   # comments that precede a statement belong to the previous lines, not to this finding
            trimmed = re.sub(r"\A\s*(?:(?://[^\n]*(?:\n|\Z)|\(\*.*?\*\))\s*)+", "", snippet, flags=re.S)
            snippet = trimmed if trimmed.strip() else snippet
        self.findings[key] = Finding(rule, severity or sev, title + (f" ({extra})" if extra else ""),
                                     location, line, " ".join(snippet.split())[:200], cwe, rec, practice,
                                     CONFIDENCE.get(rule, "Medium"), owasp=owasp_label(rule))

    def where(self, routine="", rung=""):
        parts = []
        if self.cur_prog:
            parts.append(f"Program:{self.cur_prog}")
        if routine:
            parts.append(f"Routine:{routine}")
        if rung != "":
            parts.append(f"Rung:{rung}")
        return "/".join(parts) or "Controller"

    def read_header(self, i):
        buf, j = self.lines[i], i
        while "(" in buf:
            _, _, closed = take_parens(buf[buf.index("("):])
            if closed or j + 1 >= self.n or j - i > 300:
                break
            j += 1
            buf += " " + self.lines[j].strip()
        return buf, j

    # -- main parse loop
    def parse(self):
        if self.raw:
            self.config_scan()
            self.global_scans()
            return sorted(self.findings.values(), key=lambda f: (SEV_ORDER[f.severity], f.line))
        i = 0
        skip_prefix = ("//", "RC:") if self.generic else ("//", "#", "RC:")
        self.skip_prefix = skip_prefix
        while i < self.n:
            s = self.lines[i].strip()
            self.ctx[i + 1] = self.where()
            m = re.match(r"(CONTROLLER|MODULE|PROGRAM|TASK|ROUTINE|TAG|END_PROGRAM)\b\s*(\S*)", s)
            if not m:
                mf = re.match(r"(MAIN|FAULT)\s*(?::=)?\s*([A-Za-z_]\w*)\s*;?$", s)
                if mf and self.cur_prog:  # older L5K: `MAIN name;` / `FAULT name;` lines inside PROGRAM
                    self.called.add((self.cur_prog, mf.group(2)))
                    if mf.group(1) == "FAULT" and self.cur_prog in self.prog_state:
                        self.prog_state[self.cur_prog]["fault"] = True
                    i += 1
                    continue
                if re.match(r"RUNG\s+\d+", s, re.I):  # rung outside any ROUTINE block
                    rest = s
                    while (k := top_level_semicolon(rest)) >= 0:
                        self.orphans.append((i + 1, rest[:k + 1].strip()))
                        rest = rest[k + 1:].strip()
                i += 1
                continue
            kw, name = m.group(1), m.group(2)
            if kw == "END_PROGRAM":
                self.finish_program()
                self.cur_prog = ""
                i += 1
            elif kw in ("CONTROLLER", "MODULE", "TASK", "PROGRAM"):
                hdr, j = self.read_header(i)
                if kw == "CONTROLLER":
                    self.check_controller(hdr, i + 1)
                elif kw == "MODULE":
                    self.check_module(name, hdr, i + 1)
                elif kw == "TASK":
                    self.check_task(name, hdr, i + 1)
                else:
                    self.finish_program()
                    self.cur_prog = name
                    self.check_program(name, hdr, i + 1)
                i = j + 1
            elif kw == "TAG":
                i = self.parse_tags(i)
            else:
                i = self.parse_routine(i, name)
        self.finish_program()
        if self.orphans:
            self.analyze_routine("(no ROUTINE block)", [(ln, t) for ln, t in self.orphans], 1)
        self.config_scan()
        self.global_scans()
        self.firmware_check()
        self.architecture_checks()
        if self.siemens:
            self.siemens_scan()
        return sorted(self.findings.values(), key=lambda f: (SEV_ORDER[f.severity], f.line))

    # -- config checks
    def check_controller(self, hdr, ln):
        sc = attr(hdr, "SecurityCode")
        if sc is not None and sc.strip() in ("0", "16#0000"):
            self.add("PLC-CFG-001", ln, "Controller", f"SecurityCode := {sc}")
        ctd = attr(hdr, "ChangesToDetect")
        if ctd is not None:
            digits = ctd.replace("16#", "").replace("_", "")
            if digits and set(digits) <= {"0"}:
                self.add("PLC-CFG-002", ln, "Controller", f"ChangesToDetect := {ctd}")
        sig = attr(hdr, "SignatureRunModeProtect")
        if sig is not None and sig.strip() == "0":
            self.add("PLC-CFG-002", ln, "Controller", "SignatureRunModeProtect := 0",
                     extra="run-mode signature protection off")

    def check_module(self, name, hdr, ln):
        loc = f"Module:{name}"
        if (attr(hdr, "Inhibited") or "0").strip() in ("1", "Yes", "true"):
            self.add("PLC-CFG-003", ln, loc, "Inhibited := 1")
        m = re.search(r"\b(?:E?Keying|EKey)\s*:=\s*(\w+)", hdr)
        if m and m.group(1).lower() in ("disabled", "0"):
            self.add("PLC-CFG-004", ln, loc, m.group(0))
        if name_tokens(name) & DEBUG_TOKENS:
            self.add("PLC-DBG-001", ln, loc, name)

    def check_task(self, name, hdr, ln):
        wd = attr(hdr, "Watchdog")
        if wd and wd.isdigit() and int(wd) >= 2000:
            self.add("PLC-CFG-005", ln, f"Task:{name}", f"Watchdog := {wd} ms")

    def check_program(self, name, hdr, ln):
        fr = attr(hdr, "FaultRoutineName") or attr(hdr, "FaultRoutine")
        for entry in (attr(hdr, "MainRoutineName"), fr):
            if entry:
                self.called.add((name, entry))
        for m in re.finditer(r"\b\w*RoutineName\s*:=\s*([^,\s)]+)", hdr):
            self.called.add((name, m.group(1).strip('"')))
        has_fault = bool(fr) and fr.lower() not in ("<na>", "<none>")
        self.prog_state[name] = {"ln": ln, "hdr": hdr[:120], "fault": has_fault}
        if name_tokens(name) & DEBUG_TOKENS:
            self.add("PLC-DBG-001", ln, f"Program:{name}", name)

    def firmware_check(self):
        """Policy check: report firmware whose major revision is below CONFIG['min_firmware_major']."""
        try:
            floor = int(CONFIG.get("min_firmware_major", 0) or 0)
        except (TypeError, ValueError):
            return
        if self.generic or self.raw or floor <= 0:
            return
        for i, line in enumerate(self.lines[:300], 1):
            m = re.match(r"\s*MAJOR\s+(\d+)\s*$", line) or re.search(r"\bMajorRev\s*:=\s*\"?(\d+)", line)
            if m:
                if int(m.group(1)) < floor:
                    self.add("PLC-VER-001", i, "Controller", line.strip()[:120],
                             extra=f"firmware major {m.group(1)}, policy minimum {floor}")
                return

    def finish_program(self):
        """Emit the missing-fault-routine finding once the whole PROGRAM block has been read."""
        st = self.prog_state.pop(self.cur_prog, None) if self.cur_prog else None
        if st and not self.generic and not st["fault"]:
            self.add("PLC-ROB-001", st["ln"], f"Program:{self.cur_prog}", st["hdr"])

    def config_scan(self):
        """Insecure service parameters anywhere in the file (module or controller scope)."""
        module = ""
        for idx, line in enumerate(self.lines, 1):
            s = line.strip()
            if s.startswith("//") or s.startswith("#"):
                continue
            mm = re.match(r"MODULE\s+(\w+)", s, re.I)
            if mm:
                module = mm.group(1)
            for rule, pat in CFG_PARAMS:
                for m in re.finditer(pat, s):
                    loc = f"Module:{module}" if module else "Controller"
                    self.add(rule, idx, loc, m.group(0))
            if "END_MODULE" in s:
                module = ""

    # -- tags
    def parse_tags(self, i):
        j, buf, start = i + 1, [], None
        while j < self.n and not re.match(r"\s*END_TAG", self.lines[j]):
            l = self.lines[j]
            self.ctx[j + 1] = self.where()
            if l.strip():
                start = j if start is None else start
                buf.append(l.strip())
                if l.rstrip().endswith(";"):
                    self.check_tag(" ".join(buf), start + 1)
                    buf, start = [], None
            j += 1
        return j + 1

    def check_tag(self, stmt, ln):
        m = re.match(r"\s*([A-Za-z_]\w*)\s*:\s*([^\s(:=]+)\s*", stmt)
        if not m:
            return
        name, dtype = m.group(1), m.group(2)
        if self.cur_prog:
            self.prog_tags.add((self.cur_prog, name))
        rest, attrs = stmt[m.end():], ""
        if rest.startswith("("):
            attrs, rest, _ = take_parens(rest)
        value = rest.split(":=", 1)[1].strip().rstrip(";") if ":=" in rest else ""
        loc = self.where() + f"/Tag:{name}"
        toks = name_tokens(name)
        ext = (attr(attrs, "ExternalAccess") or "Read/Write").strip().lower()

        if is_secret_name(name):
            text = ""
            sm = re.search(r"'((?:[^'$]|\$.)*)'", value)
            if sm:
                text = re.sub(r"\$[0-9A-Fa-f]{2}|\$.", "", sm.group(1)).strip()
            numeric = dtype.upper() in ("DINT", "INT", "SINT", "LINT") and re.fullmatch(r"-?\d+", value or "")
            if text or (numeric and int(value) != 0):
                self.add("PLC-CRED-001", ln, loc, f"{name} : {dtype} := <redacted>")
            if ext != "none":
                self.add("PLC-ACC-003", ln, loc, f"{name} ExternalAccess={ext}")
        if toks & SAFETY_TOKENS or toks & BYPASS_TOKENS:
            if ext == "read/write":
                self.add("PLC-ACC-001", ln, loc, f"{name} ExternalAccess=Read/Write")
        elif toks & SENSITIVE_TOKENS and ext == "read/write":
            self.add("PLC-ACC-002", ln, loc, f"{name} ExternalAccess=Read/Write")
        if toks & DEBUG_TOKENS and not is_secret_name(name):
            self.add("PLC-DBG-001", ln, loc, name)

    # -- routines
    def parse_routine(self, i, rname):
        if name_tokens(rname) & DEBUG_TOKENS:
            self.add("PLC-DBG-001", i + 1, self.where(rname), f"routine {rname}")
        self.routines.append((self.cur_prog, rname, i + 1, self.where(rname)))
        j, pending, pstart, stmts, sep = i + 1, "", i + 2, [], " "
        while j < self.n and not re.match(r"\s*END_ROUTINE", self.lines[j]):
            t = self.lines[j].strip()
            self.ctx[j + 1] = self.where(rname)
            if t and not t.startswith(self.skip_prefix) and not re.fullmatch(r"(END_)?[A-Z_]+_CONTENT", t):
                if not strip_comments(pending).strip():   # only comment residue left: a new statement starts here
                    pstart = j + 1
                pending += sep + t
                # a trailing // comment must end at its own line break, or it would swallow the next statement
                sep = "\n" if "//" in t else " "
                while (k := top_level_semicolon(pending)) >= 0:
                    stmts.append((pstart, pending[:k + 1].strip()))
                    pending, pstart = pending[k + 1:], j + 1
            j += 1
        if pending.strip():
            stmts.append((pstart, pending.strip()))
        self.analyze_routine(rname, stmts, i + 1)
        return j + 1

    def qualify(self, tag):
        if self.exact:
            return (self.cur_prog, re.sub(r"\s+", "", tag).lower())
        b = base_name(tag)
        return (self.cur_prog, b) if (self.cur_prog, b) in self.prog_tags else b

    def analyze_routine(self, rname, raw_stmts, start_line):
        # label rungs (supports "RUNG n ..." and "N: ..." / "12: ..." dialects)
        stmts, seq = [], 0
        for ln, text in raw_stmts:
            m = re.match(r"\s*(?:RUNG\s+(\d+)|N\s*:|(\d+)\s*:)", text, re.I)
            label = ""
            if m:
                seq += 1
                label = m.group(1) or m.group(2) or str(seq - 1)
            stmts.append((ln, text, label))
        if seq > CONFIG["rung_max"] and not self.generic:
            self.add("PLC-MOD-001", start_line, self.where(rname),
                     f"{seq} rungs (limit {CONFIG['rung_max']})")

        clean = [(ln, raw, mask_strings(strip_comments(raw)), lab) for ln, raw, lab in stmts]
        for ln, raw, code, lab in clean:
            self.corpus.append((ln, raw, code))
        full = "\n".join(c for _, _, c, _ in clean)
        noisy = {"PLC-INP-003": [], "PLC-CODE-001": []}
        seen_idx, coil_rungs = set(), {}

        for ln, raw, code, lab in clean:
            loc = self.where(rname, lab)
            guard_text = code if self.strict else full

            for name, args in calls(code, ["MSG", "SSV", "UID", "UIE", "COP", "CPS", "FLL", "DIV", "MOV", "EQU",
                                           "CONCAT", "INSERT", "MID", "DELETE", "JMP", "LBL", "OTE", "OTL",
                                           "OTU", "JSR"]):
                if name == "MSG":
                    self.add("PLC-NET-002", ln, loc, raw)
                elif name == "SSV":
                    self.add("PLC-SYS-001", ln, loc, raw)
                elif name in ("UID", "UIE"):
                    self.add("PLC-SYS-002", ln, loc, raw)
                elif name in ("COP", "CPS", "FLL") and len(args) >= 3 and not re.fullmatch(r"\d+", args[2]):
                    self.add("PLC-INP-002", ln, loc, raw)
                elif name == "DIV" and len(args) >= 2 and not re.fullmatch(r"[\d.]+", args[1]):
                    if not guarded(args[1], guard_text, zero_check=True):
                        self.add("PLC-ROB-002", ln, loc, raw)
                elif name == "MOV" and len(args) >= 2 and is_secret_name(base_name(args[1])) \
                        and re.fullmatch(r"\d{3,}|'.+'", args[0]):
                    self.add("PLC-CRED-003", ln, loc, f"MOV(<literal>,{args[1]})")
                elif name == "EQU" and len(args) >= 2 and any(is_secret_name(base_name(a)) for a in args[:2]) \
                        and any(re.fullmatch(r"\d{3,}|'.+'", a) for a in args[:2]):
                    self.add("PLC-CRED-003", ln, loc, "EQU(<secret>,<literal>)")
                elif name in ("CONCAT", "INSERT", "MID", "DELETE"):
                    noisy["PLC-INP-003"].append(ln)
                elif name in ("JMP", "LBL"):
                    noisy["PLC-CODE-001"].append(ln)
                elif name in ("OTE", "OTL") and args:
                    self.register_coil(name, args[0].strip(), rname, lab, ln, loc, raw)
                    coil_rungs.setdefault(args[0].strip(), []).append((ln, lab, code))
                    if name == "OTL":
                        self.latched.setdefault(self.qualify(args[0]), (ln, loc, raw))
                elif name == "OTU" and args:
                    self.unlatched.add(self.qualify(args[0]))
                elif name == "JSR" and args:
                    self.called.add((self.cur_prog, args[0].strip()))

            # ST resets count as unlatching
            for m in re.finditer(r"([A-Za-z_][\w.\[\]]*)\s*:=\s*(?:0|FALSE)\s*;", code, re.I):
                self.unlatched.add(self.qualify(m.group(1)))

            # unbounded ST loops (watchdog / DoS)
            if re.search(r"\b(WHILE|REPEAT)\b", code, re.I):
                self.add("PLC-ROB-003", ln, loc, raw)

            self.check_presets(ln, loc, raw, code, guard_text)
            self.check_io_plausibility(ln, loc, raw, code, guard_text)

            # dead code (AFI / NOP) - matches "AFI", "AFI()" and "NOP()"
            if re.search(r"\bAFI\b|\bNOP\b", code):
                self.add("PLC-CODE-001", ln, loc, raw, extra="AFI/NOP dead logic")

            # hardcoded plaintext string compared in EQU (password check)
            if re.search(r"\bEQU\s*\([^)]*[\"']", raw, re.I):
                self.add("PLC-CRED-004", ln, loc, raw)

            # raw sockets
            if SOCKET_RE.search(raw):
                self.add("PLC-NET-003", ln, loc, raw)

            # test / debug residue in logic
            if any(t in raw.lower() for t in DEBUG_SUBSTR):
                self.add("PLC-DBG-001", ln, loc, raw, extra="live test residue in logic")

            # ST-style literal credentials
            for m in re.finditer(r"\b([A-Za-z_]\w*(?:\.\w+)*)\s*:=\s*(\d{3,}|'[^']*')\s*;", raw):
                if is_secret_name(base_name(m.group(1))):
                    self.add("PLC-CRED-003", ln, loc, f"{m.group(1)} := <literal>")
            for m in re.finditer(r"\b([A-Za-z_]\w*)\s*=\s*(\d{3,})\b", code):
                if is_secret_name(m.group(1)):
                    self.add("PLC-CRED-003", ln, loc, f"{m.group(1)} = <literal>")
            for m in re.finditer(r"(?<![/*(])/\s*([A-Za-z_]\w*(?:\.\w+)*)", code):
                if not guarded(m.group(1), guard_text, zero_check=True):
                    self.add("PLC-ROB-002", ln, loc, raw)

            # ST/SCL declarations with a hard-coded initial value: name : TYPE := 'x';
            for m in _ST_DECL_RE.finditer(raw):
                if is_secret_name(m.group(1)):
                    val = m.group(2).strip("'\"")
                    if val and val != "0":
                        self.add("PLC-CRED-001", ln, loc, f"{m.group(1)} : <type> := <redacted>")

            # bypass + safety signal together
            ids = {t for ident in re.findall(r"[A-Za-z_]\w*", code) for t in name_tokens(ident)}
            if ids & BYPASS_TOKENS and ids & SAFETY_TOKENS:
                self.add("PLC-SAF-001", ln, loc, raw)

            self.check_hmi_taint(ln, loc, raw, code)

            # array indexes
            for m in re.finditer(r"([A-Za-z_]\w*(?:\.\w+)*)\s*\[\s*([^\[\]]+?)\s*\]", code):
                for v in re.findall(r"[A-Za-z_]\w*(?:\.\w+)*", m.group(2)):
                    key = (v, lab) if self.strict else v
                    if v.upper() in ("AND", "OR", "MOD") or key in seen_idx:
                        continue
                    seen_idx.add(key)
                    if not guarded(v, guard_text):
                        self.add("PLC-INP-001", ln, loc, raw, severity="HIGH" if is_external(v) else None,
                                 extra=f"index '{v}'")

        noisy_extra = {"PLC-INP-003": "", "PLC-CODE-001": "JMP/LBL unstructured flow"}
        for rule, lns in noisy.items():
            if lns:
                self.add(rule, lns[0], self.where(rname), f"{len(lns)} occurrence(s) at lines {lns[:10]}",
                         extra=noisy_extra[rule])

        self.check_opposites(rname, coil_rungs)

    # -- timer/counter presets (Top20 P6)
    def check_presets(self, ln, loc, raw, code, guard_text):
        srcs = [a[1] for _, a in calls(code, ["TON", "TOF", "RTO", "CTU", "CTD"]) if len(a) >= 2]
        srcs += [a[0] for _, a in calls(code, ["MOV"]) if len(a) >= 2 and a[1].strip().upper().endswith(".PRE")]
        srcs += re.findall(r"\.PRE\s*:=\s*([A-Za-z_][\w.]*)", code, re.I)
        bad = [s.strip() for s in srcs
               if not re.fullmatch(r"[\d.]+|\?", s.strip()) and not guarded(s.strip(), guard_text)]
        if bad:
            self.add("PLC-TMR-001", ln, loc, raw, severity="HIGH" if any(map(is_external, bad)) else None,
                     extra=f"preset '{bad[0]}'")

    # -- physical input plausibility (Top20 P12)
    def check_io_plausibility(self, ln, loc, raw, code, guard_text):
        if not (re.search(WRITE_SINK_RE, code, re.I) or ":=" in code):
            return
        no_bits = re.sub(r"\b(XIC|XIO|ONS|OSR|OSF)\s*\([^)]*\)", "", code, flags=re.I)
        bad = sorted({io for io in re.findall(r"\b\w+:\d+:I\.\w+(?:\.\w+)*", no_bits)
                      if not guarded(io, guard_text)})
        if bad:
            self.add("PLC-PLA-001", ln, loc, raw, extra=f"'{bad[0]}'")

    # -- HMI taint analysis (Top20 P8)
    def check_hmi_taint(self, ln, loc, raw, code):
        prefixes = [p.lower() for p in CONFIG["hmi_prefixes"]]
        targets = set()
        for name, args in calls(code, ["OTE", "OTL", "OTU", "MOV", "MVM", "COP", "CPS", "ADD", "SUB", "MUL",
                                       "DIV", "CPT"]):
            idx = {"OTE": 0, "OTL": 0, "OTU": 0, "CPT": 0, "ADD": 2, "SUB": 2, "MUL": 2, "DIV": 2}.get(name, 1)
            if len(args) > idx:
                targets.add(args[idx].strip())
        targets |= {m.group(1) for m in re.finditer(r"([\w.\[\]]+)\s*:=", code)}
        idents = re.findall(r"[A-Za-z_]\w*(?:\.\w+)*(?:\[[^\]]*\])?", code)
        reads = [i for i in idents if any(i.lower().startswith(p) for p in prefixes) and i not in targets]
        if not reads or not (re.search(WRITE_SINK_RE, code, re.I) or ":=" in code):
            return
        no_bits = re.sub(r"\b(XIC|XIO)\s*\([^)]*\)", "", code, flags=re.I)
        data_use = any(r in no_bits for r in reads)
        range_ok = re.search(r"\b(LIMIT|LIM|GEQ|LEQ|GRT|LES|CMP|BTW)\s*\(", code, re.I) \
            or re.search(r"<=|>=|<|>", code)
        eq_ok = re.search(r"\b(NEQ|EQU)\s*\(", code, re.I)
        if range_ok:
            return
        if data_use and not eq_ok:
            self.add("PLC-INP-004", ln, loc, raw)
        else:
            self.add("PLC-INP-005", ln, loc, raw,
                     extra="equality-only validation" if data_use else "boolean HMI command")

    # -- duplicate / conflicting coils (Top20 P7)
    def register_coil(self, instr, tag, rname, rung, ln, loc, raw):
        q = self.qualify(tag)
        prev = self.coils.get(q, [])
        if prev:
            p_instr, p_loc, p_rung, p_ln = prev[0]
            both_latch = instr == "OTL" and all(p[0] == "OTL" for p in prev)
            self.add("PLC-LOG-001", ln, loc, raw, severity="MEDIUM" if both_latch else None,
                     extra=f"'{tag}' also driven at {p_loc} line {p_ln}")
        self.coils.setdefault(q, []).append((instr, loc, rung, ln))

    def check_opposites(self, rname, coil_rungs):
        names = list(coil_rungs)
        for a in names:
            for b in names:
                if a >= b or not ((opposite_path(a, b) if self.exact else opposite(a, b))
                                  or any({a, b} == set(p) for p in CONFIG["forbidden_pairs"])):
                    continue
                same = [(ln, lab) for ln, lab, _ in coil_rungs[a]
                        if any(ln == l2 and lab == r2 for l2, r2, _ in coil_rungs[b])]
                for ln, lab in same:
                    self.add("PLC-LOG-002", ln, self.where(rname, lab), f"{a} and {b} on same rung")
                for x, y in ((a, b), (b, a)):
                    for ln, lab, code in coil_rungs[x]:
                        if not re.search(rf"\bXIO\s*\(\s*{re.escape(y)}\s*\)", code):
                            self.add("PLC-LOG-003", ln, self.where(rname, lab), code,
                                     extra=f"{x} lacks XIO({y})")
                            break

    # -- Siemens-specific checks (SCL source and SimaticML, after normalisation to plain ST)
    def siemens_scan(self):
        comments, code = _split_comments("\n".join(self.lines))
        cur_r, depth = "", 0
        for ln, (raw, c) in enumerate(zip(self.lines, code), 1):
            m = re.match(r"\s*(PROGRAM|ROUTINE)\s+(\S+)", raw)
            if m:
                if m.group(1) == "PROGRAM":
                    self.cur_prog, depth = m.group(2), 0
                else:
                    cur_r = m.group(2)
                continue
            if re.match(r"\s*END_(PROGRAM|ROUTINE)\b", raw):
                continue
            loc = self.where(cur_r, "")
            loc = re.sub(r"/Rung:$", "", loc)
            lab = re.match(r"\s*(\d+)\s*:", raw)
            if lab:
                loc = self.where(cur_r, lab.group(1))
            code_line = c.strip()
            # forced safety / permissive signal (unconditional constant assignment)
            a = re.match(r"([A-Za-z_][\w.\[\]]*)\s*:=\s*(TRUE|FALSE|1|0)\s*;", code_line, re.I)
            if a and depth == 0:
                toks = {t for part in a.group(1).split(".") for t in name_tokens(part)}
                val = a.group(2).upper() in ("TRUE", "1")
                if (val and toks & (SAFETY_TOKENS | SIEMENS_SAFETY_TOKENS)) or \
                        (not val and toks & {"estop", "trip", "lockout"}):
                    note = comments.get(ln, "")
                    why = "; original logic commented out on this line" if _looks_like_code(note) else ""
                    self.add("PLC-SAF-002", ln, loc, raw, extra=f"'{a.group(1)}' forced {a.group(2).upper()}{why}")
            # Siemens communication blocks
            for cm in list(S7_COMM_RE.finditer(code_line)) + list(S7_COMM_DECL_RE.finditer(code_line)):
                fn = cm.group(1).upper().split("_")[0] if cm.group(1).upper().startswith("TCON_") else cm.group(1).upper()
                if fn in ("PUT", "GET", "BSEND", "BRCV", "USEND", "URCV"):
                    self.add("PLC-NET-002", ln, loc, raw, extra=f"S7 {fn}: no authentication; needs PUT/GET access enabled on the CPU")
                else:
                    self.add("PLC-NET-003", ln, loc, raw, extra=f"{fn} open communication block")
            if re.search(r"\b(DIS_AIRT|DIS_IRT)\s*[(,)]", code_line, re.I):
                self.add("PLC-SYS-002", ln, loc, raw, extra="DIS_AIRT/DIS_IRT disables interrupts")
            depth += len(re.findall(r"\b(?:IF|CASE|FOR|WHILE|REPEAT)\b", code_line, re.I)) \
                - len(re.findall(r"\bEND_(?:IF|CASE|FOR|WHILE|REPEAT)\b", code_line, re.I))
            depth = max(depth, 0)
        # commented-out logic
        for ln, text in sorted(comments.items()):
            if _looks_like_code(text):
                self.add("PLC-CODE-003", ln, self.ctx[ln] or "File", text.strip())

    # -- whole-file text scans
    def global_scans(self):
        secret_re = re.compile(r"(password|passwd|pwd|passcode|passphrase|secret|api[_-]?key|token)"
                               r"\s*(?:is|:|=|:=)\s*['\"]?([^\s'\";,)$]{3,})", re.I)
        ip_re = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")
        for idx, line in enumerate(self.lines, 1):
            if self.raw:
                segs = [line]
            else:
                segs = re.findall(r'"((?:[^"$]|\$.)*)"', line) + re.findall(r"//(.*)$", line) \
                       + re.findall(r"\(\*(.*?)\*\)", line)
                if line.strip().startswith(("RC:", "#")):
                    segs.append(line)
            for seg in segs:
                if secret_re.search(seg):
                    self.add("PLC-CRED-002", idx, self.ctx[idx] or "File", "<credential-like text redacted>")
            for m in ip_re.finditer(line):
                try:
                    ip = ipaddress.ip_address(m.group(1))
                except ValueError:
                    continue
                if ip.is_unspecified or ip.is_loopback or ip.is_multicast or m.group(1).startswith("255."):
                    continue
                if self.raw and re.search(r"(?i)version|revision|assembly", line[max(0, m.start() - 25):m.start()]):
                    continue  # dotted quad is almost certainly a version number
                sev, extra = ("MEDIUM" if ip.is_global else None), m.group(1)
                if self.ip_note:  # binary strings: version numbers look like IPs
                    if extra in self.ip_seen:
                        continue
                    self.ip_seen.add(extra)
                    sev, extra = "LOW", f"{extra}; {self.ip_note}"
                self.add("PLC-NET-001", idx, self.ctx[idx] or "File", line, severity=sev, extra=extra)

    # -- architectural (absence) checks over all logic
    def architecture_checks(self):
        if not self.corpus:
            return
        if self.generic:  # absence checks use Logix names (S:FS, S:KEYS, GSV...): only latch check is portable
            for q, (ln, loc, raw) in self.latched.items():
                if q not in self.unlatched:
                    self.add("PLC-LOG-004", ln, loc, raw)
            return
        raws = [r for _, r, _ in self.corpus]
        if not any(contains_any(r, CONFIG["keyswitch_keywords"]) for r in raws):
            self.add("PLC-MODE-001", 0, "Entire codebase", "no keyswitch keyword found: " +
                     ", ".join(CONFIG["keyswitch_keywords"]))
        if not any(contains_any(r, CONFIG["firstscan_keywords"]) for r in raws):
            self.add("PLC-RST-001", 0, "Entire codebase", "no first-scan keyword found: " +
                     ", ".join(CONFIG["firstscan_keywords"]))
        timer = any(re.search(r"\bTON\s*\(", c, re.I) and contains_any(r, CONFIG["access_flag_keywords"])
                    for _, r, c in self.corpus)
        action = any(".DN" in r.upper() and re.search(r"\b(COP|MOV|CLR)\s*\(|:=", r, re.I)
                     and contains_any(r, CONFIG["password_input_keywords"]) for _, r, _ in self.corpus)
        if not (timer and action):
            missing = [n for n, ok in (("TON on access flag", timer),
                                       ("timeout clears password/access", action)) if not ok]
            self.add("PLC-SES-001", 0, "Entire codebase", "missing: " + "; ".join(missing))

        math = next((ln for ln, _, c in self.corpus
                     if re.search(r"\b(ADD|SUB|MUL|DIV|CPT|EXPT)\s*\(|:=[^;]*[*+]", c, re.I)), None)
        if math and not any(contains_any(r, CONFIG["overflow_keywords"]) for r in raws):
            self.add("PLC-INT-001", math, "Entire codebase", "no overflow check found: " +
                     ", ".join(CONFIG["overflow_keywords"]))

        gaps = [what for what, kws in CONFIG["monitor_keywords"].items()
                if not any(contains_any(r, kws) for r in raws)]
        if gaps:
            self.add("PLC-MON-001", 0, "Entire codebase", "missing: " + ", ".join(gaps))

        for q, (ln, loc, raw) in self.latched.items():
            if q not in self.unlatched:
                self.add("PLC-LOG-004", ln, loc, raw)

        for prog, r, ln, loc in self.routines:
            if (prog, r) not in self.called:
                self.add("PLC-CODE-002", ln, loc, f"routine {r}")


# ============================================================ multi-format front end
# Content sniffing decides how a file is read; the extension is only a hint. Every route ends in
# the same Scanner engine (full rule set for L5K/L5X, ST-level rules for ST/SCL/XML-embedded ST,
# text/string-level rules for opaque or binary containers).
FORMAT_INFO = {
    ".l5k": "Rockwell Logix 5000 L5K text export",
    ".l5x": "Rockwell Logix 5000 L5X (XML) export",
    ".acd": "Rockwell Studio 5000 / RSLogix 5000 project (binary)",
    ".rss": "Rockwell RSLogix 500 project",
    ".slc": "Rockwell SLC / RSLogix 500 file",
    ".ap15": "Siemens TIA Portal V15 project",
    ".ap19": "Siemens TIA Portal V19 project",
    ".zap15": "Siemens TIA Portal V15 archived project (ZIP)",
    ".zap19": "Siemens TIA Portal V19 archived project (ZIP)",
    ".scl": "Siemens SCL source",
    ".awl": "Siemens STL/AWL source",
    ".s7p": "Siemens STEP 7 project",
    ".zip": "ZIP archive",
    ".stu": "Schneider Unity Pro / Control Expert project",
    ".sta": "Schneider Unity Pro / Control Expert archive",
    ".zef": "Schneider Control Expert export (ZIP)",
    ".xef": "Schneider Control Expert XEF export (XML)",
    ".project": "CODESYS project",
    ".projectarchive": "CODESYS project archive (ZIP)",
    ".library": "CODESYS library",
    ".gx3": "Mitsubishi GX Developer project",
    ".gxw": "Mitsubishi GX Works project",
    ".gps": "Mitsubishi GX-series project",
    ".smc2": "SMC2 project file",
    ".cxp": "Omron CX-Programmer project",
    ".tsproj": "Beckhoff TwinCAT system project (XML)",
    ".plcproj": "Beckhoff TwinCAT PLC project (XML)",
    ".tcpou": "Beckhoff TwinCAT POU (XML)",
    ".st": "IEC 61131-3 Structured Text source",
    ".xml": "XML export (PLCopen / vendor)",
}
SUPPORTED_EXTS = tuple(sorted(FORMAT_INFO))

MAX_FILE_BYTES = 512 * 1024 * 1024
MAX_MEMBER_BYTES = 200 * 1024 * 1024
MAX_TOTAL_BYTES = 1024 * 1024 * 1024
MAX_MEMBERS = 5000
MAX_DEPTH = 4
MIN_STRING = 6
MAX_STRINGS = 2_000_000
MAX_CARVE_TRIES, MAX_CARVE_STREAMS = 20000, 2000
MAX_CARVE_IN, MAX_CARVE_OUT = 16 * 1024 * 1024, 64 * 1024 * 1024

_L5K_RE = re.compile(r"^\s*CONTROLLER\s+\w+\s*\(", re.M | re.I)
_RUNG_STR = re.compile(r"^(?:\d+\s*:\s*)?(?:[A-Z]{2,6}\([^;]*\))+;?$")
_ASCII_RE = re.compile(rb"[\x20-\x7e\t]{%d,}" % MIN_STRING)
_UTF16_RE = re.compile(rb"(?:[\x20-\x7e]\x00){%d,}" % MIN_STRING)
_ZLIB_RE = re.compile(rb"\x78[\x01\x5e\x9c\xda]")
_ST_TAGS = {"ST", "STSource", "STContent", "Declaration"}
_GRAPHIC_TAGS = {"LD", "FBD", "SFC", "IL", "NWL", "CFC"}
_CFG_ATTR = re.compile(r"web|http|telnet|ftp|opcua|snmp|safetylocked", re.I)
_BOOLS = {"true": "1", "false": "0", "yes": "1", "no": "0"}
_TEXT_BYTES = bytes(sorted((set(range(0x20, 0x100)) - {0x7f}) | {7, 8, 9, 10, 12, 13, 27}))


def decode_text(data):
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", errors="replace")
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def _sniff(data):
    if data[:4] in (b"PK\x03\x04", b"PK\x05\x06"):
        return "zip"
    head = data[:65536]
    if not head or head.startswith((b"\xff\xfe", b"\xfe\xff", b"\xef\xbb\xbf")):
        return "text"
    if b"\x00" in head:
        return "binary"
    if len(head.translate(None, _TEXT_BYTES)) > 0.05 * len(head) or \
            len(head.translate(None, bytes(range(0x80)))) > 0.30 * len(head):
        return "binary"
    return "text"


def _ln(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _loc(prefix, location):
    return f"[{prefix}] {location}" if prefix else location


def _join(prefix, name):
    return f"{prefix}!{name}" if prefix else name


def _merge(primary, secondary):
    keys = {(f.rule_id, f.title, f.snippet, f.line) for f in primary}
    return list(primary) + [f for f in secondary if (f.rule_id, f.title, f.snippet, f.line) not in keys]


class _Synth:
    """Builds synthetic L5K-style text plus a map back to original line numbers."""
    def __init__(self):
        self.lines, self.src = [], []

    def add(self, line, src=0):
        self.lines.append(line)
        self.src.append(src)

    def st_program(self, label, body_lines, first_src):
        label = re.sub(r"[^\w.\-]", "_", label or "") or "Main"
        self.add(f"PROGRAM {label} (MainRoutineName := Main, FaultRoutineName := Main)")
        self.add("ROUTINE Main ()")
        for k, l in enumerate(body_lines):
            self.add(l, first_src + k if first_src else 0)
        self.add("END_ROUTINE")
        self.add("END_PROGRAM")


class _Locator:
    """Maps text found in an XML document back to its line number (document-order cursor)."""
    def __init__(self, text):
        self.text, self.pos = text, 0
        self.nl = [m.start() for m in re.finditer(r"\n", text)]

    def line_at(self, offset):
        return bisect.bisect_left(self.nl, offset) + 1

    def find(self, chunk):
        chunk = (chunk or "").strip()
        if not chunk:
            return 0
        i = self.text.find(chunk, self.pos)
        if i < 0:
            i = self.text.find(chunk)
        if i < 0:
            return 0
        self.pos = i + len(chunk)
        return bisect.bisect_left(self.nl, i) + 1


class ScanCancelled(Exception):
    """Raised when the cancel object passed to scan_file() reports is_set()."""


@dataclass
class ScanResult:
    findings: list                                   # active findings (after any baseline)
    details: list = field(default_factory=list)
    suppressed: list = field(default_factory=list)   # [(Finding, baseline entry)]
    expired: list = field(default_factory=list)      # [(Finding, entry)] suppression lapsed, reported again
    stale: list = field(default_factory=list)        # baseline entries that matched nothing


class _Ctx:
    def __init__(self, strict, cancel=None):
        self.strict, self.findings, self.details, self.total = strict, [], [], 0
        self.cancel = cancel

    def check(self):
        if self.cancel is not None and self.cancel.is_set():
            raise ScanCancelled("scan cancelled")

    def note(self, rule, location, snippet, prefix="", extra=""):
        if rule in DISABLED:
            return
        sev, title, cwe, rec, practice = RULES[rule]
        self.findings.append(Finding(rule, sev, title + (f" ({extra})" if extra else ""),
                                     _loc(prefix, location), 0, " ".join(snippet.split())[:200],
                                     cwe, rec, practice, "High", owasp=owasp_label(rule)))

    def take(self, fs, prefix=""):
        for f in fs:
            f.location = _loc(prefix, f.location)
            self.findings.append(f)

    def detail(self, prefix, name, msg):
        self.details.append(f"{prefix or name}: {msg}")


# ---- helpers for synthetic L5K text
def _safe(n):
    return re.sub(r"[^\w.\-]", "_", n or "") or "unnamed"


def _fv(v):
    v = "" if v is None else str(v)
    if v and re.fullmatch(r"[^\s,()\"'$]+", v):
        return v
    return '"' + v.replace("$", "$$").replace('"', '$"').replace("\r", " ").replace("\n", " ") + '"'


def _attrs(d, skip=()):
    out = []
    for k, v in d.items():
        if k not in skip:
            out.append(re.sub(r"\W", "_", k) + " := " + _fv(v))
    return ", ".join(out)


def _norm_cfg(d):
    return {k: (_BOOLS.get(str(v).lower(), v) if _CFG_ATTR.search(k) else v) for k, v in d.items()}


def _one_line(t):
    return " ".join((t or "").split())


def _l5x_tag_line(tag):
    name = _safe(tag.get("Name"))
    dtype = tag.get("DataType") or tag.get("TagType") or "ALIAS"
    attrs = {}
    desc = [_one_line(e.text) for n in ("Description", "Comment", "LocalizedDescription", "LocalizedComment")
            for e in tag.iter(n) if _one_line(e.text)]
    if desc:
        attrs["Description"] = " | ".join(desc)
    if tag.get("ExternalAccess"):
        attrs["ExternalAccess"] = tag.get("ExternalAccess")
    value = ""
    datas = tag.findall("Data")
    for d in datas:
        if d.get("Format") == "L5K":
            value = _one_line(d.text)
            break
    else:
        for d in datas:
            if d.get("Format") == "String":
                t = _one_line(d.text)
                value = t if t.startswith("'") else f"'{t}'"
            elif d.get("Format") == "Decorated":
                dv = d.find("DataValue")
                if dv is not None and dv.get("Value") is not None:
                    value = dv.get("Value")
                else:
                    for m in d.iter("DataValueMember"):
                        if m.get("Name") == "DATA":
                            value = "'" + _one_line(m.text or m.get("Value")) + "'"
    head = f"{name} : {dtype} ({_attrs(attrs)})"
    return f"{head} := {value};" if value else head + ";"


def _l5x_to_l5k(root, loc):
    """Convert an L5X (XML) export into the L5K-style text the Scanner engine understands."""
    syn, notes = _Synth(), []
    stats = {"programs": 0, "routines": 0, "rungs": 0}
    ctrl = root.find("Controller")
    if ctrl is None:
        ctrl = root
        notes.append(("PLC-FMT-004", "File", "no <Controller> element: partial L5X export, scanned what is present"))
    else:
        attrs = dict(ctrl.attrib)
        sec = ctrl.find("Security")
        if sec is not None:
            if "Code" in sec.attrib:
                attrs["SecurityCode"] = sec.get("Code")
            for k in ("ChangesToDetect", "SignatureRunModeProtect"):
                if k in sec.attrib:
                    attrs[k] = sec.get(k)
        si = ctrl.find("SafetyInfo")
        if si is not None:
            attrs.update({k: v for k, v in si.attrib.items() if _CFG_ATTR.search(k)})
        syn.add(f"CONTROLLER {_safe(ctrl.get('Name'))} ({_attrs(_norm_cfg(attrs))})")

    mods = ctrl.find("Modules")
    for mod in (mods.findall("Module") if mods is not None else []):
        attrs = dict(mod.attrib)
        ek = mod.find("EKey")
        if ek is not None:
            attrs["EKey"] = ek.get("State", "")
        for n, p in enumerate(mod.iter("Port")):
            if p.get("Address"):
                attrs["PortAddress" + (str(n) if n else "")] = p.get("Address")
        for el in mod.iter():
            for k, v in el.attrib.items():
                if _CFG_ATTR.search(k):
                    attrs[k] = v
            if el.get("Name") and el.get("Value") is not None and _CFG_ATTR.search(el.get("Name")):
                attrs[el.get("Name")] = el.get("Value")
        syn.add(f"MODULE {_safe(mod.get('Name'))} ({_attrs(_norm_cfg(attrs))})")
        syn.add("END_MODULE")

    def tags_block(el):
        if el is None:
            return
        syn.add("TAG")
        for tag in el.findall("Tag"):
            syn.add(_l5x_tag_line(tag))
        syn.add("END_TAG")

    def routine(r, owner):
        name = _safe(r.get("Name"))
        typ = (r.get("Type") or "RLL").upper()
        stats["routines"] += 1
        syn.add(f"ROUTINE {name} ()")
        if typ == "RLL":
            content = r.find("RLLContent")
            for rung in (content.findall("Rung") if content is not None else []):
                for c in rung.findall("Comment"):
                    ct = _one_line(c.text)
                    if ct:
                        syn.add('RC: "' + ct.replace("$", "$$").replace('"', '$"') + '"')
                t = rung.find("Text")
                text = _one_line(t.text) if t is not None else ""
                if text:
                    stats["rungs"] += 1
                    syn.add(f"{rung.get('Number', '0')}: {text}" + ("" if text.endswith(";") else ";"),
                            loc.find(t.text))
        elif typ == "ST":
            content = r.find("STContent")
            for ln_el in (content.findall("Line") if content is not None else []):
                if (ln_el.text or "").strip():
                    syn.add(_one_line(ln_el.text), loc.find(ln_el.text))
        else:
            notes.append(("PLC-FMT-002", f"{owner}/Routine:{name}", f"{typ} routine not analysed"))
        syn.add("END_ROUTINE")

    tags_block(ctrl.find("Tags"))
    tasks = ctrl.find("Tasks")
    for t in (tasks.findall("Task") if tasks is not None else []):
        syn.add(f"TASK {_safe(t.get('Name'))} ({_attrs(t.attrib, skip=('Name',))})")
    progs = ctrl.find("Programs")
    for p in (progs.findall("Program") if progs is not None else []):
        pname = _safe(p.get("Name"))
        stats["programs"] += 1
        syn.add(f"PROGRAM {pname} ({_attrs(p.attrib, skip=('Name',))})")
        tags_block(p.find("Tags"))
        rs = p.find("Routines")
        for r in (rs.findall("Routine") if rs is not None else []):
            routine(r, f"Program:{pname}")
        syn.add("END_PROGRAM")
    for aoi in root.iter("AddOnInstructionDefinition"):
        aname = "AOI_" + _safe(aoi.get("Name"))
        syn.add(f"PROGRAM {aname} (MainRoutineName := Logic, FaultRoutineName := Prescan, "
                f"EnableInFalseRoutineName := EnableInFalse)")
        rs = aoi.find("Routines")
        for r in (rs.findall("Routine") if rs is not None else []):
            routine(r, f"Program:{aname}")
        syn.add("END_PROGRAM")
    return syn, notes, stats


# ---- route handlers
def _raw_scan(lines, name, cx, **kw):
    return Scanner(name, cx.strict, lines=lines, raw=True, **kw).parse()


def _xml_lines(text):
    lines = text.splitlines()
    if lines and max(map(len, lines)) > 5000:  # minified XML: split so findings get distinct locations
        lines = re.sub(r">\s*<", ">\n<", text).splitlines()
    return lines


# ---- Siemens TIA Portal SimaticML (Openness export) -> plain ST / rung text
_EDGE_PARTS = {"PBox", "NBox"}
_COMPARE = {"Eq": "EQU", "Ne": "NEQ", "Gt": "GRT", "Lt": "LES", "Ge": "GEQ", "Le": "LEQ", "InRange": "LIM", "OutRange": "LIM"}
_TIMERS = {"TON", "TOF", "TP", "TONR"}
_COUNTERS = {"CTU", "CTD", "CTUD"}
_MATH = {"Add": "ADD", "Sub": "SUB", "Mul": "MUL", "Div": "DIV", "Mod": "MOD"}
_BOOL_SOURCES = {"Contact", "O", "A", "Not"} | _EDGE_PARTS | set(_COMPARE)
_BLOCK_KINDS = {"FC", "FB", "OB", "GlobalDB", "InstanceDB", "ArrayDB"}


def _child(el, name):
    for c in el:
        if _ln(c.tag) == name:
            return c
    return None


def _ctext(el, name, default=""):
    c = _child(el, name)
    return (c.text or "").strip() if c is not None and c.text else default


def _sym_text(sym):
    """Dotted path of a <Symbol>: Component names, array indexes and bit/byte slices."""
    out = []
    for comp in sym:
        if _ln(comp.tag) != "Component":
            continue
        nm = re.sub(r"[^\w]", "_", comp.get("Name", "")) or "_"
        idx = [_access_text(a) for a in comp if _ln(a.tag) == "Access"]
        if idx:
            nm += "[" + ",".join(idx) + "]"
        sl = comp.get("SliceAccessModifier")
        out.append(nm + (("." + sl.upper()) if sl else ""))
    return ".".join(out)


def _time_ms(lit):
    """IEC time literal (T#2s, T#1m30s, TIME#500ms) -> milliseconds as text, so presets read as constants."""
    units = {"d": 86400000, "h": 3600000, "m": 60000, "s": 1000, "ms": 1}
    body = re.sub(r"(?i)^t(?:ime)?#", "", lit).replace("_", "")
    parts = re.findall(r"(\d+(?:\.\d+)?)(ms|d|h|m|s)", body, re.I)
    if not parts:
        return lit
    return str(int(sum(float(n) * units[u.lower()] for n, u in parts)))


def _contact_text(op, neg):
    """XIC/XIO for a contact; a contact that can never pass power (XIC FALSE / XIO TRUE) is also marked AFI()."""
    const = {"true": True, "1": True, "false": False, "0": False}.get(op.strip().lower())
    dead = const is not None and const == neg
    return ("AFI()" if dead else "") + (f"XIO({op})" if neg else f"XIC({op})")


def _access_text(acc):
    scope = acc.get("Scope", "")
    sym = _child(acc, "Symbol")
    if sym is not None:
        return _sym_text(sym)
    if scope in ("LiteralConstant", "TypedConstant"):
        const = _child(acc, "Constant") if _child(acc, "Constant") is not None else acc
        v = _ctext(const, "ConstantValue") or _ctext(acc, "ConstantValue")
        return (_time_ms(v) if re.match(r"(?i)t(?:ime)?#", v or "") else v) or "?"
    addr = _child(acc, "Address")
    if addr is not None:
        area = {"Input": "I", "Output": "Q", "Memory": "M", "PeripheryInput": "PI", "PeripheryOutput": "PQ"}.get(addr.get("Area", ""), "M")
        try:
            bit = int(addr.get("BitOffset", "0"))
        except ValueError:
            bit = 0
        return f"%{area}{bit // 8}.{bit % 8}"
    return "?"


class _Net:
    """One FlgNet (ladder / FBD network) as a small graph, rendered to RLL-style text."""

    def __init__(self, flg):
        self.parts, self.access, self.driver, self.outvar = {}, {}, {}, {}
        self._memo = {}
        parts_el = _child(flg, "Parts")
        for el in (parts_el if parts_el is not None else []):
            uid, t = el.get("UId"), _ln(el.tag)
            if t == "Access":
                self.access[uid] = _access_text(el)
            elif t == "Part":
                self.parts[uid] = {"name": el.get("Name", "?"), "neg": {n.get("Name") for n in el if _ln(n.tag) == "Negated"},
                                   "card": next((int(v.text) for v in el if _ln(v.tag) == "TemplateValue"
                                                 and v.get("Name") == "Card" and (v.text or "").isdigit()), 2),
                                   "inst": next((_access_text(i) if _child(i, "Symbol") is not None else
                                                 ".".join(re.sub(r"\W", "_", c.get("Name", "")) for c in i.iter() if _ln(c.tag) == "Component")
                                                 for i in el if _ln(i.tag) == "Instance"), "")}
            elif t == "Call":
                ci = _child(el, "CallInfo")
                self.parts[uid] = {"name": "Call", "callee": ci.get("Name", "?") if ci is not None else "?",
                                   "neg": set(), "card": 2, "inst": ""}
        wires = _child(flg, "Wires")
        for w in (wires if wires is not None else []):
            conns = [c for c in w if _ln(c.tag) in ("Powerrail", "IdentCon", "NameCon", "OpenCon")]
            if not conns:
                continue
            src = next((("rail",) for c in conns if _ln(c.tag) == "Powerrail"), None)
            if src is None:
                c0 = conns[0]
                src = ("acc", c0.get("UId")) if _ln(c0.tag) == "IdentCon" else ("pin", c0.get("UId"), c0.get("Name"))
                targets = conns[1:]
            else:
                targets = [c for c in conns if _ln(c.tag) != "Powerrail"]
            for t in targets:
                if _ln(t.tag) == "NameCon":
                    self.driver[(t.get("UId"), t.get("Name"))] = src
                elif _ln(t.tag) == "IdentCon" and src[0] == "pin":
                    self.outvar[(src[1], src[2])] = t.get("UId")

    def value(self, uid, pin, depth=0):
        """Text of the value wired into an input pin (variable, constant, or an upstream part's output)."""
        src = self.driver.get((uid, pin))
        if src is None:
            return ""
        if src[0] == "acc":
            return self.access.get(src[1], "?")
        if src[0] == "pin" and depth < 30:
            part = self.parts.get(src[1], {"name": "?"})
            name = part["name"]
            ov = self.outvar.get((src[1], src[2]))
            if ov is not None:
                return self.access.get(ov, "?")
            if name in _MATH or name == "Convert":
                a, b = self.value(src[1], "in1", depth + 1) or self.value(src[1], "in", depth + 1), self.value(src[1], "in2", depth + 1)
                return f"({a} {name} {b})" if b else f"{name}({a})"
            return f"{name}_{src[2]}"
        return ""

    def cond(self, uid, pin, depth=0):
        """RLL text for the power flow arriving at (uid, pin): contacts in series, BST/NXB/BND for parallel."""
        key = (uid, pin)
        if key not in self._memo:
            self._memo[key] = self._cond(uid, pin, depth)
        return self._memo[key]

    def _cond(self, uid, pin, depth):
        src = self.driver.get((uid, pin))
        if src is not None and src[0] == "acc":              # boolean tag wired straight into the pin
            return _contact_text(self.access.get(src[1], "?"), False)
        if src is None or src[0] != "pin" or depth > 40:
            return ""
        suid, spin = src[1], src[2]
        part = self.parts.get(suid)
        if part is None:
            return ""
        name = part["name"]
        up = self.cond(suid, "in", depth + 1)
        if name == "Contact":
            return up + _contact_text(self.value(suid, "operand") or "?", "operand" in part["neg"])
        if name in ("O", "A"):
            branches = [self.cond_pin_value(suid, f"in{k}", depth + 1) for k in range(1, part["card"] + 1)]
            if name == "A":
                return "".join(branches)
            return "BST " + " NXB ".join(branches) + " BND "
        if name in _EDGE_PARTS:
            return up + f"ONS({self.value(suid, 'bit') or '?'})"
        if name in _COMPARE:
            a, b = self.value(suid, "in1"), self.value(suid, "in2")
            args = f"{a},{b}" if name not in ("InRange", "OutRange") else f"{self.value(suid, 'min')},{a},{self.value(suid, 'max')}"
            return up + f"{_COMPARE[name]}({args})"
        if name == "Not":
            return up + "NOT()"
        if name in ("Rs", "Sr"):                              # flip-flop output = its stored operand bit
            return f"XIC({self.value(suid, 'operand') or '?'})"
        # output of a timer / counter / call used as a condition
        inst = part.get("inst") or self.outvar_text(suid, spin) or f"{name}"
        return self.cond(suid, "in", depth + 1) + f"XIC({inst}.{spin})" if inst else up

    def cond_pin_value(self, uid, pin, depth):
        src = self.driver.get((uid, pin))
        if src is None or src[0] == "rail":
            return ""
        return self.cond(uid, pin, depth)

    def outvar_text(self, uid, pin):
        ov = self.outvar.get((uid, pin))
        return self.access.get(ov, "") if ov is not None else ""

    def rungs(self):
        """[(part uid, rung text)] - one rung per distinct condition, terminals sharing one condition share a rung."""
        groups, order = {}, []

        def put(cond, instr, uid):
            if cond not in groups:
                groups[cond] = []
                order.append(cond)
            groups[cond].append((uid, instr))
        for uid, part in self.parts.items():
            n = part["name"]
            if n in _BOOL_SOURCES:
                continue
            op = self.value(uid, "operand") or part.get("inst") or "?"
            if n == "Coil":
                put(self.cond(uid, "in"), f"OTE({op})", uid)
            elif n == "SCoil":
                put(self.cond(uid, "in"), f"OTL({op})", uid)
            elif n == "RCoil":
                put(self.cond(uid, "in"), f"OTU({op})", uid)
            elif n in ("Rs", "Sr"):       # Rs: pins s1 / r ; Sr: pins s / r1
                put(self.cond(uid, "s1") or self.cond(uid, "s"), f"OTL({op})", uid)
                put(self.cond(uid, "r") or self.cond(uid, "r1"), f"OTU({op})", uid)
            elif n in _TIMERS or n in _COUNTERS:
                preset = self.value(uid, "PT") or self.value(uid, "PV") or "0"
                put(self.cond(uid, "IN") or self.cond(uid, "CU"), f"{n if n in _TIMERS else n}({part.get('inst') or '?'},{preset},0)", uid)
            elif n == "Move" or n == "Convert":
                dst = self.outvar_text(uid, "out1") or self.outvar_text(uid, "out") or "?"
                put(self.cond(uid, "en"), f"MOV({self.value(uid, 'in') or '?'},{dst})", uid)
            elif n in _MATH:
                dst = self.outvar_text(uid, "out") or "?"
                put(self.cond(uid, "en"), f"{_MATH[n]}({self.value(uid, 'in1') or '?'},{self.value(uid, 'in2') or '?'},{dst})", uid)
            elif n == "Call":
                put(self.cond(uid, "en"), f"JSR({part['callee']})", uid)
            elif n in ("Ret", "Jmp", "JmpN", "Label"):
                put(self.cond(uid, "in") or self.cond(uid, "en"), f"{'JMP' if n.startswith('Jmp') else 'NOP'}({self.value(uid, 'label') or n})", uid)
            else:
                put(self.cond(uid, "en") or self.cond(uid, "in"), f"{n}({self.value(uid, 'in') or ''})", uid)
        out = []
        for cond in order:
            ins = groups[cond]
            body = ins[0][1] if len(ins) == 1 else "[" + ",".join(i for _, i in ins) + "]"
            out.append((ins[0][0], f"{cond}{body}"))
        return out


def _st_from_tokens(sst):
    """Rebuild SCL source text from a SimaticML <StructuredText> token stream."""
    buf = []

    def walk(el):
        t = _ln(el.tag)
        if t == "Token":
            buf.append(el.get("Text", ""))
        elif t == "Blank":
            buf.append(" " * int(el.get("Num", "1") or 1))
        elif t == "NewLine":
            buf.append("\n" * int(el.get("Num", "1") or 1))
        elif t == "Access":
            buf.append(_access_text(el))
        elif t in ("Comment", "LineComment"):
            txt = "".join(el.itertext()).strip()
            buf.append(f"// {txt}" if t == "LineComment" else f"(* {txt} *)")
        else:
            for c in el:
                walk(c)
    for c in sst:
        walk(c)
    return "".join(buf)


def _simatic_to_st(root, loc, text):
    """Convert a TIA Portal SimaticML export (FC/FB/OB/DB) into synthetic ST/rung text for the Scanner."""
    syn, notes = _Synth(), []
    stats = {"blocks": 0, "networks": 0, "langs": {}}
    flg_at = [m.start() for m in re.finditer(r"<FlgNet\b", text)]
    sst_at = [m.start() for m in re.finditer(r"<StructuredText\b", text)]
    fi = si = 0
    for blk in root.iter():
        kind = _ln(blk.tag).replace("SW.Blocks.", "")
        if not _ln(blk.tag).startswith("SW.Blocks.") or kind not in _BLOCK_KINDS:
            continue
        attrs = _child(blk, "AttributeList")
        bname = (_ctext(attrs, "Name") if attrs is not None else "") or f"{kind}{blk.get('ID', '')}"
        sname, stats["blocks"] = _safe(bname), stats["blocks"] + 1
        where = f"Program:{sname}"
        blk_line = loc.find(f"<Name>{bname.replace('&', '&amp;')}</Name>") or 1
        syn.add(f"PROGRAM {sname} (MainRoutineName := Logic, FaultRoutineName := Logic)", blk_line)
        syn.add("ROUTINE Logic ()", blk_line)
        if attrs is not None and _ctext(attrs, "MemoryLayout").lower() == "standard":
            notes.append(("PLC-ACC-004", where, f"{kind} {bname}: MemoryLayout=Standard (absolute/offset access enabled)"))
        # member start values -> declarations (hard-coded credential check)
        for mem in blk.iter():
            if _ln(mem.tag) == "Member" and mem.get("Name"):
                sv = next((v for v in mem if _ln(v.tag) == "StartValue" and (v.text or "").strip()), None)
                if sv is not None:
                    val = sv.text.strip()
                    lit = val if re.fullmatch(r"-?\d+", val) else "'" + val.strip("'\"").replace("'", "$'") + "'"
                    syn.add(f"{re.sub(r'[^\w]', '_', mem.get('Name'))} : {re.sub(r'[^\w]', '', mem.get('Datatype', 'String')) or 'String'} := {lit};",
                            loc.find(f'Name="{mem.get("Name")}"') or blk_line)
        n = 0
        for cu in blk.iter():
            if _ln(cu.tag) != "SW.Blocks.CompileUnit":
                continue
            n += 1
            stats["networks"] += 1
            lattr = _child(cu, "AttributeList")
            lang = (_ctext(lattr, "ProgrammingLanguage") if lattr is not None else "") or "LAD"
            stats["langs"][lang] = stats["langs"].get(lang, 0) + 1
            ns = _child(lattr, "NetworkSource") if lattr is not None else None
            flg = _child(ns, "FlgNet") if ns is not None else None
            sst = _child(ns, "StructuredText") if ns is not None else None
            if flg is not None:
                start = flg_at[fi] if fi < len(flg_at) else 0
                fi += 1
                end = text.find("</FlgNet>", start)
                net = _Net(flg)
                for uid, rung in net.rungs():
                    m = re.compile(rf'<(?:Part|Call)\b[^>]*\bUId="{re.escape(uid)}"').search(text, start, end if end > 0 else len(text))
                    syn.add(f"{n}: {rung};", loc.line_at(m.start() if m else start))
            elif sst is not None:
                start = sst_at[si] if si < len(sst_at) else 0
                si += 1
                base = loc.line_at(start)
                src = _st_from_tokens(sst)
                syn.add(f"{n}: // SCL network", base)
                for k, l in enumerate(_scl_normalize(src)):
                    if l.strip():
                        syn.add(l, base + k)
            elif lang in ("STL", "GRAPH", "CFC"):
                notes.append(("PLC-FMT-002", f"{where}/Routine:Logic/Rung:{n}", f"{lang} network not analysed"))
        syn.add("END_ROUTINE")
        syn.add("END_PROGRAM")
    return syn, notes, stats



def _label(el, parent):
    names, node = [], parent.get(el)
    while node is not None:
        n = node.get("Name") or node.get("name")
        if n:
            names.append(n)
        node = parent.get(node)
    return ".".join(reversed(names))


def _analyze_xml(text, name, ext, cx, prefix):
    body = re.sub(r"^\s*<\?xml[^>]*\?>", "", text.lstrip("\ufeff \t\r\n"), count=1)
    root, reason = None, ""
    if re.search(r"<!ENTITY", body, re.I):
        reason = "XML declares entities (not parsed: entity-expansion risk)"
    else:
        try:
            root = ET.fromstring(body)
        except ET.ParseError as exc:
            reason = f"XML parse error: {exc}"
    if root is None:
        cx.note("PLC-FMT-004", "File", reason, prefix)
        cx.take(_raw_scan(_xml_lines(text), name, cx), prefix)
        cx.detail(prefix, name, "XML could not be parsed - plain-text scan only")
        return
    loc = _Locator(text)
    if _ln(root.tag) == "RSLogix5000Content":
        syn, notes, st = _l5x_to_l5k(root, loc)
        cx.take(Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src).parse(), prefix)
        for rule, where, snip in notes:
            cx.note(rule, where, snip, prefix)
        cx.detail(prefix, name, f"Rockwell L5X converted to the L5K model ({st['programs']} program(s), "
                                f"{st['routines']} routine(s), {st['rungs']} rung(s)) - full rule set")
        return
    if any(_ln(e.tag).startswith("SW.Blocks.") for e in root.iter()):
        syn, notes, st = _simatic_to_st(root, loc, text)
        logic = Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src, generic=True, siemens=True).parse()
        cx.take(_merge(logic, _raw_scan(_xml_lines(text), name, cx)), prefix)
        for rule, where, snip in notes:
            cx.note(rule, where, snip, prefix)
        langs = ", ".join(f"{n} {k}" for k, n in sorted(st["langs"].items())) or "no networks"
        cx.detail(prefix, name, f"Siemens TIA Portal SimaticML ({st['blocks']} block(s); {langs}) - "
                                f"ladder/ST converted to the rung model: logic rules + Siemens checks + text scan")
        return
    parent = {c: p for p in root.iter() for c in p}
    syn, notes, n_st = _Synth(), [], 0
    for el in root.iter():
        t = _ln(el.tag)
        if t in _ST_TAGS:
            b = "".join(el.itertext())
            if b.strip():
                syn.st_program(_label(el, parent), b.strip().splitlines(), loc.find(b))
                n_st += 1
        elif t in _GRAPHIC_TAGS and _ln(getattr(parent.get(el), "tag", "")) in ("Implementation", "body", "Body"):
            notes.append(("PLC-FMT-002", _label(el, parent) or "File", f"{t} logic not analysed"))
    decls = []
    for el in root.iter():
        vname = el.get("name")
        if _ln(el.tag) == "variable" and vname and is_secret_name(vname):
            for v in el.iter():
                val = v.get("value") if _ln(v.tag) == "simpleValue" else None
                if val:
                    decls.append(f"{vname} : STRING := " +
                                 (val if re.fullmatch(r"-?\d+", val) else "'" + val.replace("'", "$'") + "'") + ";")
                    break
    if decls:
        syn.st_program("Variables", decls, 0)
    logic = Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src, generic=True).parse() if syn.lines else []
    cx.take(_merge(logic, _raw_scan(_xml_lines(text), name, cx)), prefix)
    for rule, where, snip in notes:
        cx.note(rule, where, snip, prefix)
    if any(_ln(e.tag).startswith("SW.") for e in root.iter()):
        cx.detail(prefix, name, "Siemens TIA Portal export without logic blocks (tag table / UDT / other): "
                                "text scan only - export the FC/FB/OB blocks as XML or SCL to analyse the logic")
        return
    cx.detail(prefix, name, f"XML ({_ln(root.tag)}): {n_st} ST block(s) analysed + text scan of the whole file")


def _split_comments(text):
    """(comments, code): comments maps 1-based line -> comment text found on it; code is the text with every
    comment and string literal blanked out but all line breaks kept (same line count as the input)."""
    out, comments, i, n, ln = [], {}, 0, len(text), 1

    def add_comment(chunk, at):
        comments[at] = (comments.get(at, "") + " " + chunk).strip() if at in comments else chunk
    while i < n:
        two = text[i:i + 2]
        if two == "//":
            j = text.find("\n", i)
            j = n if j < 0 else j
            add_comment(text[i + 2:j], ln)
            out.append(" " * (j - i))
            i = j
        elif two == "(*" or two == "/*":
            close = "*)" if two == "(*" else "*/"
            j = text.find(close, i + 2)
            j = n if j < 0 else j + 2
            body = text[i + 2:j - 2 if text[j - 2:j] == close else j]
            for k, part in enumerate(body.split("\n")):
                if part.strip():
                    add_comment(part, ln + k)
            seg = text[i:j]
            out.append(re.sub(r"[^\n]", " ", seg))
            ln += seg.count("\n")
            i = j
        elif text[i] == "'":
            j = i + 1
            while j < n and text[j] != "'" and text[j] != "\n":
                j += 2 if text[j] == "$" else 1
            j = min(j + 1, n)
            out.append("''" + " " * max(j - i - 2, 0))
            i = j
        else:
            if text[i] == "\n":
                ln += 1
            out.append(text[i])
            i += 1
    return comments, "".join(out).split("\n")


def _looks_like_code(comment):
    return bool(comment) and bool(_CODE_COMMENT_RE.match(comment))


def _scl_normalize(text):
    """Siemens SCL -> plain ST the generic engine understands. Line numbers are preserved 1:1.
    '#local' -> 'local', '"Sym"."Member"' -> 'Sym.Member', 'x.%X3' -> 'x.X3'; headers/REGIONs/pragmas become comments."""
    out = []
    for line in text.splitlines():
        st = line.strip()
        if re.match(r"(REGION|END_REGION|VERSION|BEGIN|FUNCTION|FUNCTION_BLOCK|ORGANIZATION_BLOCK|DATA_BLOCK|TYPE|"
                    r"END_FUNCTION|END_FUNCTION_BLOCK|END_ORGANIZATION_BLOCK|END_DATA_BLOCK|END_TYPE)\b", st, re.I) \
                or st.startswith("{"):
            out.append("// " + st)
            continue
        parts = re.split(r"('(?:[^'$\n]|\$.)*')", line)
        for k in range(0, len(parts), 2):
            seg = re.sub(r'"([^"\n]*)"', lambda m: re.sub(r"[^\w.]", "_", m.group(1)), parts[k])
            seg = re.sub(r"#(?=[A-Za-z_])", "", seg)
            parts[k] = re.sub(r"\.%([XBWD])(\d+)", r".\1\2", seg, flags=re.I)
        out.append("".join(parts))
    return out


def _scl_blocks(text):
    """[(block name, first line number, [normalised lines])] - one entry per FUNCTION/FB/OB/DB in an SCL source."""
    lines = text.splitlines()
    norm = _scl_normalize(text)
    starts = [(i, re.match(r"\s*(?:FUNCTION_BLOCK|FUNCTION|ORGANIZATION_BLOCK|DATA_BLOCK)\s+\"?([^\"\s:]+)", l, re.I))
              for i, l in enumerate(lines)]
    starts = [(i, m.group(1)) for i, m in starts if m]
    if not starts:
        return [("Main", 1, norm)]
    starts[0] = (0, starts[0][1])
    return [(name, i + 1, norm[i:(starts[k + 1][0] if k + 1 < len(starts) else len(norm))])
            for k, (i, name) in enumerate(starts)]


def _scan_items(items, name, cx, binary):
    """items = [(position, text)] (byte offset for binaries, line number for text)."""
    cx.check()
    raw = Scanner(name, cx.strict, lines=[t for _, t in items],
                  line_map=[0 if binary else p for p, _ in items], raw=True,
                  ctx_labels=[f"Offset 0x{p:X}" for p, _ in items] if binary else None,
                  ip_note="binary string - may be a version number" if binary else "").parse()
    syn, k = _Synth(), 0
    stmts = []
    for pos, t in items:
        s = t.strip()
        if _RUNG_STR.match(s):
            stmts.append((pos, s if s.endswith(";") else s + ";"))
        elif ":=" in s and s.endswith(";"):
            stmts.append((pos, s))
    logic = []
    if stmts:
        syn.add("PROGRAM Extracted (MainRoutineName := Strings, FaultRoutineName := Strings)")
        syn.add("ROUTINE Strings ()")
        for k, (pos, s) in enumerate(stmts):
            syn.add(f"{k}: {s}", 0 if binary else pos)
        syn.add("END_ROUTINE")
        syn.add("END_PROGRAM")
        logic = Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src, generic=True).parse()
    merged = _merge(logic, raw)
    if binary:
        for f in merged:
            f.confidence = "Low"
    return merged


def _extract_strings(data, check=None):
    found = {}
    for rx, enc in ((_ASCII_RE, "latin-1"), (_UTF16_RE, "utf-16-le")):
        for n, m in enumerate(rx.finditer(data)):
            if check and n % 5000 == 0:
                check()
            s = m.group().decode(enc).strip()
            if len(s) >= MIN_STRING and s not in found:
                found[s] = m.start()
                if len(found) >= MAX_STRINGS:
                    break
    return sorted(((off, s) for s, off in found.items()))


def _carve_zlib(data, check=None):
    view, n, skip_until, tries, found = memoryview(data), len(data), 0, 0, 0
    for m in _ZLIB_RE.finditer(data):
        if check:
            check()
        s = m.start()
        if s < skip_until:
            continue
        tries += 1
        if tries > MAX_CARVE_TRIES or found >= MAX_CARVE_STREAMS:
            break
        d, out, p = zlib.decompressobj(), bytearray(), s
        try:
            while p < min(n, s + MAX_CARVE_IN) and not d.eof and len(out) < MAX_CARVE_OUT:
                q = min(p + 65536, n)
                out += d.decompress(view[p:q])
                p = q
        except zlib.error:
            continue
        if len(out) < 64:
            continue
        if d.eof:
            skip_until = p - len(d.unused_data)
        found += 1
        yield s, bytes(out)


def _analyze_binary(data, name, ext, depth, cx, prefix, carved=False):
    cx.check()
    strings = _extract_strings(data, cx.check)
    n_carved = 0
    if depth < MAX_DEPTH - 1:
        for off, chunk in _carve_zlib(data, cx.check):
            n_carved += 1
            label = f"zlib@0x{off:X}"
            _analyze(chunk, label, "", depth + 1, cx, _join(prefix, label), carved=True)
    cx.take(_scan_items(strings, name, cx, binary=True), prefix)
    if not carved:
        info = FORMAT_INFO.get(ext, "unrecognised binary format")
        cx.note("PLC-FMT-001", "File", f"{info}: {len(strings)} embedded strings analysed, "
                f"{n_carved} compressed stream(s) decoded; logic inside the binary is not parsed", prefix)
        cx.detail(prefix, name, f"{info} - string-level analysis ({len(strings)} strings, {n_carved} zlib stream(s))")


def _analyze_zip(data, name, ext, depth, cx, prefix):
    cx.check()
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        cx.note("PLC-FMT-004", "File", "ZIP signature present but archive is damaged", prefix)
        _analyze_binary(data, name, ext, depth, cx, prefix)
        return
    skipped, scanned = [], 0
    with zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        for zi in infos[:MAX_MEMBERS]:
            cx.check()
            mext = os.path.splitext(zi.filename)[1].lower()
            if mext not in FORMAT_INFO:
                skipped.append(zi.filename)
            elif zi.flag_bits & 0x1:
                skipped.append(f"{zi.filename} (encrypted)")
            elif zi.file_size > MAX_MEMBER_BYTES or cx.total + zi.file_size > MAX_TOTAL_BYTES or \
                    (zi.file_size > 50 * 1024 * 1024 and zi.file_size / max(zi.compress_size, 1) > 200):
                skipped.append(f"{zi.filename} (size/ratio limit)")
            else:
                try:
                    with zf.open(zi) as fh:
                        blob = fh.read(MAX_MEMBER_BYTES + 1)
                except (RuntimeError, zipfile.BadZipFile, NotImplementedError, OSError, EOFError) as exc:
                    skipped.append(f"{zi.filename} (unreadable: {exc})")
                    continue
                if len(blob) > MAX_MEMBER_BYTES:
                    skipped.append(f"{zi.filename} (size limit)")
                    continue
                cx.total += len(blob)
                scanned += 1
                _analyze(blob, zi.filename, mext, depth + 1, cx, _join(prefix, zi.filename))
        if len(infos) > MAX_MEMBERS:
            skipped.append(f"... {len(infos) - MAX_MEMBERS} more member(s) beyond the {MAX_MEMBERS} limit")
    cx.detail(prefix, name, f"ZIP archive: {scanned} member(s) scanned, {len(skipped)} skipped")
    if skipped:
        cx.note("PLC-FMT-003", "Archive", f"{len(skipped)} member(s) not scanned: " + ", ".join(skipped[:8]),
                prefix)


def _analyze_text(text, name, ext, depth, cx, prefix):
    if text.lstrip("\ufeff \t\r\n").startswith("<"):
        return _analyze_xml(text, name, ext, cx, prefix)
    lines = text.splitlines()
    if ext == ".l5k" or _L5K_RE.search(text[:500000]):
        cx.take(Scanner(name, cx.strict, lines=lines).parse(), prefix)
        cx.detail(prefix, name, "Rockwell L5K text - full rule set")
    elif ext == ".scl" or (ext == ".st" and re.search(r"(?im)^\s*(FUNCTION|FUNCTION_BLOCK|ORGANIZATION_BLOCK|DATA_BLOCK)\s+\"", text[:200000])):
        syn, blocks = _Synth(), _scl_blocks(text)
        for bname, first, body in blocks:
            syn.st_program(bname, body, first)
            if re.search(r"S7_Optimized_Access\s*:=\s*'FALSE'", "\n".join(body), re.I):
                cx.note("PLC-ACC-004", f"Program:{_safe(bname)}", "{ S7_Optimized_Access := 'FALSE' }", prefix)
        logic = Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src, generic=True, siemens=True).parse()
        cx.take(_merge(logic, _raw_scan(lines, name, cx)), prefix)
        cx.detail(prefix, name, f"Siemens SCL ({len(blocks)} block(s), symbolic names normalised) - ST rule set "
                                f"+ Siemens checks + text scan")
    elif ext in (".st", ".scl"):
        syn = _Synth()
        syn.st_program("Main", lines, 1)
        logic = Scanner(name, cx.strict, lines=syn.lines, line_map=syn.src, generic=True).parse()
        cx.take(_merge(logic, _raw_scan(lines, name, cx)), prefix)
        cx.detail(prefix, name, f"{FORMAT_INFO[ext]} - ST rule set + text scan")
    elif ext == ".awl":
        cx.take(_raw_scan(lines, name, cx), prefix)
        cx.detail(prefix, name, "Siemens STL/AWL - comment/string/IP/credential scan (instruction list not parsed)")
    else:
        items = [(i, l) for i, l in enumerate(lines, 1) if l.strip()]
        cx.take(_scan_items(items, name, cx, binary=False), prefix)
        info = FORMAT_INFO.get(ext, "unrecognised text format")
        cx.note("PLC-FMT-001", "File", f"{info}: structure not parsed; text/statement-level analysis only", prefix)
        cx.detail(prefix, name, f"{info} - text/statement-level analysis")


def _analyze(data, name, ext, depth, cx, prefix, carved=False):
    cx.check()
    ext = ext.lower()
    kind = _sniff(data)
    if kind == "zip":
        if depth >= MAX_DEPTH:
            cx.note("PLC-FMT-003", "Archive", "nesting depth limit reached; inner archive not scanned", prefix)
        else:
            _analyze_zip(data, name, ext, depth, cx, prefix)
    elif kind == "text":
        _analyze_text(decode_text(data), name, ext, depth, cx, prefix)
    else:
        _analyze_binary(data, name, ext, depth, cx, prefix, carved)


# ---- baseline / suppression file
BASELINE_STATUSES = ("accepted_risk", "false_positive")


def fingerprint(f):
    """Stable id for a finding. Excludes line numbers so it survives edits that shift lines;
    it changes when the rule, location (program/routine/rung/tag) or flagged code changes."""
    if f.rule_id.startswith("PLC-FMT"):
        key = "|".join((f.rule_id, f.location))
    else:
        key = "|".join((f.rule_id, f.location, f.title, " ".join(f.snippet.split())))
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def _parse_date(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return datetime.date.fromisoformat(text)
    except ValueError:
        raise ValueError(f"invalid date '{text}' (use YYYY-MM-DD)")


def load_baseline(path):
    """Read and validate a baseline file."""
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict) or not isinstance(data.get("entries", []), list):
        raise ValueError("baseline must be a JSON object with an 'entries' list")
    for n, e in enumerate(data.get("entries", []), 1):
        if not isinstance(e, dict) or not isinstance(e.get("fingerprint"), str) or not e["fingerprint"]:
            raise ValueError(f"entry {n}: missing 'fingerprint'")
        if e.get("status", "accepted_risk") not in BASELINE_STATUSES:
            raise ValueError(f"entry {n}: status must be one of {', '.join(BASELINE_STATUSES)}")
        _parse_date(e.get("expires"))
    return data


def apply_baseline(findings, baseline, today=None):
    """Split findings into (active, suppressed, expired, stale).
    Entries past their 'expires' date no longer suppress: the finding is reported again."""
    today = today or datetime.date.today()
    by_fp = {e["fingerprint"]: e for e in baseline.get("entries", [])}
    active, suppressed, expired, matched = [], [], [], set()
    for f in findings:
        e = by_fp.get(f.fingerprint)
        if e is None:
            active.append(f)
            continue
        matched.add(f.fingerprint)
        exp = _parse_date(e.get("expires"))
        if exp and exp < today:
            expired.append((f, e))
            active.append(f)
        else:
            suppressed.append((f, e))
    stale = [e for fp, e in by_fp.items() if fp not in matched]
    return active, suppressed, expired, stale


def write_baseline(path, findings, status="accepted_risk", reason="TODO: add justification", owner="", expires=""):
    """Add findings to the baseline file at `path` (created if missing). Existing entries,
    including reasons/owners/expiry you edited, are kept. Returns the number of entries added."""
    if status not in BASELINE_STATUSES:
        raise ValueError(f"status must be one of {', '.join(BASELINE_STATUSES)}")
    _parse_date(expires)
    data = load_baseline(path) if os.path.exists(path) else {"version": 1, "entries": []}
    known = {e["fingerprint"] for e in data["entries"]}
    added = 0
    for f in findings:
        if not f.fingerprint:
            f.fingerprint = fingerprint(f)
        if f.fingerprint in known:
            continue
        known.add(f.fingerprint)
        added += 1
        data["entries"].append({"fingerprint": f.fingerprint, "rule_id": f.rule_id, "severity": f.severity,
                                "location": f.location, "snippet": f.snippet[:100], "status": status,
                                "reason": reason, "owner": owner, "expires": expires})
    data["version"] = 1
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    return added


def scan_file(path, strict=False, baseline=None, cancel=None):
    """Scan any supported PLC project/export/source file (or ZIP of them) -> ScanResult.
    baseline: optional dict from load_baseline(); suppressed findings move to result.suppressed.
    cancel: optional object with is_set() (e.g. threading.Event); checked between files, archive
    members, string extraction and zlib carving. Raises ScanCancelled when it is set."""
    size = os.path.getsize(path)
    if size > MAX_FILE_BYTES:
        raise ValueError(f"file is {size // 2**20} MB; limit is {MAX_FILE_BYTES // 2**20} MB")
    with open(path, "rb") as fh:
        data = fh.read()
    ext = os.path.splitext(path)[1].lower()
    cx = _Ctx(strict, cancel)
    cx.total = len(data)
    if ext not in FORMAT_INFO:
        cx.details.append(f"extension '{ext or '(none)'}' is not in the supported list - format detected from content")
    _analyze(data, os.path.basename(path), ext, 0, cx, "")
    cx.findings.sort(key=lambda f: (SEV_ORDER[f.severity], f.line))
    for f in cx.findings:
        f.fingerprint = fingerprint(f)
    if baseline:
        active, suppressed, expired, stale = apply_baseline(cx.findings, baseline)
        return ScanResult(active, cx.details, suppressed, expired, stale)
    return ScanResult(cx.findings, cx.details)


# ------------------------------------------------------------ output
def print_report(path, findings, min_sev):
    shown = [f for f in findings if SEV_ORDER[f.severity] <= SEV_ORDER[min_sev]]
    counts = {s: sum(1 for f in findings if f.severity == s) for s in SEV_ORDER}
    print(f"\n{'=' * 75}\n[+] PLC security audit: {path}")
    print("    Summary: " + (", ".join(f"{s}={c}" for s, c in counts.items() if c) or "no findings"))
    cats = [f"{c}={n}" for c, _, n in owasp_summary(findings) if n]
    if cats:
        print(f"    OWASP Top 10:{OWASP_STATE['edition']} (primary category, by analogy): " + ", ".join(cats))
    for f in shown:
        tag = f"  <{f.practice}>" if f.practice else ""
        print(f"\n[{f.severity}] {f.rule_id}  {f.title}{tag}")
        print(f"  - Context : {f.location}" + (f" (line {f.line})" if f.line else ""))
        print(f"  - Standard: {f.cwe_guideline}")
        if f.owasp:
            print(f"  - OWASP   : {f.owasp}")
        if f.confidence:
            print(f"  - Confidence: {f.confidence}")
        print(f"  - Code    : {f.snippet}")
        print(f"  - Fix     : {f.recommendation}")
    if not shown:
        print("    No findings at or above the chosen severity.")


def main():
    ap = argparse.ArgumentParser(description="Static security scanner for PLC project files (L5K/L5X/ACD/ST/SCL/XML/ZIP/... v3.5)")
    ap.add_argument("files", nargs="*", help="supported: " + " ".join(SUPPORTED_EXTS))
    ap.add_argument("--json")
    ap.add_argument("--csv")
    ap.add_argument("--min-severity", default="LOW", choices=list(SEV_ORDER))
    ap.add_argument("--fail-on", default="HIGH", choices=list(SEV_ORDER))
    ap.add_argument("--strict", action="store_true",
                    help="require bounds/zero checks in the SAME rung (matches l5k_auditor.py behaviour)")
    ap.add_argument("--config", help="JSON file overriding CONFIG keys (keywords, thresholds, pairs)")
    ap.add_argument("--baseline", help="baseline JSON: findings listed there are suppressed (accepted risk / false positive)")
    ap.add_argument("--write-baseline", metavar="FILE",
                    help="add every current finding to FILE as accepted_risk (edit the reasons afterwards) and exit 0")
    ap.add_argument("--show-suppressed", action="store_true", help="list findings hidden by the baseline")
    ap.add_argument("--rules", metavar="FILE", help="rules file (JSON): disable rules, override severity/text/confidence, add patterns and tokens")
    ap.add_argument("--dump-rules", metavar="FILE", help="write an editable rules template with every built-in rule, then exit")
    ap.add_argument("--owasp-edition", choices=sorted(OWASP_NAMES), default="2025",
                    help="OWASP Top 10 edition used to label findings (default 2025)")
    ap.add_argument("--owasp-coverage", action="store_true",
                    help="print which scanner rules map to each OWASP Top 10 category, then exit")
    ap.add_argument("--version", action="version", version=f"plc_scanner3 {__version__}")
    a = ap.parse_args()
    set_owasp_edition(a.owasp_edition)
    if a.owasp_coverage:
        print(f"OWASP Top 10:{a.owasp_edition} coverage (primary category per rule; mapping is by analogy):")
        for code, rules_ in owasp_coverage().items():
            print(f"  {code}:{a.owasp_edition} {OWASP_NAMES[a.owasp_edition][code]}: "
                  + (f"{len(rules_)} rule(s): {', '.join(r.replace('PLC-', '') for r in rules_)}" if rules_ else "no rule"))
        sys.exit(0)
    if a.dump_rules:
        n = dump_rules(a.dump_rules)
        print(f"[+] Wrote {n} rules to {a.dump_rules}. Edit it, then scan with --rules {a.dump_rules}")
        sys.exit(0)
    if a.rules:
        try:
            info = apply_rules(load_rules(a.rules))
        except (OSError, ValueError) as exc:
            print(f"[-] Error: cannot use rules file '{a.rules}': {exc}")
            sys.exit(1)
        print(f"[i] rules file {info['name']} (sha256 {info['sha256'][:12]}): {info['disabled']} disabled, "
              f"{info['overridden']} overridden, {info['patterns']} extra config pattern(s), {info['tokens']} token change(s)")
    if a.config:
        with open(a.config) as fh:
            CONFIG.update(json.load(fh))
    if not a.files:
        ap.error("no files given")
    baseline = None
    if a.baseline:
        try:
            baseline = load_baseline(a.baseline)
        except (OSError, ValueError) as exc:
            print(f"[-] Error: cannot read baseline '{a.baseline}': {exc}")
            sys.exit(1)

    allf, worst = {}, 99
    for p in a.files:
        try:
            res = scan_file(p, a.strict, baseline)
        except FileNotFoundError:
            print(f"[-] Error: target file '{p}' does not exist.")
            sys.exit(1)
        except (ValueError, OSError) as exc:
            print(f"[-] Error: cannot scan '{p}': {exc}")
            sys.exit(1)
        fs = allf[p] = res.findings
        for d in res.details:
            print(f"[i] {d}")
        print_report(p, fs, a.min_severity)
        if baseline:
            print(f"[i] baseline: {len(res.suppressed)} finding(s) suppressed, {len(res.expired)} expired "
                  f"(reported again), {len(res.stale)} stale entr{'y' if len(res.stale) == 1 else 'ies'} matched nothing")
            if a.show_suppressed:
                for f, e in res.suppressed:
                    print(f"    suppressed [{f.severity}] {f.rule_id} {f.location} "
                          f"- {e.get('status', 'accepted_risk')}: {e.get('reason', '')}")
        worst = min([worst] + [SEV_ORDER[f.severity] for f in fs])
    if a.json:
        with open(a.json, "w") as fh:
            json.dump({p: [asdict(f) for f in fs] for p, fs in allf.items()}, fh, indent=2)
    if a.csv:
        with open(a.csv, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["file"] + list(Finding.__dataclass_fields__))
            for p, fs in allf.items():
                for f in fs:
                    w.writerow([p] + list(asdict(f).values()))
    total = sum(len(v) for v in allf.values())
    if a.write_baseline:
        try:
            added = write_baseline(a.write_baseline, [f for fs in allf.values() for f in fs])
        except (OSError, ValueError) as exc:
            print(f"[-] Error: cannot write baseline '{a.write_baseline}': {exc}")
            sys.exit(1)
        print(f"\n[+] Baseline updated: {added} new entr{'y' if added == 1 else 'ies'} added to {a.write_baseline}. "
              "Edit 'reason', 'owner' and 'expires' for each, then rescan with --baseline.")
        sys.exit(0)
    print(f"\n{'=' * 75}\n[+] Audit complete. Total findings: {total}")
    sys.exit(1 if worst <= SEV_ORDER[a.fail_on] else 0)


if __name__ == "__main__":
    main()
