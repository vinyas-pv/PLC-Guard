# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for the PLC Security Scanner desktop app.
# Build with:  pyinstaller --noconfirm --clean packaging\PLCSecurityScanner.spec
# (packaging\build_windows.bat does this for you). Output: dist\PLC Security Scanner\PLC Security Scanner.exe
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))
APP_NAME = "PLC Security Scanner"


def p(*parts):
    return os.path.join(ROOT, *parts)


# (source, destination folder inside the bundle). Read at run time through qt_resource_path().
datas = [
    (p("README.md"), "."),
    (p("rules.example.json"), "."),
    (p("assets", "icon.ico"), "assets"),
    (p("samples", "critical_logic_flaw_sample.L5K"), "samples"),
]

a = Analysis(
    [p("plc_security_scanner.py")],
    pathex=[ROOT],
    binaries=[],
    datas=datas,
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    # The Qt modules below are not used and would only add size.
    excludes=["tkinter", "_tkinter", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
              "PySide6.QtQml", "PySide6.QtQuick", "PySide6.Qt3DCore", "PySide6.QtMultimedia",
              "PySide6.QtCharts", "PySide6.QtDataVisualization",
              "PySide6.QtPdf", "PySide6.QtPdfWidgets",
              "PySide6.QtOpenGL", "PySide6.QtOpenGLWidgets"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,                     # UPX-packed executables trigger far more antivirus false positives
    console=False,                 # windowed application: no black console window
    disable_windowed_traceback=False,
    icon=p("assets", "icon.ico"),
    version=os.path.join(SPECPATH, "version_info.txt"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name=APP_NAME,
)
