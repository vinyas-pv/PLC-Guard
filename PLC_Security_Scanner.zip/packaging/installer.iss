; Inno Setup 6.3+ script: packages the PyInstaller output into a normal Windows installer.
; Compile with:  ISCC.exe /DAppVersion=3.5.0 packaging\installer.iss   (build_windows.bat does this)
; The finished installer asks to launch the app when it ends, so installing it opens the tool.

#ifndef AppVersion
  #define AppVersion "3.5.0"
#endif
#define AppName "PLC Security Scanner"
#define AppExeName "PLC Security Scanner.exe"
#define AppPublisher "PLC Security Scanner"

[Setup]
; Fixed identifier: lets a newer installer upgrade an existing install in place. Never reuse it for another product.
AppId={{038EF0B9-67A8-4584-8D79-567566186367}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=..\dist\installer
OutputBaseFilename=PLC-Security-Scanner-Setup-{#AppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\{#AppExeName}
UninstallDisplayName={#AppName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Per-user install needs no administrator rights; the wizard lets the user choose (useful on locked-down PCs).
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Files]
Source: "..\dist\{#AppName}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
; Shown as a ticked box on the last wizard page: finishing the installer opens the tool.
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent
