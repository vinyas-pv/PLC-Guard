@echo off
rem PLC Security Scanner Windows build script.
setlocal EnableExtensions
cd /d "%~dp0\.."

echo.
echo === PLC Security Scanner: Windows build ===
where py >nul 2>nul
if errorlevel 1 goto no_python

rem Recreate an incomplete/stale virtual environment.
if exist ".venv-build\Scripts\python.exe" goto have_venv
if exist ".venv-build" rmdir /s /q ".venv-build"

echo Creating the build environment .venv-build ...
set "PYVER="
for %%V in (3.14 3.13 3.12 3.11 3.10) do call :try_version %%V
if not defined PYVER goto no_supported_python
if not exist ".venv-build\Scripts\python.exe" goto venv_failed

echo Using Python %PYVER%
:have_venv
set "VENV_PY=%CD%\.venv-build\Scripts\python.exe"
if not exist "%VENV_PY%" goto venv_failed

echo.
echo === Installing dependencies ===
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto fail
"%VENV_PY%" -m pip install -r requirements.txt -r requirements-build.txt
if errorlevel 1 goto fail

echo.
echo === Test suite excluded from this production package ===
echo Build will proceed directly to packaging.

set "APPVER="
for /f %%v in ('"%VENV_PY%" packaging\make_version_info.py') do set "APPVER=%%v"
if not defined APPVER goto fail
echo Building version %APPVER%

echo.
echo === Building the executable with PyInstaller ===
rem pyinstaller is invoked as a module from the selected virtual environment
"%VENV_PY%" -m PyInstaller --noconfirm --clean packaging\PLCSecurityScanner.spec
if errorlevel 1 goto fail
if not exist "dist\PLC Security Scanner\PLC Security Scanner.exe" goto no_exe

echo.
echo === Building the installer with Inno Setup ===
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto have_iscc
set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto have_iscc
set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto have_iscc
echo Inno Setup 6 was not found, so the installer was skipped.
echo Install it from https://jrsoftware.org/isdl.php and run this script again.
goto done_portable

:have_iscc
"%ISCC%" /DAppVersion=%APPVER% packaging\installer.iss
if errorlevel 1 goto fail
echo Installer: dist\installer\PLC-Security-Scanner-Setup-%APPVER%.exe
echo Portable : dist\PLC Security Scanner\PLC Security Scanner.exe
goto end

:done_portable
echo Portable build: dist\PLC Security Scanner\PLC Security Scanner.exe
goto end

:try_version
if defined PYVER exit /b 0
py -%1 --version >nul 2>nul
if errorlevel 1 exit /b 0
echo Trying Python %1
py -%1 -m venv .venv-build >nul 2>nul
if errorlevel 1 exit /b 0
if not exist ".venv-build\Scripts\python.exe" exit /b 0
set "PYVER=%1"
exit /b 0

:no_python
echo ERROR: Python Launcher py was not found. Install Python from https://www.python.org/downloads/.
exit /b 1
:no_supported_python
echo ERROR: No usable Python 3.10-3.14 runtime was found. Install Python 3.13 or 3.14 and retry.
exit /b 1
:venv_failed
echo ERROR: Could not create or locate .venv-build\Scripts\python.exe. Delete .venv-build and retry.
exit /b 1
:no_exe
echo ERROR: PyInstaller finished but the executable was not produced. Check output above.
exit /b 1
:fail
echo ERROR: the build failed. See messages above.
exit /b 1
:end
endlocal
