# PLC Project Security Scanner

A static security scanner for PLC programs. It reads project files, exports and source files from
several vendors, applies a heuristic rule set (credentials, network exposure, unsafe logic, missing
safeguards, and so on), and produces a prioritised list of findings with CWE references and fix
recommendations.

Repository contents:

| Path | Purpose |
|---|---|
| `plc_scanner3.py` | Scanner engine and command-line interface (v3.5) |
| `plc_security_scanner.py`, `(included in plc_security_scanner.py)` | **Desktop app (PySide6)**: the window and its shared GUI logic |
| `(GUI helpers included in plc_security_scanner.py)` | Shared scanner filtering and report-export functions used by the Qt app |
| `packaging/`, `assets/`, `requirements*.txt` | Windows build: PyInstaller spec, Inno Setup installer script, build script, icon |
| `BUILDING.md` | Step-by-step guide to building the Windows installer |
| `run_from_source.bat` | Start the PySide6 app from source on Windows |
| `rules.example.json` | Example rules file (see "Rules file") |
| `samples/` | Small demonstration PLC project opened by the GUI's sample command |

> **Findings are review leads, not proof.** The analysis is heuristic and static. A clean result does
> not mean a program is secure, and a finding does not mean it is exploitable.

**Version:** 3.5

**Contributors:** Vinyas PV Kuddannaya

---

## Requirements

- **Scanner engine and command line:** Python 3.8 or newer, no third-party packages.
- **Desktop app (PySide6) from source:** Python 3.10 to 3.12 and `pip install -r requirements.txt`.
- **Windows installer:** nothing to install; see "Desktop app and Windows installer" below.
- **Older Tk GUI:** Tkinter (bundled with the python.org installers; on Debian/Ubuntu `sudo apt install python3-tk`).

Keep the `.py` files together in the **same folder**; the GUIs import the engine.

---

## Desktop app and Windows installer

The recommended GUI is the PySide6 desktop app (`plc_security_scanner.py`). It has everything the older Tk GUI has (upload and drag-and-drop, Cancel, sortable multi-select results tree (Category / Title / Instance: click a title such as *Output coil driven in multiple locations* to expand every instance as a sub-branch), confidence/OWASP/severity/search filters, config / rules / baseline files with indicators, suppress-selected, CSV/JSON/HTML export including suppressed findings and their reasons) plus a menu bar, remembered window size and settings, an error log, and opening a file given on the command line.

**Run it from source (Windows):** double-click `run_from_source.bat`, or `pip install -r requirements.txt` then `python plc_security_scanner.py`.

**Build a Windows installer** that, once installed, opens the tool (a ticked *Launch PLC Security Scanner* box on the last wizard page): run `packaging\build_windows.bat` on a Windows PC with Python 3.10-3.14 and Inno Setup 6.3+. The script builds the app with PyInstaller and compiles `dist\installer\PLC-Security-Scanner-Setup-<version>.exe`. Full steps, options, signing and troubleshooting are in **[BUILDING.md](BUILDING.md)**.

> **Production package:** the distribution includes the application source, required runtime resources and Windows build files. The test suite is intentionally kept out of this lean package; verify the built application on the target Windows machine before deployment.

---

## Quick start

### GUI

```
python (GUI helpers included in plc_security_scanner.py)        # Windows: py (GUI helpers included in plc_security_scanner.py)
```

1. Click **Upload file…** and choose a PLC file (the dialog is grouped by vendor). Scanning starts
   automatically.
2. Review the colour-coded results. Click a column header to sort; filter by minimum severity or
   free text; optionally hide dead-code noise.
3. Select a row to see its context, standard (CWE), offending code and recommended fix. With nothing
   selected, the detail pane shows **Scan details**: how each part of the file was analysed.
4. Use **Download CSV / JSON / HTML report** to export (optionally only the rows currently shown).

Optional controls:

- **Strict:** bounds and zero checks must be in the same rung.
- **Config…:** load a JSON file that overrides the keyword lists (see "Customising").
- **Rules…:** load a rules file that disables rules, overrides severity/text/confidence, or adds patterns and name words (see "Rules file"). The file is rescanned straight away. Buttons are disabled while a scan runs.
- **Baseline…:** load a baseline file so findings you have already triaged are hidden (see "Baseline / suppression").
- **Suppress selected…:** select one finding, or several with Ctrl/Shift-click, give one reason, and add them to the baseline file (the file is created if none is loaded). The file is rescanned straight away.
- **Cancel:** stops a running scan at the next checkpoint (between files, archive members, string extraction and zlib streams). A single large text file that is already being parsed finishes first. The previous results stay on screen.
- **Min confidence:** filter the table to High, or Medium and High, confidence findings.
- **OWASP:** pick the Top 10 edition (2025 or 2021) and filter the table to one category. The **OWASP** column shows the category code.

The row under the upload bar always shows which **Config**, **Rules** file and **Baseline** are loaded, with **Reset config**, **Reset rules** and **Clear baseline** buttons, so you can tell at a glance what is affecting the results. The table has a **Confidence** column and the detail pane shows it too (see "Confidence"). Very long result lists are loaded into the table in batches so the window stays responsive.

### Command line

```
python plc_scanner3.py plant.L5K
python plc_scanner3.py project.zip --json out.json --csv out.csv --fail-on HIGH
python plc_scanner3.py motor.st fb.TcPOU --min-severity MEDIUM
python plc_scanner3.py plant.L5K --strict --config my_names.json
python plc_scanner3.py --dump-rules my_rules.json                        # editable list of all rules
python plc_scanner3.py plant.L5K --rules my_rules.json
python plc_scanner3.py plant.L5K --write-baseline plc_baseline.json     # accept today's findings
python plc_scanner3.py plant.L5K --baseline plc_baseline.json --fail-on HIGH
```

| Option | Meaning |
|---|---|
| `files` | One or more files to scan |
| `--json FILE` / `--csv FILE` | Write all findings to a file |
| `--min-severity` | Hide findings below this level in the console report (default `LOW`) |
| `--fail-on` | Exit code 1 if any finding is at or above this level (default `HIGH`) |
| `--strict` | Require guards (bounds / zero checks) in the *same* rung |
| `--config FILE` | JSON file overriding keys of the `CONFIG` dictionary |
| `--rules FILE` | Rules file: disable rules, override severity/text/confidence, add patterns and tokens |
| `--dump-rules FILE` | Write an editable template listing every built-in rule, then exit |
| `--baseline FILE` | Suppress findings listed in this baseline file |
| `--write-baseline FILE` | Add all current findings to FILE as `accepted_risk` and exit 0 |
| `--show-suppressed` | List the findings hidden by the baseline |
| `--owasp-edition {2021,2025}` | OWASP Top 10 edition used to label findings (default 2025) |
| `--owasp-coverage` | Print which rules map to each OWASP category, then exit |
| `--version` | Print the version |

Severity levels, highest to lowest: `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, `INFO`.

Exit codes: `0` = nothing at/above `--fail-on`, `1` = at least one such finding, or the file could
not be read.

---

## Supported file types

The format is detected from the file's **content**; the extension is only a hint. A file with an
unlisted extension is still scanned by content, with a note in the scan details.

| Extension(s) | Treated as | Analysis depth |
|---|---|---|
| `.l5k` | Rockwell Logix 5000 text export | **Full** rule set |
| `.l5x` | Rockwell Logix 5000 XML export, converted internally to the L5K model | **Full** rule set |
| `.st` | IEC 61131-3 Structured Text source | **Medium**: ST rules plus text scan |
| `.scl` (and `.st` with Siemens `FUNCTION "name"` headers) | Siemens TIA Portal SCL source. `#local`, `"Symbol"."Member"`, `.%X0` bit access, `REGION` and pragmas are normalised; each FUNCTION/FB/OB/DB is its own block | **Medium+**: ST rules, Siemens checks (forced safety signals, S7 PUT/GET/TCON, commented-out code, access mode), text scan |
| `.xml` Siemens TIA Portal SimaticML (Openness export of FC/FB/OB/DB) | LAD/FBD networks are converted from their wire graph to rungs (`XIC/XIO/OTE/OTL/OTU`, `BST/NXB/BND`, timers, flip-flops, compares, calls); SCL networks are rebuilt from tokens. Locations read `Program:<block>/Routine:Logic/Rung:<network number>` | **Full-ish**: logic, safety, comms, credential and Siemens checks. STL/GRAPH networks are reported as `PLC-FMT-002` |
| `.TcPOU`, `.xml` (PLCopen, Beckhoff, Schneider XEF) | XML with embedded ST code and declarations | **Medium**: ST blocks plus whole-file text scan |
| `.tsproj`, `.plcproj`, other XML | XML project/config files | **Light**: text scan only |
| `.awl` | Siemens STL / AWL source | **Light**: comments, strings, IPs, credentials; instruction list is not parsed |
| `.zip`, `.zap15`, `.zap19`, `.zef`, `.projectarchive` | ZIP-based archives. Opened in memory; every supported member is scanned (nested archives included). | Per member |
| `.acd`, `.rss`, `.slc`, `.ap15`, `.ap19`, `.s7p`, `.stu`, `.sta`, `.project`, `.library`, `.gx3`, `.gxw`, `.gps`, `.smc2`, `.cxp` | Proprietary containers | **String-level only** |

`.xef` is also accepted so that `.zef` archives are useful.

### What "string-level only" means

For proprietary binary containers the scanner does not parse the logic. It:

1. extracts printable ASCII and UTF-16 strings,
2. finds and decompresses embedded zlib streams and rescans the result (a decompressed L5K or XML
   payload is analysed with the full rules),
3. runs credential, IP and insecure-setting checks on the strings, and any strings that look like
   ladder instructions (e.g. `XIC(a)OTE(b);`) or ST statements (`x := 1;`) are run through the rule
   engine.

Every such file produces a `PLC-FMT-001` finding stating that coverage is limited. For a real audit,
**export the project to an open format** (L5K/L5X, PLCopen XML, ST/SCL) and scan that.

If a file's extension and content disagree (for example a `.zef` that is not actually a ZIP), the
scanner follows the content and reports a `PLC-FMT-004` note.

---

## What it checks

Rules are identified as `PLC-<AREA>-<NNN>`. The main groups:

| Area | Examples |
|---|---|
| `CRED` | Hard-coded passwords in tag values, comments, strings, `EQU` comparisons, ST declarations |
| `NET` | Hard-coded IP addresses, unauthenticated `MSG`, raw TCP/UDP socket instructions |
| `ACC` | Safety/secret/sensitive tags with read/write external access |
| `CFG` | No security code, change detection off, electronic keying off, web server/Telnet/FTP/SNMP/OPC UA anonymous enabled, unlocked safety task, large watchdog |
| `INP` | Array indexes without bounds checks, HMI input reaching write instructions unvalidated, unsafe `COP`/`CPS` lengths |
| `LOG` | Output driven from several places, opposing outputs on one rung or without interlock, latches never unlatched |
| `ROB` / `INT` / `TMR` / `PLA` | Missing fault routine, division without zero check, unbounded ST loops, overflow checks, timer presets, input plausibility |
| `MODE` / `RST` / `SES` / `MON` | No keyswitch tracking, no first-scan initialisation, no session timeout, no health monitoring |
| `SYS` / `SAF` / `DBG` / `CODE` / `MOD` | `SSV`, `UID`, bypass-plus-safety logic, test/debug residue, dead code, uncalled routines, oversized routines |
| `FMT` | Coverage notes: limited analysis, graphical routine languages skipped, archive members skipped, parse fallback |

Some rules apply only to Rockwell content. The "absence" checks (keyswitch, first-scan, session
timeout, health monitoring, overflow flags) and the "no fault routine" / "uncalled routine" checks
look for Logix names such as `S:FS` and `S:KEYS`, so they are **disabled for non-Rockwell formats**.

### Reading locations

- Findings inside archives or decompressed streams are prefixed with their origin, e.g.
  `[inner.zip!a/sample.L5X] Program:Main/Routine:MainRoutine/Rung:2` or
  `[c/project.acd!zlib@0x12E] ...`.
- For text, ST and XML sources, the line number refers to the original file where it could be
  determined. For binaries the location shows the byte offset (`Offset 0x357`) instead.
- For multi-line ST statements the reported line is the line where the statement starts.
- Hard-coded IPs found in binary strings are reported as `LOW` and flagged "may be a version number",
  because dotted version strings look like IP addresses.

---

## Confidence

Every finding carries a confidence level showing how likely it is to be a true positive:

| Level | Meaning | Examples |
|---|---|---|
| **High** | A literal setting or instruction was read directly | Web server enabled, `SSV`/`UID` used, opposing outputs on one rung, raw sockets |
| **Medium** | A structural or name-based pattern | Hard-coded credential in a secret-named tag, unvalidated HMI value, missing index bounds check |
| **Low** | Absence-based or weak name heuristic | "No keyswitch tracking", "no first-scan logic", `MSG` flagged as unauthenticated, anything found only in binary strings |

Confidence is separate from severity. A CRITICAL finding with Low confidence still needs a human to confirm it is real. Review High-confidence findings first. The level is fixed per rule (the `CONFIDENCE` table in `plc_scanner3.py`), except that findings from binary strings are always Low.

---

## Baseline / suppression

A baseline file records findings you have reviewed, so repeat scans don't keep reporting them.

1. **Create it:** `python plc_scanner3.py plant.L5K --write-baseline plc_baseline.json` adds every current finding as `accepted_risk` with the reason `TODO: add justification`. Running it again keeps your edits and adds only new findings. (In the GUI use **Suppress selected…** to add one finding at a time with a reason.)
2. **Triage it:** open the JSON and, for each entry, set `status`, `reason`, `owner` and optionally `expires`. Delete entries for findings you do want to keep seeing.
3. **Use it:** `--baseline plc_baseline.json`, or **Baseline…** in the GUI.

```json
{
  "version": 1,
  "entries": [
    {
      "fingerprint": "3f9c1a7e5b2d4c80",
      "rule_id": "PLC-RST-001",
      "location": "Entire codebase",
      "status": "false_positive",
      "reason": "Safe state is set by the plant-wide start-up module",
      "owner": "V. Kuddannaya",
      "expires": "2027-06-30"
    }
  ]
}
```

- **status:** `accepted_risk` or `false_positive`.
- **expires** (`YYYY-MM-DD`, optional): after this date the entry stops suppressing and the finding is reported again, so risk acceptances get reviewed.
- **Fingerprints** are computed from the rule, location (program/routine/rung/tag) and the flagged code. They do **not** include line numbers, so a suppression survives edits that shift lines. They do change when the rung number, name or flagged code changes, which correctly brings the finding back for review.
- **Stale entries** (matching nothing in the current scan) are counted in the summary so you can clean them up.
- Suppressed findings are excluded from the report, the exports and the `--fail-on` exit code. Use `--show-suppressed` to list them. Keep one baseline per project: findings with the same rule and location in different files share a fingerprint.
- Treat the baseline as a controlled document. Anyone who can edit it can hide findings, so keep it under version control and review changes to it.

---

## Rules file

A rules file changes how the scanner behaves **without editing code**. It is plain JSON (`--rules FILE`, or **Rules…** in the GUI). Start from a template:

```
python plc_scanner3.py --dump-rules my_rules.json
```

The template lists all rules with their built-in settings, so it changes nothing until you edit it. Delete entries you don't need. `rules.example.json` shows a small working example.

```json
{
  "version": 1,
  "disable": ["PLC-CODE-001"],
  "overrides": {
    "PLC-CFG-006": {
      "severity": "HIGH",
      "confidence": "High",
      "title": "Module web server enabled",
      "cwe": "CWE-306 / CWE-200",
      "recommendation": "Disable the web server (plant SOP-17).",
      "practice": "Top20 P13"
    },
    "PLC-NET-001": { "severity": "LOW", "lock_severity": true }
  },
  "cfg_params": [
    { "rule": "PLC-CFG-006", "pattern": "\\bEnableWebServer\\s*:=\\s*1\\b" }
  ],
  "tokens": {
    "debug": { "remove": ["test"] },
    "debug_substrings": { "remove": ["_test"] },
    "secret": { "add": ["passkey"] },
    "opposites": { "add": [["engage", "release"]] }
  }
}
```

| Section | What it does |
|---|---|
| `disable` | Rule ids that never produce findings. Disabling a `PLC-FMT-*` rule hides the scan-coverage warnings, which is not recommended. |
| `overrides` | Per rule: `severity`, `confidence` (High/Medium/Low), `title`, `cwe`, `recommendation`, `practice`. Only the keys you give are changed. |
| `cfg_params` | Extra regular expressions that count as a controller/module setting for a rule (for example another firmware's name for "web server enabled"). |
| `overrides.<rule>.owasp` | Remap a rule's OWASP category per edition, e.g. `{"2025": "A01"}`. An edition you leave out keeps its default. |
| `tokens` | Add or remove words the scanner uses to recognise names. Groups: `secret`, `safety`, `bypass`, `sensitive`, `debug`, `external_input` (one lowercase word each), `secret_substrings` and `debug_substrings` (text searched inside names or logic), and `opposites` (pairs of words for conflicting outputs). |

**Things to know**

- **Severity overrides win.** Four rules normally raise or lower their own severity by context: `PLC-INP-001`, `PLC-LOG-001`, `PLC-NET-001` and `PLC-TMR-001` (for example a public IP address makes `PLC-NET-001` MEDIUM). A severity you set that differs from the built-in one always applies. If you set the *same* value as the built-in one and want it fixed, add `"lock_severity": true`.
- **Name checks have two layers.** To stop `FB_Test` being reported as test residue, remove `test` from `tokens.debug` (names) **and** `_test` from `tokens.debug_substrings` (text in logic).
- **Validation.** The whole file is checked before use. Unknown rule ids, bad severities, invalid regular expressions and unknown keys are all listed together, and nothing is applied if there is a problem.
- **A rules file replaces the previous one**; it does not stack. **Reset rules** (GUI) restores the built-in set.
- **Traceability.** The CLI prints the rules file name and a short hash. The GUI's JSON and HTML exports record the scanner version, rules file name and SHA-256, so a report can be tied to the rule set that produced it.
- **Baselines are unaffected.** Fingerprints do not include severity or text, so changing them does not invalidate suppressions. Entries for rules you disabled will show as stale.
- **Trust the file.** A rules file can hide findings and contains regular expressions that run against project files. Keep it under version control, review changes to it, and only load files from a source you trust. Patterns are limited to 300 characters.
- **Detection logic is not in the rules file.** To change *when* a rule fires (not just its settings), edit the `Scanner` class in `plc_scanner3.py`.

---

## OWASP Top 10 mapping

Every finding carries a primary **OWASP Top 10** category. Choose the edition with `--owasp-edition 2025` (default) or `2021`; the GUI has an edition selector that relabels results instantly. The 2025 edition is the current published list (announced November 2025, final version January 2026); 2021 is the previous edition that many audits and policies still reference.

> **Read this first.** The OWASP Top 10 is an awareness document about **web application** risks. A PLC has no browser, SQL or sessions in that sense, so the mapping is **by analogy**: each rule is assigned the category whose weakness family (the rule's CWE ids) or intent it most resembles. It helps you report in a familiar vocabulary. It is **not** an OWASP assessment, a compliance statement or a certification, and it does not make PLC findings equivalent to web vulnerabilities.

**Where it shows up**

- Console: an `OWASP` line per finding and a per-category count under the summary. `--owasp-coverage` prints which rules map to each category and exits.
- GUI: an **OWASP** column, a category filter and an edition selector next to the other filters. The detail pane shows the full label.
- Exports: CSV and JSON include an `owasp` field. The GUI's JSON adds `owasp_edition` and an `owasp_summary` of all ten categories (zero counts included). The HTML report adds a column and a summary line.
- Scan-coverage notes (`PLC-FMT-*`) have no category, because they describe the scan, not the program.

**Mapping (2025 order, primary category per rule)**

| 2025 category | 2021 equivalent | What it means for PLC code | Rules (primary category) |
|---|---|---|---|
| **A01:2025 Broken Access Control** | A01:2021 Broken Access Control | Tags, safety logic and controller settings that can be written or changed by parties who should not be able to | ACC-001, ACC-002, ACC-003, CFG-012, SYS-001 |
| **A02:2025 Security Misconfiguration** | A05:2021 Security Misconfiguration | Unneeded services enabled (web server, SNMP), weak module settings, debug/test leftovers, hard-coded addresses | CFG-003, CFG-004, CFG-005, CFG-006, CFG-011, DBG-001, NET-001 |
| **A03:2025 Software Supply Chain Failures** | A06:2021 Vulnerable and Outdated Components | Controller firmware older than your policy minimum (set `min_firmware_major`; off by default). Library and add-on instruction provenance is not assessed | VER-001 |
| **A04:2025 Cryptographic Failures** | A02:2021 Cryptographic Failures | Cleartext protocols (Telnet, FTP), OPC UA 'None' security policy, raw sockets | CFG-007, CFG-008, CFG-010, NET-003 |
| **A05:2025 Injection** | A03:2021 Injection | Unvalidated external input (HMI values, array indexes, copy lengths, string handling, timer/counter presets) influencing control logic or memory | INP-001, INP-002, INP-003, INP-004, INP-005, PLA-001, TMR-001 |
| **A06:2025 Insecure Design** | A04:2021 Insecure Design | Logic flaws: conflicting outputs, unsafe restart state, bypass combined with safety signals, oversized or dead logic | CODE-001, CODE-002, LOG-001, LOG-002, LOG-003, LOG-004, MOD-001, RST-001, SAF-001 |
| **A07:2025 Authentication Failures** | A07:2021 Identification and Authentication Failures | Hard-coded credentials, no controller security code, anonymous OPC UA, unauthenticated messaging, no session timeout | CFG-001, CFG-009, CRED-001, CRED-002, CRED-003, CRED-004, NET-002, SES-001 |
| **A08:2025 Software or Data Integrity Failures** | A08:2021 Software and Data Integrity Failures | Change detection / signature protection switched off | CFG-002 |
| **A09:2025 Logging & Alerting Failures** | A09:2021 Security Logging and Monitoring Failures | No operating-mode tracking, no health monitoring | MODE-001, MON-001 |
| **A10:2025 Mishandling of Exceptional Conditions** | (none: part of A04:2021 Insecure Design) | No fault routine, division without zero check, arithmetic without overflow check, unbounded loops, interrupts disabled | INT-001, ROB-001, ROB-002, ROB-003, SYS-002 |

**What this mapping does and does not cover**

- **One primary category per finding**, so summaries add up. Many findings touch several categories (for example a missing security code is also an access-control issue). To change a mapping, use the `owasp` key in a rules file (see "Rules file").
- **A03 Software Supply Chain Failures / A06:2021 Vulnerable and Outdated Components** has a single rule, and it needs a policy: set `min_firmware_major` in the Config file (for example `{"min_firmware_major": 21}`) and controllers with a lower firmware major revision are reported. There is no vulnerability database behind it, and add-on instruction or library provenance is not assessed.
- **A08 Software or Data Integrity Failures** has one rule (change detection / signature protection off). Signed-code and provenance checks are not implemented.
- **A10:2021 Server-Side Request Forgery** has no PLC analogue and no rule.
- **Exceptional conditions** (fault routines, division, overflow, loops) are a 2025 category. In the 2021 edition the same rules map to Insecure Design, so that category looks much larger there.
- A category with findings means the scanner saw something that resembles it. A category with none does **not** mean that area is secure.

---

## Outputs

| Format | Notes |
|---|---|
| Console | Grouped by severity, with context, standard, code and fix |
| CSV | UTF-8 with BOM so Excel opens it correctly |
| JSON | CLI: `{file: [findings]}`. GUI: includes a summary, timestamp, scanner version and rules file name/hash. Findings include `confidence` and `fingerprint` |
| HTML | Standalone, colour-coded report (GUI) |

Credential values are **redacted** in findings; only the fact that one exists is reported.

---

## Safety limits

The scanner opens untrusted files, so it applies limits (constants near the top of the front-end
section of `plc_scanner3.py`):

| Limit | Default |
|---|---|
| Maximum input file | 512 MB |
| Maximum single archive member | 200 MB |
| Maximum total data read | 1 GB |
| Maximum members per archive | 5,000 |
| Maximum archive nesting depth | 4 |
| Archive compression-ratio guard | Members over 50 MB expanding more than 200:1 are skipped |
| zlib carving | At most 2,000 streams, 64 MB output per stream |

Archives are read in memory only; nothing is written to disk, so path-traversal entries in a ZIP
cannot affect your file system. XML containing `<!ENTITY>` declarations is **not parsed** (protection
against entity-expansion attacks) and is scanned as plain text instead. Encrypted archive members are
skipped and listed in a `PLC-FMT-003` note.

---

## Customising

### Keyword lists and thresholds (Config file)

Pass a JSON file with `--config` (or **Config…** in the GUI) to override any key of the `CONFIG`
dictionary in `plc_scanner3.py`, for example:

```json
{
  "rung_max": 80,
  "keyswitch_keywords": ["S:KEYS", "KeySwitch", "Mode_Key"],
  "hmi_prefixes": ["HMI_", "SCADA_"],
  "forbidden_pairs": [["Gate_Open", "Gate_Close"]]
}
```

Module/controller property names differ between firmware versions. If a service-exposure rule does
not fire on your export, add the attribute name through a rules file (`cfg_params`), or to `CFG_PARAMS` in the code.

### Adding an extension

Add a line to `FORMAT_INFO` in `plc_scanner3.py`. If its content is text, XML, ZIP or binary, the
existing detection routes it automatically. For a new dialog entry in the GUI, add the extension to
`FILE_GROUPS` in `(GUI helpers included in plc_security_scanner.py)`.

---

## Known limitations

- **Binary formats are not parsed.** See "string-level only" above. The `.acd`/`.ap*` carving is
  best-effort and only helps if the container stores zlib-compressed sections.
- **Vendor-format support was built from format knowledge and synthetic test files**, not from a
  corpus of real project files for every vendor. Expect some real-world exports to need small
  adjustments (attribute names in L5X, element names in vendor XML).
- **Graphical languages** (ladder, FBD, SFC, IL) in non-Rockwell, non-Siemens formats are not analysed and are
  reported as `PLC-FMT-002`. Siemens LAD/FBD (SimaticML) is analysed; the conversion flattens a network to
  per-output conditions, so parallel branches are approximated and findings are review leads.
- **`.awl`** (STL source) gets a text scan only; STL instruction analysis is not implemented. Export blocks as SCL or SimaticML XML instead.
- **Encrypted or password-protected** archives and projects cannot be read.
- **Heuristic rules produce false positives**, notably name-based checks (e.g. a program called
  `FB_Test` is flagged as debug residue) and IP-address matches in XML.
- Python 3.8+ is required because the engine uses the walrus operator.
- The Windows executable and installer are built by scripts that have not been run by the author; see BUILDING.md.

---

## Behaviour changes in v3.5

- **New:** PySide6 desktop app, Windows build scripts (PyInstaller + Inno Setup installer that launches the app), icon, build guide, Windows packaging support.
- **The scanner engine, rules and results are unchanged.** Only the version number moved.

## Behaviour changes in v3.4

- **New:** OWASP Top 10 mapping (2025 and 2021) on every finding, console/GUI/export support, `--owasp-edition`, `--owasp-coverage`, remapping through the rules file, and the policy-driven firmware rule `PLC-VER-001`.
- **Findings gain an `owasp` field** in JSON/CSV. Existing fields are unchanged.
- **No change** to which findings are reported unless you set `min_firmware_major` (default 0 = off).

## Behaviour changes in v3.3

- **New:** rules file (`--rules`, `--dump-rules`, GUI **Rules…**), configurable `debug_substrings` / `secret_substrings`, scanner version and rules file recorded in GUI exports.
- **No change** to results when no rules file is loaded.

## Behaviour changes in v3.2

- **GUI:** Cancel button, always-visible Config/Baseline indicator with reset buttons, multi-select suppress, minimum-confidence filter, batched table loading, and a summary when several rows are selected.
- **Engine:** `scan_file(..., cancel=...)` accepts an object with `is_set()` (such as `threading.Event`) and raises `ScanCancelled`.

## Behaviour changes in v3.1

- **New:** baseline/suppression file, per-finding confidence, `MAIN name;` / `FAULT name;` program lines in L5K, `--version`, automated tests.
- **Fixed:** an L5K program that declares its main routine with a `MAIN name;` line was reported as having an uncalled routine (`PLC-CODE-002`). A `FAULT name;` line now also counts as a fault routine (`PLC-ROB-001`).
- Findings now include two extra fields, `confidence` and `fingerprint`, in JSON and CSV output. Existing columns are unchanged.

## Behaviour changes from v2.1

- **Fault-routine check fixed.** v2.1 looked for an attribute named `FaultRoutine`, but L5K headers
  use `FaultRoutineName`, so every program was reported as having no fault routine and its fault
  routine as uncalled. v3.0 reads `FaultRoutineName` (falling back to `FaultRoutine`). Results for
  L5K files are otherwise unchanged.
- **New:** multi-format front end, `PLC-FMT-*` coverage notes, ST declaration credential check, and
  the `scan_file()` API.

---

## Using the engine from Python

```python
import plc_scanner3 as scanner

result = scanner.scan_file("project.zip", strict=False)
for f in result.findings:
    print(f.severity, f.rule_id, f.location, f.snippet)
for line in result.details:      # how each part of the file was analysed
    print(line)
```

`scan_file()` accepts any supported file and returns a `ScanResult(findings, details)`. The original
`Scanner(path).parse()` interface still works for L5K text.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| GUI says "Tkinter is not installed" | `sudo apt install python3-tk` (Linux); reinstall Python with Tk on Windows/macOS |
| GUI says "Scanner engine missing" | Put `plc_scanner3.py` in the same folder as `(GUI helpers included in plc_security_scanner.py)` |
| "No findings" on a binary project | Check the Scan details and the `PLC-FMT-001` note: only strings were analysed. Export to an open format and rescan. |
| Archive members missing from results | Look for a `PLC-FMT-003` note listing skipped members (unsupported type, encrypted, or over a limit) |
| "file is N MB; limit is 512 MB" | Raise `MAX_FILE_BYTES` in `plc_scanner3.py` if you trust the file |
