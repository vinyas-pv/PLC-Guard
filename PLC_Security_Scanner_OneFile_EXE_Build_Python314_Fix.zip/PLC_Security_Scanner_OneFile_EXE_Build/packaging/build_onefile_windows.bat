@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."

 echo.
echo === PLC Security Scanner: single-file Windows EXE build ===

rem Start clean so an old/broken virtual environment is not reused.
if exist ".venv-build" rmdir /s /q ".venv-build"
set "PYVER="

where py >nul 2>nul
if errorlevel 1 goto no_launcher

rem Try supported 64-bit Python versions, newest first. Python 3.14 is supported
rem by recent PyInstaller releases; 3.10-3.13 remain fallback options.
for %%V in (3.14 3.13 3.12 3.11 3.10) do call :try_version %%V
if not defined PYVER goto no_supported_python
if not exist ".venv-build\Scripts\python.exe" goto venv_failed
set "VENV_PY=%CD%\.venv-build\Scripts\python.exe"

echo Using Python %PYVER%
"%VENV_PY%" -m ensurepip --upgrade
if errorlevel 1 goto fail
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto fail
"%VENV_PY%" -m pip install -r requirements.txt "pyinstaller>=6.16,<7"
if errorlevel 1 goto fail

echo.
echo === Building ONE standalone EXE ===
"%VENV_PY%" -m PyInstaller --noconfirm --clean packaging\PLCSecurityScanner_OneFile.spec
if errorlevel 1 goto fail
if not exist "dist\PLC Security Scanner.exe" goto no_exe

echo.
echo SUCCESS: dist\PLC Security Scanner.exe
echo This is the single file to share. Python is not required on recipient PCs.
goto end

:try_version
if defined PYVER exit /b 0
py -%1 -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 exit /b 0
py -%1 -m venv .venv-build >nul 2>nul
if errorlevel 1 exit /b 0
if not exist ".venv-build\Scripts\python.exe" exit /b 0
set "PYVER=%1"
exit /b 0

:no_launcher
echo ERROR: The Windows Python Launcher 'py' was not found.
echo Install 64-bit Python from https://www.python.org/downloads/windows/
echo During setup, enable the Python Launcher option, then reopen this window.
goto failed
:no_supported_python
echo ERROR: No usable 64-bit Python 3.10, 3.11, 3.12, 3.13 or 3.14 was found.
echo Install Python 3.14 (recommended) or Python 3.13 from python.org,
echo enable the Python Launcher, then run this script again.
goto failed
:venv_failed
echo ERROR: Could not create the build virtual environment.
echo Check that Python is installed correctly and that this folder is writable.
goto failed
:no_exe
echo ERROR: PyInstaller did not create the expected EXE. Check build output.
goto failed
:fail
echo ERROR: A build command failed. Read the error messages above.
goto failed
:failed
endlocal
exit /b 1
:end
endlocal
exit /b 0
