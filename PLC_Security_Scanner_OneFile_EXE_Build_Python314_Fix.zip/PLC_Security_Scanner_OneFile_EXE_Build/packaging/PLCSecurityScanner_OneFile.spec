# Single-file, windowed Windows executable.
# Build from the project root with:
#   py -m PyInstaller --noconfirm --clean packaging\\PLCSecurityScanner_OneFile.spec
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))
APP_NAME = "PLC Security Scanner"


def p(*parts):
    return os.path.join(ROOT, *parts)


a = Analysis(
    [p("plc_security_scanner.py")],
    pathex=[ROOT],
    binaries=[],
    datas=[
        (p("README.md"), "."),
        (p("rules.example.json"), "."),
        (p("assets", "icon.ico"), "assets"),
        (p("samples", "critical_logic_flaw_sample.L5K"), "samples"),
    ],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        "tkinter", "_tkinter",
        "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
        "PySide6.QtQml", "PySide6.QtQuick", "PySide6.Qt3DCore",
        "PySide6.QtMultimedia", "PySide6.QtCharts",
        "PySide6.QtDataVisualization", "PySide6.QtPdf",
        "PySide6.QtPdfWidgets", "PySide6.QtOpenGL",
        "PySide6.QtOpenGLWidgets",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon=p("assets", "icon.ico"),
    version=os.path.join(SPECPATH, "version_info.txt"),
)
